"""
End-to-end validation of the discovery control plane + pipeline against a
synthetic in-memory BigQuery-like dataset. Proves:
  1. Cold-start bootstrap from audit logs seeds the right candidate pairs
  2. The fence/sketch/IND passes produce sensible scored edges
  3. Composite keys flow through correctly
  4. Steward verdicts move lifecycle state and gate future runs
  5. Data drift re-opens settled pairs; unchanged settled pairs are skipped
"""
import sys, random
sys.path.insert(0, "/home/claude/reldiscovery")
random.seed(42)

from discovery.drivers import (MockComputeDriver, MockSketchDriver, _FakeColumn)
from discovery.work_queue import InMemoryQueueStore
from discovery.pipeline import DiscoveryPipeline, DiscoveryConfig, TriggerHandlers

# ---------------------------------------------------------------------------
# Build a synthetic enterprise: customers, orders, order_lines, products,
# shipments. Real referential structure so IND probes mean something.
# ---------------------------------------------------------------------------
N_CUST, N_ORD, N_LINE, N_PROD = 1000, 5000, 15000, 300

customer_ids = list(range(1, N_CUST + 1))
product_ids  = list(range(1, N_PROD + 1))
order_ids    = list(range(1, N_ORD + 1))
fiscal_years = [2023, 2024, 2025]

# orders reference customers; carry (order_id, fiscal_year) composite key
ord_customer = [random.choice(customer_ids) for _ in range(N_ORD)]
ord_fy       = [random.choice(fiscal_years) for _ in range(N_ORD)]

# order_lines reference orders via composite (order_id, fiscal_year) and products
line_order_idx = [random.randrange(N_ORD) for _ in range(N_LINE)]
line_order_id  = [order_ids[i] for i in line_order_idx]
line_fy        = [ord_fy[i] for i in line_order_idx]            # consistent composite
line_product   = [random.choice(product_ids) for _ in range(N_LINE)]

# shipments reference orders via a RENAMED column order_ref_id (FK alias case)
ship_order = [random.choice(order_ids) for _ in range(4000)]

tables = {
    "proj.sales.dim_customer": {
        "customer_id": _FakeColumn(customer_ids),
        "name": _FakeColumn([f"cust_{i}" for i in customer_ids], "STRING"),
    },
    "proj.sales.dim_product": {
        "product_id": _FakeColumn(product_ids),
        "sku": _FakeColumn([f"sku_{i}" for i in product_ids], "STRING"),
    },
    "proj.sales.fact_orders": {
        "order_id": _FakeColumn(order_ids),
        "fiscal_year": _FakeColumn(ord_fy),
        "customer_id": _FakeColumn(ord_customer),
    },
    "proj.sales.fact_order_lines": {
        "line_id": _FakeColumn(list(range(1, N_LINE + 1))),
        "order_id": _FakeColumn(line_order_id),
        "fiscal_year": _FakeColumn(line_fy),
        "product_id": _FakeColumn(line_product),
    },
    "proj.ops.fact_shipments": {
        "shipment_id": _FakeColumn(list(range(1, 4001))),
        "order_ref_id": _FakeColumn(ship_order),
    },
}

# ---------------------------------------------------------------------------
# Synthetic audit log: the queries analysts "have been running"
# ---------------------------------------------------------------------------
audit_rows = [
    {"query": """SELECT o.*, c.name FROM `proj.sales.fact_orders` o
                 JOIN `proj.sales.dim_customer` c ON o.customer_id=c.customer_id""",
     "query_count": 420},
    {"query": """SELECT * FROM `proj.sales.fact_orders` o
                 JOIN `proj.sales.fact_order_lines` ol
                   ON o.order_id=ol.order_id AND o.fiscal_year=ol.fiscal_year""",
     "query_count": 130},
    {"query": """SELECT * FROM `proj.sales.fact_order_lines` ol
                 JOIN `proj.sales.dim_product` p ON ol.product_id=p.product_id""",
     "query_count": 88},
    {"query": """SELECT * FROM `proj.sales.fact_orders` o, `proj.ops.fact_shipments` s
                 WHERE o.order_id=s.order_ref_id AND s.shipment_id > 0""",
     "query_count": 45},
    {"query": "SELECT 1", "query_count": 9},                 # noise
    {"query": "NOT VALID SQL %%%", "query_count": 3},        # parse fail
]

# ---------------------------------------------------------------------------
# Wire it up
# ---------------------------------------------------------------------------
compute = MockComputeDriver(tables, audit_rows)
sketch  = MockSketchDriver(compute)
store   = InMemoryQueueStore()
cfg     = DiscoveryConfig(min_audit_query_count=5, ind_sample_rows=2000,
                          num_perm=128, jaccard_floor=0.05)
pipe    = DiscoveryPipeline(store, compute, sketch, cfg)
trig    = TriggerHandlers(store, pipe)

print("="*72)
print("PHASE 1 — COLD-START BOOTSTRAP FROM AUDIT LOGS")
print("="*72)
boot = pipe.bootstrap_from_audit()
print(f"  Parsed queries     : {boot['parsed']['total_queries']}")
print(f"  Parse failures     : {boot['parsed']['parse_failed']}")
print(f"  No-join queries    : {boot['parsed']['no_join_found']}")
print(f"  Candidate pairs    : {boot['candidates']}")
print(f"  Newly queued       : {boot['newly_queued']}")
print("\n  Seeded candidates (priority-ordered):")
for it in sorted(store.all_items(), key=lambda x: -x.priority_score):
    kind = "COMPOSITE" if it.is_composite else "single"
    cols = ",".join(f"{a}={b}" for a,b in zip(it.a_columns, it.b_columns))
    short = lambda f: f.split(".")[-1]
    print(f"    [{kind:9}] {short(it.table_a_fqn):18} <-> {short(it.table_b_fqn):18}"
          f" prio={it.priority_score:7.1f}  ({cols})")

print("\n" + "="*72)
print("PHASE 2 — DISCOVERY BATCH (fence -> sketch -> IND -> score)")
print("="*72)
out = pipe.run_discovery_batch(budget=10)
print(f"  Run {out['run_id'][:8]} · claimed={out['claimed']} "
      f"edges={out['edges']} skipped={out['skipped']}")
print("\n  Scored relationship edges:")
print(f"    {'pair':42} {'jac':>5} {'ind':>5} {'name':>5} {'conf':>5}  class / direction")
for e in sorted(out["results"], key=lambda x: -x.composite_confidence):
    short = lambda f: f.split(".")[-1]
    pair = f"{short(e.table_a_fqn)} <-> {short(e.table_b_fqn)}"
    comp = " [C]" if e.is_composite else ""
    print(f"    {pair+comp:42} {e.jaccard:5.2f} {e.ind_confidence:5.2f} "
          f"{e.name_similarity:5.2f} {e.composite_confidence:5.2f}  "
          f"{e.classification} / {e.ind_direction}")

# capture a work_id to confirm
edge_map = {(e.table_a_fqn, e.table_b_fqn): e for e in out["results"]}

print("\n" + "="*72)
print("PHASE 3 — STEWARD VERDICTS MOVE LIFECYCLE STATE")
print("="*72)
# Confirm the customer<->orders edge; reject region-like weak ones if any
cust_orders = edge_map.get(("proj.sales.dim_customer", "proj.sales.fact_orders"))
if cust_orders:
    trig.on_steward_verdict(cust_orders.work_id, "confirmed")
    print(f"  Confirmed: dim_customer <-> fact_orders")
# Confirm composite orders<->order_lines
comp_edge = edge_map.get(("proj.sales.fact_order_lines", "proj.sales.fact_orders"))
if comp_edge:
    trig.on_steward_verdict(comp_edge.work_id, "confirmed")
    print(f"  Confirmed: fact_order_lines <-> fact_orders (composite)")

for it in store.all_items():
    if it.lifecycle_state != "CANDIDATE":
        short = lambda f: f.split(".")[-1]
        print(f"    -> {short(it.table_a_fqn)} <-> {short(it.table_b_fqn)}: "
              f"lifecycle={it.lifecycle_state}, status={it.status}")

print("\n" + "="*72)
print("PHASE 4 — INCREMENTAL RE-RUN (confirmed+unchanged should be SKIPPED)")
print("="*72)
out2 = pipe.run_discovery_batch(budget=10)
print(f"  Run {out2['run_id'][:8]} · claimed={out2['claimed']} "
      f"edges={out2['edges']} skipped={out2['skipped']}")
print("  (confirmed pairs with unchanged fingerprints are NOT re-evaluated —")
print("   claimed should exclude them; only still-CANDIDATE pairs remain)")

print("\n" + "="*72)
print("PHASE 5 — DATA DRIFT RE-OPENS A CONFIRMED PAIR")
print("="*72)
# mutate fact_orders: append new rows -> fingerprint changes
tables["proj.sales.fact_orders"]["order_id"].values.extend(range(N_ORD+1, N_ORD+501))
tables["proj.sales.fact_orders"]["fiscal_year"].values.extend([2025]*500)
tables["proj.sales.fact_orders"]["customer_id"].values.extend(
    [random.choice(customer_ids) for _ in range(500)])
affected = trig.on_data_drift("proj.sales.fact_orders")
print(f"  fact_orders fingerprint changed -> re-opened {affected} settled pair(s)")
out3 = pipe.run_discovery_batch(budget=10)
print(f"  Run {out3['run_id'][:8]} · claimed={out3['claimed']} "
      f"edges={out3['edges']} skipped={out3['skipped']}")
print("  (confirmed pairs touching fact_orders are now re-evaluated for")
print("   conformance because their data fingerprint drifted)")

print("\n" + "="*72)
print("PHASE 6 — ANALYST NOMINATION (on-demand, jumps the queue)")
print("="*72)
from discovery.work_queue import WorkItem
nom = WorkItem(table_a_fqn="proj.sales.dim_product",
               table_b_fqn="proj.sales.fact_order_lines",
               a_columns=("product_id",), b_columns=("product_id",),
               is_composite=False)
res = trig.on_nomination([nom], by="architect@corp.com", budget=5)
print(f"  Nominated dim_product <-> fact_order_lines, ran immediately:")
print(f"  claimed={res['claimed']} edges={res['edges']}")
for e in res["results"]:
    short = lambda f: f.split(".")[-1]
    print(f"    {short(e.table_a_fqn)} <-> {short(e.table_b_fqn)}: "
          f"conf={e.composite_confidence:.2f} ({e.classification})")

print("\n" + "="*72)
print("DONE — control plane, passes, scoring, lifecycle & triggers validated")
print("="*72)
