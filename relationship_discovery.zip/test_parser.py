"""Quick validation of the audit join parser against realistic BQ queries."""
import sys
sys.path.insert(0, "/home/claude/reldiscovery")

from discovery.audit_join_parser import parse_query, parse_audit_rows

def show(title, pairs):
    print(f"\n=== {title} ===")
    if not pairs:
        print("  (no candidates)")
    for p in pairs:
        kind = "COMPOSITE" if p.is_composite else "single"
        amap = ", ".join(f"{a}={b}" for a, b in zip(p.a_columns, p.b_columns))
        print(f"  [{kind}] {p.table_a_fqn}  <->  {p.table_b_fqn}")
        print(f"           on: {amap}   sources={set(p.sources)}")

# 1. Explicit single-column join
q1 = """
SELECT o.*, c.name
FROM `proj.sales.fact_orders` o
JOIN `proj.sales.dim_customer` c ON o.customer_id = c.customer_id
"""
show("1. Explicit single JOIN", parse_query(q1))

# 2. Explicit COMPOSITE join (two columns, same pair -> one composite candidate)
q2 = """
SELECT *
FROM `proj.sales.fact_orders` o
JOIN `proj.sales.fact_order_lines` ol
  ON o.order_id = ol.order_id AND o.fiscal_year = ol.fiscal_year
"""
show("2. Explicit COMPOSITE JOIN", parse_query(q2))

# 3. Implicit WHERE join (comma join)
q3 = """
SELECT *
FROM `proj.sales.fact_orders` o, `proj.ops.fact_shipments` s
WHERE o.order_id = s.order_ref_id
  AND o.status = 'COMPLETE'        -- filter, must be ignored
  AND s.region_id = 5              -- constant filter, must be ignored
"""
show("3. Implicit WHERE JOIN (+ filters that must be ignored)", parse_query(q3))

# 4. Multi-table chain: 3 tables, 2 distinct pairs
q4 = """
SELECT *
FROM `proj.sales.fact_order_lines` ol
JOIN `proj.sales.dim_product` p ON ol.product_id = p.product_id
JOIN `proj.sales.fact_orders` o ON ol.order_id = o.order_id
"""
show("4. Three-table chain -> 2 pairs", parse_query(q4))

# 5. Self-join must be excluded
q5 = """
SELECT a.*
FROM `proj.hr.employees` a
JOIN `proj.hr.employees` b ON a.manager_id = b.employee_id
"""
show("5. Self-join (must be EXCLUDED)", parse_query(q5))

# 6. CTE alias must NOT seed a base-table pair (option i)
q6 = """
WITH recent AS (SELECT * FROM `proj.sales.fact_orders` WHERE order_date > '2025-01-01')
SELECT r.*, c.name
FROM recent r
JOIN `proj.sales.dim_customer` c ON r.customer_id = c.customer_id
"""
show("6. CTE on one side (option i: dropped, no base-table pair)", parse_query(q6))

# 7. Aggregation across a corpus with frequency weighting + dedup
corpus = [
    {"query": q1, "query_count": 300},   # customer<->orders, seen 300x
    {"query": q1, "query_count": 42},    # same pair again, different batch
    {"query": q2, "query_count": 89},    # composite orders<->order_lines
    {"query": "SELECT 1", "query_count": 5},          # no join
    {"query": "THIS IS NOT SQL ::::", "query_count": 1},  # parse fail
]
pairs, stats = parse_audit_rows(corpus)
show("7. Corpus aggregation", pairs)
print("\n  Stats:", stats)
print("  -> customer<->orders query_count should be 342:",
      [p.query_count for p in pairs if "dim_customer" in p.table_b_fqn or "dim_customer" in p.table_a_fqn])
