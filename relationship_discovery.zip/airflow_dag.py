"""
airflow_dag.py
==============
Thin Airflow orchestration over the framework-agnostic discovery core.
The DAG does NOT contain discovery logic — it wires triggers to the queue and
submits batches. All real work lives in discovery/*.

Two DAGs:
  1. reldiscovery_bootstrap   — run ONCE (manual trigger) for cold start
  2. reldiscovery_incremental — scheduled; detects drift, runs a budgeted batch
"""
from __future__ import annotations
import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.operators.python import PythonOperator

# ---- factory: build the production wiring (real drivers) -------------------
def _build_pipeline():
    import psycopg
    from google.cloud import bigquery
    from pyspark.sql import SparkSession

    from discovery.drivers import BigQueryDriver, SparkSketchDriver
    from discovery.work_queue import PostgresQueueStore
    from discovery.pipeline import DiscoveryPipeline, DiscoveryConfig, TriggerHandlers

    conn = psycopg.connect(os.environ["DISCOVERY_PG_DSN"])
    bq = bigquery.Client()
    spark = SparkSession.builder.appName("reldiscovery").getOrCreate()

    compute = BigQueryDriver(
        client=bq,
        project_ids=os.environ["BQ_PROJECT_IDS"].split(","),
        org_id=os.environ.get("BQ_ORG_ID"),
    )
    sketch = SparkSketchDriver(spark)
    store = PostgresQueueStore(conn)
    pipe = DiscoveryPipeline(store, compute, sketch, DiscoveryConfig())
    return store, pipe, TriggerHandlers(store, pipe)


# ---- task callables --------------------------------------------------------
def task_bootstrap(**_):
    _, pipe, _t = _build_pipeline()
    result = pipe.bootstrap_from_audit()
    print("bootstrap:", result)


def task_cold_seed(**_):
    """Second seeding path: find never-queried lookup-table relationships.
    Runs after audit bootstrap so it reuses sketches and supplements (not
    replaces) the audit-evidenced candidates."""
    _, pipe, _t = _build_pipeline()
    result = pipe.seed_cold_lookups()
    print("cold seed:", result)


def task_detect_drift(**_):
    """Scan table_registry for fingerprint changes; re-open affected pairs.
    This is the 'monthly batch' reframed: it DETECTS work, doesn't do discovery."""
    store, pipe, trig = _build_pipeline()
    # In production: compare live BQ fingerprints to table_registry.data_fingerprint
    # and call trig.on_data_drift(fqn) for each changed table. Pseudocode:
    #   for t in registry.tables():
    #       live = compute.compute_data_fingerprint(t.fqn)
    #       if live != t.stored_fingerprint:
    #           trig.on_data_drift(t.fqn); registry.update_fingerprint(t.fqn, live)
    print("drift scan complete")


def task_run_batch(**context):
    store, pipe, _t = _build_pipeline()
    budget = int(context["params"].get("scope_budget", 50_000))
    result = pipe.run_discovery_batch(budget=budget)
    print(f"batch: claimed={result['claimed']} edges={result['edges']} "
          f"skipped={result['skipped']} reclaimed={result['reclaimed']}")


# ---- DAG 1: bootstrap (manual, once) ---------------------------------------
with DAG(
    dag_id="reldiscovery_bootstrap",
    schedule=None,                       # manual trigger only
    start_date=datetime(2025, 1, 1),
    catchup=False,
    tags=["relationship-discovery", "bootstrap"],
) as bootstrap_dag:
    audit = PythonOperator(task_id="bootstrap_from_audit",
                           python_callable=task_bootstrap)
    cold = PythonOperator(task_id="cold_seed_lookups",
                          python_callable=task_cold_seed)
    audit >> cold      # cold seeding reuses sketches from the audit pass


# ---- DAG 2: incremental (scheduled) ----------------------------------------
with DAG(
    dag_id="reldiscovery_incremental",
    schedule="0 2 * * 0",                # weekly, Sunday 02:00
    start_date=datetime(2025, 1, 1),
    catchup=False,
    default_args={"retries": 2, "retry_delay": timedelta(minutes=10)},
    params={"scope_budget": 50_000},
    tags=["relationship-discovery", "incremental"],
) as incremental_dag:
    detect = PythonOperator(task_id="detect_drift", python_callable=task_detect_drift)
    run = PythonOperator(task_id="run_discovery_batch", python_callable=task_run_batch)
    detect >> run
