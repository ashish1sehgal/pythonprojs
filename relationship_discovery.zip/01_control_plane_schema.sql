-- ============================================================================
-- RELATIONSHIP DISCOVERY — CONTROL PLANE SCHEMA
-- ============================================================================
-- This is the single source of truth for "what needs discovering" and
-- "what is already settled." The execution engine (PySpark) is STATELESS —
-- it pulls work from here and writes results back. All idempotency,
-- resumability, and incrementality live in these tables.
--
-- Design principle: the unit of work is the PAIR, not the table. Triggers
-- (scheduled scan, nomination, steward action) all converge on the
-- discovery_work_queue. The "monthly batch" only detects drift and emits
-- work; it never does discovery directly.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- TABLE REGISTRY — every table known to the platform, with its fingerprint.
-- The fingerprint is how we detect "material change" for incremental triggers.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS table_registry (
    table_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system       TEXT NOT NULL,              -- 'bigquery'
    project_id          TEXT NOT NULL,
    dataset_id          TEXT NOT NULL,
    table_name          TEXT NOT NULL,
    table_fqn           TEXT NOT NULL,              -- project.dataset.table
    -- Scoping signals (computed once during onboarding, cheap to refresh)
    discovery_tier      TEXT,                       -- TIER1_CORE / TIER2_OPS / ...
    vocab_tokens        TEXT[],                     -- column-name vocabulary cluster
    row_count           BIGINT,
    -- The fingerprint: hash of (row_count || distinct-count-vector || max-ts).
    -- A material shift here is the trigger for incremental re-evaluation.
    data_fingerprint    TEXT,
    fingerprint_at      TIMESTAMPTZ,
    -- Lifecycle
    is_profiled         BOOLEAN DEFAULT FALSE,       -- has single-table profiling run?
    onboarded_at        TIMESTAMPTZ DEFAULT now(),
    last_seen_at        TIMESTAMPTZ DEFAULT now(),
    UNIQUE (source_system, table_fqn)
);
CREATE INDEX IF NOT EXISTS idx_registry_tier ON table_registry(discovery_tier);
CREATE INDEX IF NOT EXISTS idx_registry_dataset ON table_registry(dataset_id);

-- ----------------------------------------------------------------------------
-- DISCOVERY WORK QUEUE — the heart of the system.
-- Every candidate pair that needs evaluation is a row here. Idempotent:
-- a (table_a, table_b) pair is unique. Resumable: status drives an FSM.
-- Prioritized: high-value pairs (audit evidence, anchor topology) run first.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS discovery_work_queue (
    work_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    -- The pair (canonical ordering: table_a_fqn < table_b_fqn lexicographically)
    table_a_id          UUID NOT NULL REFERENCES table_registry(table_id),
    table_b_id          UUID NOT NULL REFERENCES table_registry(table_id),
    table_a_fqn         TEXT NOT NULL,
    table_b_fqn         TEXT NOT NULL,

    -- FSM status — drives the execution pipeline
    status              TEXT NOT NULL DEFAULT 'QUEUED',
    -- QUEUED -> SKETCHING -> PROBING -> SCORING -> DONE
    --        -> FAILED (retryable) -> DEAD (max attempts exceeded)
    --        -> SKIPPED (lifecycle says no re-eval needed)

    -- Lifecycle state — the incrementality gate. This is what lets us SKIP work.
    lifecycle_state     TEXT NOT NULL DEFAULT 'CANDIDATE',
    -- CANDIDATE   : full pipeline on next eligible run
    -- CONFIRMED   : steward said yes -> only lightweight conformance monitoring
    -- REJECTED    : steward said no  -> blacklisted unless fingerprint drifts
    -- MONITORING  : confirmed + under periodic conformance check
    -- DEGRADED    : confirmed but conformance dropped -> alert + re-probe

    -- Prioritization (the scope budget orders by this DESC)
    priority_score      NUMERIC(10,4) NOT NULL DEFAULT 0,
    priority_signals    JSONB,                     -- why this priority

    -- Incrementality gates: the fingerprints captured at last evaluation.
    -- If the live fingerprint differs from this, the pair is "stale" and
    -- eligible for re-evaluation even if CONFIRMED/REJECTED.
    a_fingerprint_at_eval  TEXT,
    b_fingerprint_at_eval  TEXT,

    -- Trigger provenance — how did this pair get here?
    trigger_source      TEXT,                      -- 'new_table'|'drift'|'nomination'
    triggered_by        TEXT,                      -- user email or 'system'

    -- Execution bookkeeping (resumability)
    attempt_count       INTEGER NOT NULL DEFAULT 0,
    max_attempts        INTEGER NOT NULL DEFAULT 3,
    claimed_by_run      UUID,                      -- which run batch owns it now
    claimed_at          TIMESTAMPTZ,
    last_error          TEXT,

    -- Timestamps
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now(),

    UNIQUE (table_a_id, table_b_id)
);
CREATE INDEX IF NOT EXISTS idx_wq_status_priority
    ON discovery_work_queue(status, priority_score DESC)
    WHERE status = 'QUEUED';
CREATE INDEX IF NOT EXISTS idx_wq_lifecycle ON discovery_work_queue(lifecycle_state);
CREATE INDEX IF NOT EXISTS idx_wq_claimed_run ON discovery_work_queue(claimed_by_run);

-- ----------------------------------------------------------------------------
-- DISCOVERY RUNS — each execution batch. A run claims N pairs from the queue,
-- ships them to Dataproc, and tracks completion. Enables resumability:
-- a crashed run's claimed pairs can be reclaimed after a lease timeout.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS discovery_runs (
    run_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_type            TEXT NOT NULL,             -- 'scheduled'|'nomination'|'drift'
    trigger_detail      JSONB,
    -- Scope budget for this run
    scope_budget        INTEGER NOT NULL,          -- max pairs claimed
    pairs_claimed       INTEGER DEFAULT 0,
    pairs_completed     INTEGER DEFAULT 0,
    pairs_failed        INTEGER DEFAULT 0,
    -- Dataproc linkage
    dataproc_batch_id   TEXT,
    gcs_inbox_prefix    TEXT,                      -- where results land
    -- Status
    status              TEXT NOT NULL DEFAULT 'PENDING',
    -- PENDING -> CLAIMING -> SUBMITTED -> INGESTING -> COMPLETE -> FAILED
    started_at          TIMESTAMPTZ DEFAULT now(),
    finished_at         TIMESTAMPTZ,
    created_by          TEXT
);
CREATE INDEX IF NOT EXISTS idx_runs_status ON discovery_runs(status);

-- ----------------------------------------------------------------------------
-- RELATIONSHIP EDGES — the output. Scored relationships. Confirmed/rejected
-- edges carry steward verdicts. This feeds the graph UI.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_edges (
    edge_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_id             UUID REFERENCES discovery_work_queue(work_id),
    table_a_fqn         TEXT NOT NULL,
    table_b_fqn         TEXT NOT NULL,
    -- Column mapping (composite-aware: arrays, sorted-canonical)
    a_columns           TEXT[] NOT NULL,
    b_columns           TEXT[] NOT NULL,
    is_composite        BOOLEAN DEFAULT FALSE,
    -- Mathematical signals
    jaccard_similarity  NUMERIC(6,5),
    ind_confidence      NUMERIC(6,5),
    ind_direction       TEXT,                      -- 'a_in_b'|'b_in_a'|'bidirectional'
    name_similarity     NUMERIC(6,5),
    llm_semantic_score  NUMERIC(6,5),
    lineage_prior       NUMERIC(6,5),
    composite_confidence NUMERIC(6,5),
    classification      TEXT,                      -- LIKELY_FK|POSSIBLE_LOOKUP|WEAK
    -- Source epistemology (declared vs inferred — critical distinction)
    relationship_source TEXT NOT NULL DEFAULT 'INFERRED',  -- 'DECLARED'|'INFERRED'
    declared_constraint_name TEXT,                 -- if harvested from catalog
    -- Steward verdict
    human_verdict       TEXT,                      -- 'confirmed'|'rejected'|'deferred'
    reviewed_by         TEXT,
    reviewed_at         TIMESTAMPTZ,
    -- Provenance
    discovery_run_id    UUID REFERENCES discovery_runs(run_id),
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_a_fqn, table_b_fqn, a_columns, b_columns)
);
CREATE INDEX IF NOT EXISTS idx_edges_confidence ON relationship_edges(composite_confidence DESC);
CREATE INDEX IF NOT EXISTS idx_edges_classification ON relationship_edges(classification);
CREATE INDEX IF NOT EXISTS idx_edges_source ON relationship_edges(relationship_source);

-- ----------------------------------------------------------------------------
-- COLUMN SKETCH CACHE — MinHash signatures persisted for reuse. The single
-- biggest compute saver: a column's sketch is computed once and compared
-- against all future candidates. Keyed on table + fingerprint so staleness
-- is detectable.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS column_sketch_cache (
    sketch_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_id            UUID REFERENCES table_registry(table_id),
    table_fqn           TEXT NOT NULL,
    column_name         TEXT NOT NULL,             -- or __composite__[a,b] form
    is_composite        BOOLEAN DEFAULT FALSE,
    num_perm            INTEGER NOT NULL,          -- MinHash permutations (e.g. 128)
    sketch_b64          TEXT,                      -- serialized signature
    gcs_path            TEXT,                      -- large sketches spill to GCS
    distinct_estimate   BIGINT,
    -- Staleness gate: which table fingerprint this sketch was built against
    built_against_fingerprint TEXT,
    built_at            TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_fqn, column_name, num_perm)
);
CREATE INDEX IF NOT EXISTS idx_sketch_table ON column_sketch_cache(table_id);

-- ============================================================================
-- HELPER VIEW: what's actually eligible to run right now.
-- Encapsulates the incrementality rules so the claim query stays simple.
-- ============================================================================
CREATE OR REPLACE VIEW v_runnable_work AS
SELECT wq.*
FROM discovery_work_queue wq
JOIN table_registry ta ON ta.table_id = wq.table_a_id
JOIN table_registry tb ON tb.table_id = wq.table_b_id
WHERE wq.status = 'QUEUED'
  AND wq.attempt_count < wq.max_attempts
  AND (
        -- CANDIDATE pairs always run
        wq.lifecycle_state = 'CANDIDATE'
        -- CONFIRMED/MONITORING run only if a fingerprint drifted (conformance)
     OR (wq.lifecycle_state IN ('CONFIRMED','MONITORING')
         AND (ta.data_fingerprint IS DISTINCT FROM wq.a_fingerprint_at_eval
           OR tb.data_fingerprint IS DISTINCT FROM wq.b_fingerprint_at_eval))
        -- REJECTED run only if the underlying data changed (staleness gate)
     OR (wq.lifecycle_state = 'REJECTED'
         AND (ta.data_fingerprint IS DISTINCT FROM wq.a_fingerprint_at_eval
           OR tb.data_fingerprint IS DISTINCT FROM wq.b_fingerprint_at_eval))
      );
