"""
Proves the COLD path: discovering a lookup-table relationship that has NO query
evidence whatsoever. We add DIM_CURRENCY — a small lookup table — and a
currency_code column on fact_orders that references it. CRUCIALLY, no audit
query ever joins them. Audit bootstrap is blind to this pair; cold seeding must
find it.
"""
import sys, random
sys.path.insert(0, "/home/claude/reldiscovery")
random.seed(42)

from discovery.drivers import MockComputeDriver, MockSketchDriver, _FakeColumn
from discovery.work_queue import InMemoryQueueStore
from discovery.pipeline import DiscoveryPipeline, DiscoveryConfig, TriggerHandlers
from discovery.cold_lookup_seeder import ColdSeedConfig

# ---- synthetic enterprise WITH an unused lookup table -----------------------
N_ORD = 5000
order_ids = list(range(1, N_ORD + 1))

# DIM_CURRENCY: a classic small lookup table. 8 currencies. Nobody joins it.
currency_codes = ["USD", "EUR", "GBP", "JPY", "INR", "CAD", "AUD", "CHF"]

# fact_orders carries a currency_code that references DIM_CURRENCY — but no
# query has EVER joined them (the relationship is latent in the data only).
ord_currency = [random.choice(currency_codes) for _ in range(N_ORD)]

tables = {
    "proj.ref.dim_currency": {
        "currency_code": _FakeColumn(currency_codes, "STRING"),
        "currency_name": _FakeColumn(
            ["US Dollar","Euro","Pound","Yen","Rupee","CAD Dollar","AUD Dollar","Franc"],
            "STRING"),
        "symbol": _FakeColumn(["$","€","£","¥","₹","$","$","Fr"], "STRING"),
    },
    "proj.sales.fact_orders": {
        "order_id": _FakeColumn(order_ids),
        "customer_id": _FakeColumn([random.randint(1, 1000) for _ in range(N_ORD)]),
        "currency_code": _FakeColumn(ord_currency, "STRING"),  # <-- latent FK
    },
    "proj.sales.dim_customer": {
        "customer_id": _FakeColumn(list(range(1, 1001))),
        "name": _FakeColumn([f"c{i}" for i in range(1, 1001)], "STRING"),
    },
}

# ---- audit log: ONLY the customer<->orders join. Currency is NEVER joined. --
audit_rows = [
    {"query": """SELECT o.*, c.name FROM `proj.sales.fact_orders` o
                 JOIN `proj.sales.dim_customer` c ON o.customer_id=c.customer_id""",
     "query_count": 300},
]

compute = MockComputeDriver(tables, audit_rows)
sketch  = MockSketchDriver(compute)
store   = InMemoryQueueStore()
cfg     = DiscoveryConfig(min_audit_query_count=1, ind_sample_rows=2000,
                          jaccard_floor=0.05, max_cardinality_ratio=10000.0)
pipe    = DiscoveryPipeline(store, compute, sketch, cfg)
trig    = TriggerHandlers(store, pipe)

short = lambda f: f.split(".")[-1]

print("="*74)
print("STEP 1 — AUDIT BOOTSTRAP (currency is invisible: never joined)")
print("="*74)
boot = pipe.bootstrap_from_audit()
print(f"  candidates from audit: {boot['candidates']}")
for it in store.all_items():
    cols = ",".join(f"{a}={b}" for a,b in zip(it.a_columns, it.b_columns))
    print(f"    {short(it.table_a_fqn)} <-> {short(it.table_b_fqn)}  ({cols})")
has_currency = any("dim_currency" in it.table_a_fqn or "dim_currency" in it.table_b_fqn
                   for it in store.all_items())
print(f"\n  >> dim_currency relationship found by audit? {has_currency}")
print("     (expected: False — no query ever joined it)")

print("\n" + "="*74)
print("STEP 2 — COLD LOOKUP SEEDING (finds the latent currency relationship)")
print("="*74)
cold_cfg = ColdSeedConfig(lookup_row_ceiling=1000, key_uniqueness_floor=0.95,
                          lsh_min_jaccard=0.05, lsh_bands=64, lsh_rows_per_band=2)
cold = pipe.seed_cold_lookups(cold_cfg)
print(f"  cold candidate pairs seeded: {cold['cold_candidates']} "
      f"(newly queued: {cold['newly_queued']})")
print("\n  Cold-seeded candidates:")
for it in store.all_items():
    if it.priority_signals.get("seed") == "cold_lookup":
        sig = it.priority_signals
        print(f"    {short(it.table_a_fqn)}.{it.a_columns[0]} <-> "
              f"{short(it.table_b_fqn)}.{it.b_columns[0]}")
        print(f"        parent(PK)={sig['parent']}  child(FK)={sig['child']}")
        print(f"        lsh_jaccard={sig['lsh_jaccard']}  "
              f"name_affinity={sig['name_affinity']}  prio={it.priority_score}")

found_currency = any(
    it.priority_signals.get("seed") == "cold_lookup" and
    ("dim_currency" in it.table_a_fqn or "dim_currency" in it.table_b_fqn)
    for it in store.all_items())
print(f"\n  >> dim_currency relationship found by COLD seeding? {found_currency}")
print("     (expected: True — value overlap surfaced it with no query evidence)")

print("\n" + "="*74)
print("STEP 3 — SAME PIPELINE SCORES THE COLD CANDIDATES (unchanged passes)")
print("="*74)
out = pipe.run_discovery_batch(budget=20)
print(f"  claimed={out['claimed']} edges={out['edges']} skipped={out['skipped']}")
print("\n  Scored edges (note the currency lookup now has a confidence score):")
print(f"    {'pair':46} {'jac':>5} {'ind':>5} {'name':>5} {'conf':>5}  class")
for e in sorted(out["results"], key=lambda x: -x.composite_confidence):
    pair = f"{short(e.table_a_fqn)}.{e.a_columns[0]} <-> {short(e.table_b_fqn)}.{e.b_columns[0]}"
    print(f"    {pair:46} {e.jaccard:5.2f} {e.ind_confidence:5.2f} "
          f"{e.name_similarity:5.2f} {e.composite_confidence:5.2f}  {e.classification}")

currency_edge = [e for e in out["results"]
                 if "dim_currency" in e.table_a_fqn or "dim_currency" in e.table_b_fqn]
print("\n" + "="*74)
if currency_edge and found_currency and not has_currency:
    ce = currency_edge[0]
    print("RESULT — The unused DIM_CURRENCY lookup table, which NO query had ever")
    print(f"joined, was discovered purely from value-overlap + shape + name signal,")
    print(f"and scored {ce.composite_confidence:.2f} ({ce.classification}). The gap is closed.")
else:
    print("RESULT — unexpected; investigate.")
print("="*74)
