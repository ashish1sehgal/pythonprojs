# Relationship Discovery — BigQuery Backend

Incremental, event-driven, pair-level relationship discovery for BigQuery at
enterprise scale. Bootstraps from query audit logs, then runs as a resumable
work queue.

## The core decision: neither "monthly batch all pairs" nor "on-demand single table"

Both naive framings are wrong. The unit of work is the **candidate pair**, and
pairs become eligible for evaluation based on **events**, not a calendar:

| Trigger | What it does | Compute |
|---|---|---|
| **Cold-start bootstrap** | Mine audit-log JOINs → seed candidate pairs | one-time |
| **New table onboarded** | Scope its counterparties → seed pairs | per table |
| **Data fingerprint drift** | Re-open affected pairs (conformance) | per change |
| **Steward verdict** | Confirm/Reject/Defer → lifecycle transition | none (state only) |
| **Analyst nomination** | Force-evaluate specific pairs, jump the queue | on demand |

The "monthly batch" is reframed as a **scheduled drift-detection scan that emits
events** — it detects what needs discovery, it doesn't do discovery. The
"on-demand single table" is reframed as a **nomination that enqueues pairs** at
high priority. Both converge on one queue and one execution path.

## Two seeding paths, one pipeline

Candidate pairs are born two ways, then flow into the identical
fence→sketch→IND→score pipeline:

```
SEEDING PATHS (produce candidate WorkItems)
├── audit_join_parser     pairs humans have already joined     (high prior)
│                           from INFORMATION_SCHEMA.JOBS
└── cold_lookup_seeder     pairs nobody has joined yet          (lower prior)
                            via: lookup-shape detection
                               + LSH bucketing over sketch cache (sub-quadratic)
                               + name affinity
        │
        ▼
   discovery_work_queue  ──→  SAME fence→sketch→IND→score pipeline
```

### Why the cold path exists

Audit-log bootstrap can only find relationships **someone has already
exploited**. But the primary value of discovery is finding the *unused* lookup
/ dimension tables — the orphaned `REF_COUNTRY`, the `LKP_STATUS` nobody joins
because they don't know it exists. Those never appear in any JOIN, so audit
mining is blind to them.

`cold_lookup_seeder` finds them with three signals that need only metadata +
profile stats + the existing sketch cache:

1. **Lookup-shape detection** — small table + near-unique key column ⇒ a
   dimension/lookup *parent* candidate. Identifies the "one" side of a FK with
   no data join.
2. **LSH bucketing (sub-quadratic)** over the existing sketch population, with
   a star-topology filter so every column is compared against lookup anchors,
   not against every other column. Colliding buckets surface candidates; all
   pairs are never enumerated.
3. **Name affinity** — `status_code ↔ order_status`, `currency_id ↔ currency`.

The cold path reuses the pipeline's sketch cache, so no column is sketched
twice. Cold candidates get lower base priority than audit-evidenced pairs, so
they run after the high-confidence work. LSH casts a wide net; the unchanged
IND/scoring passes filter its false positives (validated in `test_cold.py`,
where a coincidental `customer_id↔order_id` collision is correctly down-ranked
to WEAK_CORRELATION while the never-queried `DIM_CURRENCY` link scores
LIKELY_FK).

## Module layout

```
sql/01_control_plane_schema.sql   Postgres DDL: work queue, lifecycle, edges, sketch cache
discovery/
  audit_join_parser.py            sqlglot-based JOIN/WHERE extraction → candidate pairs
  cold_lookup_seeder.py           lookup-shape + LSH + name affinity → cold candidate pairs
  drivers.py                      ComputeDriver/SketchDriver interfaces
                                    + BigQueryDriver/SparkSketchDriver (prod)
                                    + Mock*Driver (local validation)
  work_queue.py                   QueueStore (InMemory + Postgres), lifecycle FSM,
                                    claim/lease with FOR UPDATE SKIP LOCKED
  pipeline.py                     DiscoveryPipeline (the passes) + TriggerHandlers
airflow/airflow_dag.py            thin orchestration: bootstrap DAG + incremental DAG
test_parser.py                    parser unit checks
test_e2e.py                       full local validation against synthetic data
test_cold.py                      proves cold discovery of a never-queried lookup table
```

## The passes (per pair)

1. **Pass 1/2 — Type + cardinality fence** — `APPROX_COUNT_DISTINCT` + null
   fraction pushed down to BigQuery. Eliminates incompatible pairs before any
   Spark spend.
2. **Pass 3 — MinHash sketch + Jaccard** — Spark/Dataproc. Composite keys use
   order-independent virtual-column projection (`__composite__[a,b]`, sorted,
   name-prefixed). Sketches are cached and reused.
3. **Pass 4 — IND containment probe** — pushed down to BigQuery as a sampled
   semi-join; returns containment fraction both directions to assign FK
   direction.
4. **Pass 5 — LLM semantic score** — *stub, next iteration.* Interface present,
   weight currently folded into the math signals.

Composite confidence = `w₁·jaccard + w₂·ind + w₃·name + w₄·lineage`
(weights configurable; Pass-5 LLM weight added next iteration).

## Pushdown-first

Everything expressible as a BigQuery aggregate runs in BQ slots (HLL distinct
counts, type fences, the IND probe). Spark is used only for MinHash sketch
generation over surviving candidate columns. This keeps Dataproc cost bounded
to the genuinely Spark-shaped work.

## Incrementality gates (how work is skipped)

- `CANDIDATE` → full pipeline on next run
- `CONFIRMED` / `MONITORING` → skipped unless a table fingerprint drifted
  (then lightweight conformance re-check)
- `REJECTED` → blacklisted unless fingerprint drifts (stale-rejection gate)
- A nomination force-reopens regardless of state

## Concurrency & resumability

The Postgres claim uses `FOR UPDATE SKIP LOCKED`, so concurrent Dataproc runs
never grab the same pair. Each claim takes a lease; `reclaim_expired()` returns
a crashed run's pairs to `QUEUED` after the lease elapses. Status is a per-item
FSM (`QUEUED → CLAIMED → SKETCHING → PROBING → SCORING → DONE`, with
`FAILED→retry`, `DEAD`, `SKIPPED`).

## Running the local validation

```bash
pip install sqlglot psycopg
python test_parser.py     # parser correctness
python test_e2e.py        # full pipeline + lifecycle + triggers on synthetic data
```

The local path uses `MockComputeDriver`/`MockSketchDriver`, which implement the
**full semantics** (real MinHash, real IND set-containment, real fingerprinting)
so the control logic is genuinely exercised, not faked.

## Deploying

1. Apply `sql/01_control_plane_schema.sql` to your Postgres control DB.
2. Set env: `DISCOVERY_PG_DSN`, `BQ_PROJECT_IDS`, `BQ_ORG_ID`.
3. Wire the real `probe_inclusion` / Spark sketch bodies (marked
   `NotImplementedError` — the mock documents the exact semantics to match).
4. Trigger `reldiscovery_bootstrap` once, then let `reldiscovery_incremental`
   run on its schedule.

## Next iteration

- Pass 5 LLM semantic scoring (interface already carved out)
- Declared-constraint harvest path (BigQuery has none, but Oracle/Postgres
  sources do — declared edges bypass the probabilistic pipeline)
- Composite cold candidates (current cold seeder emits single-column lookup
  candidates; composite lookup keys are a natural extension of the LSH path)
