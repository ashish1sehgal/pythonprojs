"""
cold_lookup_seeder.py
=====================
Second seeding path: discover relationships that have NO query history.

The audit-log bootstrap can only find relationships someone has already
exploited. But the primary value of relationship discovery is finding the
UNUSED lookup/dimension tables — the orphaned REF_COUNTRY, the LKP_STATUS
nobody joins because they don't know it exists. Those will never appear in
any JOIN, so audit mining is blind to them.

This module seeds candidate pairs WITHOUT query evidence, using three signals
that need only metadata + profile statistics + the existing sketch cache:

  1. LOOKUP-SHAPE DETECTION  — small table + near-unique key column = a
     dimension/lookup PARENT candidate. Identifies the "one" side of a
     one-to-many FK without any data join.

  2. LSH BUCKETING (sub-quadratic) — over the EXISTING sketch population, find
     columns whose value sets overlap with a lookup anchor's key column. This
     is the star-topology scope: every column is compared against lookup
     anchors, not against every other column. LSH banding makes this
     sub-quadratic — colliding buckets surface candidates; we never enumerate
     all pairs.

  3. NAME AFFINITY — status_code <-> order_status, currency_id <-> currency.
     A cheap prior that boosts/parallels the value-overlap signal.

Output: WorkItems that flow into the SAME work queue and SAME fence->sketch->
IND->score pipeline as audit-seeded pairs. The only difference is provenance
(trigger_source='cold_lookup') and a lower base priority — these are
speculative, so they run after the high-confidence audit-evidenced pairs.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass

from .drivers import (ComputeDriver, SketchDriver, SketchResult,
                      make_column_key)
from .work_queue import WorkItem

logger = logging.getLogger(__name__)


@dataclass
class ColdSeedConfig:
    lookup_row_ceiling: int = 100_000       # tables larger than this aren't lookups
    key_uniqueness_floor: float = 0.95      # distinct/row >= this => key column
    num_perm: int = 128
    distinct_cap: int = 500_000
    # LSH banding (bands * rows_per_band must == num_perm)
    lsh_bands: int = 32
    lsh_rows_per_band: int = 4
    lsh_min_jaccard: float = 0.10           # cast wide; pipeline IND probe narrows
    # name affinity
    name_affinity_floor: float = 0.30
    # priority: cold pairs start lower than audit pairs (which start ~60-200)
    base_priority: float = 10.0


def _trigram(s: str) -> set[str]:
    s = f"  {s.lower()} "
    return {s[i:i+3] for i in range(len(s) - 2)}


def _name_affinity(col_a: str, col_b: str) -> float:
    ta, tb = _trigram(col_a), _trigram(col_b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


class ColdLookupSeeder:
    """
    Generates candidate WorkItems for never-queried relationships.

    Strategy:
      - identify lookup/dimension tables (Signal 1) -> their key columns are
        the FK-PARENT anchors
      - ensure those anchors (and all profiled columns) have sketches
      - LSH-bucket all sketches with the star-topology anchor filter (Signal 2)
      - for each bucket hit, compute name affinity (Signal 3) and emit a
        candidate pair oriented child(FK) -> parent(PK)
    """

    def __init__(self, compute: ComputeDriver, sketch: SketchDriver,
                 cfg: ColdSeedConfig | None = None):
        self.compute = compute
        self.sketch = sketch
        self.cfg = cfg or ColdSeedConfig()

    def seed(self, sketch_supplier) -> list[WorkItem]:
        """
        sketch_supplier(table_fqn, column_key) -> SketchResult
            A callable that returns (and caches) a column's sketch. We reuse the
            pipeline's sketch cache so cold discovery never re-sketches a column
            that audit discovery already sketched.
        """
        cfg = self.cfg

        # ---- Signal 1: identify lookup/dimension parents ----
        shapes = self.compute.scan_table_shapes(
            cfg.lookup_row_ceiling, cfg.key_uniqueness_floor)
        lookups = [s for s in shapes if s.row_count <= cfg.lookup_row_ceiling
                   and s.key_columns]
        if not lookups:
            logger.info("cold seed: no lookup-shaped tables found")
            return []

        # anchor key columns: the PK side of potential FKs
        anchor_keys: set[tuple[str, str]] = set()
        anchor_sketches: list[SketchResult] = []
        for lk in lookups:
            for kc in lk.key_columns:
                ck = make_column_key([kc])
                anchor_keys.add((lk.table_fqn, ck))
                anchor_sketches.append(sketch_supplier(lk.table_fqn, ck))

        # ---- gather candidate-child sketches: every column of every table ----
        # (in production, restrict to type-compatible columns via profile stats;
        #  here we sketch all columns of all tables and let LSH + IND filter)
        all_sketches: list[SketchResult] = list(anchor_sketches)
        for s in shapes:
            for cname in s.columns:
                ck = make_column_key([cname])
                if (s.table_fqn, ck) in anchor_keys:
                    continue  # already added as an anchor
                all_sketches.append(sketch_supplier(s.table_fqn, ck))

        # ---- Signal 2: LSH bucketing with star-topology anchor filter ----
        hits = self.sketch.lsh_bucket(
            all_sketches,
            bands=cfg.lsh_bands,
            rows_per_band=cfg.lsh_rows_per_band,
            min_jaccard=cfg.lsh_min_jaccard,
            anchor_keys=anchor_keys,
        )

        # ---- build WorkItems, oriented child(FK) -> parent(PK) ----
        items: list[WorkItem] = []
        for h in hits:
            # decide which side is the lookup parent (anchor)
            a_is_anchor = (h.table_a_fqn, make_column_key([h.column_a])) in anchor_keys
            b_is_anchor = (h.table_b_fqn, make_column_key([h.column_b])) in anchor_keys
            if a_is_anchor and not b_is_anchor:
                parent_fqn, parent_col = h.table_a_fqn, h.column_a
                child_fqn, child_col = h.table_b_fqn, h.column_b
            elif b_is_anchor and not a_is_anchor:
                parent_fqn, parent_col = h.table_b_fqn, h.column_b
                child_fqn, child_col = h.table_a_fqn, h.column_a
            else:
                # both or neither anchors: skip ambiguous (two lookups colliding)
                continue

            # ---- Signal 3: name affinity ----
            name_aff = _name_affinity(child_col, parent_col)

            # canonical ordering for the queue (matches audit path convention)
            if child_fqn < parent_fqn:
                ta, tb = child_fqn, parent_fqn
                ca, cb = (child_col,), (parent_col,)
            else:
                ta, tb = parent_fqn, child_fqn
                ca, cb = (parent_col,), (child_col,)

            prio = (cfg.base_priority
                    + h.estimated_jaccard * 20.0      # value overlap
                    + name_aff * 15.0)                # name signal

            items.append(WorkItem(
                table_a_fqn=ta, table_b_fqn=tb,
                a_columns=ca, b_columns=cb, is_composite=False,
                priority_score=round(prio, 4),
                priority_signals={
                    "seed": "cold_lookup",
                    "lsh_jaccard": h.estimated_jaccard,
                    "name_affinity": round(name_aff, 4),
                    "parent": f"{parent_fqn}.{parent_col}",
                    "child": f"{child_fqn}.{child_col}",
                },
                trigger_source="cold_lookup",
            ))
        logger.info("cold seed: %d lookup anchors -> %d candidate pairs",
                    len(anchor_keys), len(items))
        return items
