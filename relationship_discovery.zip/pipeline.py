"""
pipeline.py
===========
Orchestrates relationship discovery on top of the control plane and drivers.

Two entry points reflect the two-phase design we agreed on:

  bootstrap_from_audit()  — COLD START. Mines BigQuery audit logs, parses JOIN
                            predicates into column-level candidate pairs, and
                            seeds the work queue. Run once.

  run_discovery_batch()   — STEADY STATE. Claims a budgeted batch of runnable
                            pairs and executes the passes:
                              Pass 1/2 : type + cardinality fence  (BQ pushdown)
                              Pass 3   : MinHash sketch + Jaccard   (Spark)
                              Pass 4   : IND containment probe       (BQ pushdown)
                              Pass 5   : LLM semantic score          (STUB - next iter)
                            then scores and writes edges.

Incremental triggers (new table / drift / steward action) just feed the same
queue and call run_discovery_batch — there is no separate code path.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass

from .audit_join_parser import parse_audit_rows
from .drivers import ComputeDriver, SketchDriver, make_column_key
from .work_queue import QueueStore, WorkItem

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Tunables (would live in config / Postgres in production)
# ---------------------------------------------------------------------------
@dataclass
class DiscoveryConfig:
    lookback_days: int = 180
    min_audit_query_count: int = 5
    num_perm: int = 128
    distinct_cap: int = 500_000
    ind_sample_rows: int = 50_000
    # fence thresholds
    max_null_fraction: float = 0.95
    max_cardinality_ratio: float = 50.0
    # scoring thresholds
    jaccard_floor: float = 0.15            # below this, don't bother with IND
    ind_confirm_threshold: float = 0.60
    likely_fk_threshold: float = 0.80
    possible_lookup_threshold: float = 0.55
    # weights (Pass-5 LLM weight folded into others until next iteration)
    w_jaccard: float = 0.35
    w_ind: float = 0.40
    w_name: float = 0.10
    w_lineage: float = 0.15


# ---------------------------------------------------------------------------
# Scoring helpers
# ---------------------------------------------------------------------------
def _name_similarity(a_cols, b_cols) -> float:
    """Cheap trigram-ish name similarity over the column lists."""
    def trigrams(s):
        s = f"  {s.lower()} "
        return {s[i:i+3] for i in range(len(s) - 2)}
    sa = set().union(*(trigrams(c) for c in a_cols)) if a_cols else set()
    sb = set().union(*(trigrams(c) for c in b_cols)) if b_cols else set()
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def _classify(conf: float, cfg: DiscoveryConfig) -> str:
    if conf >= cfg.likely_fk_threshold:
        return "LIKELY_FK"
    if conf >= cfg.possible_lookup_threshold:
        return "POSSIBLE_LOOKUP"
    return "WEAK_CORRELATION"


@dataclass
class EdgeResult:
    table_a_fqn: str
    table_b_fqn: str
    a_columns: tuple[str, ...]
    b_columns: tuple[str, ...]
    is_composite: bool
    jaccard: float
    ind_confidence: float
    ind_direction: str
    name_similarity: float
    lineage_prior: float
    composite_confidence: float
    classification: str
    work_id: str


# ---------------------------------------------------------------------------
# Pipeline
# ---------------------------------------------------------------------------
class DiscoveryPipeline:
    def __init__(self, store: QueueStore, compute: ComputeDriver,
                 sketch: SketchDriver, cfg: DiscoveryConfig | None = None):
        self.store = store
        self.compute = compute
        self.sketch = sketch
        self.cfg = cfg or DiscoveryConfig()
        # in-process sketch cache: (table_fqn, column_key) -> SketchResult
        self._sketch_cache: dict[tuple[str, str], object] = {}

    # -- COLD START ---------------------------------------------------------
    def bootstrap_from_audit(self, lineage_priors: dict[tuple, float] | None = None) -> dict:
        """
        Mine audit logs -> parse joins -> seed candidate pairs.
        `lineage_priors` optionally maps a candidate dedupe key to a prior
        confidence (from frequency / source reliability), used for priority.
        """
        rows = self.compute.fetch_audit_join_queries(
            self.cfg.lookback_days, self.cfg.min_audit_query_count)
        candidates, stats = parse_audit_rows(rows)
        logger.info("audit parse: %s", stats)

        items: list[WorkItem] = []
        for c in candidates:
            # Priority: frequency-weighted, boosted for explicit joins & composites
            base = min(c.query_count, 500) * 0.4
            if "explicit_join" in c.sources:
                base += 30
            if c.is_composite:
                base += 15
            prior = (lineage_priors or {}).get(c.dedupe_key, 0.0)
            base += prior * 40

            items.append(WorkItem(
                table_a_fqn=c.table_a_fqn, table_b_fqn=c.table_b_fqn,
                a_columns=c.a_columns, b_columns=c.b_columns,
                is_composite=c.is_composite,
                priority_score=round(base, 4),
                priority_signals={
                    "query_count": c.query_count,
                    "sources": sorted(c.sources),
                    "lineage_prior": prior,
                },
                trigger_source="bootstrap",
            ))
        inserted = self.store.upsert_candidates(items)
        return {"parsed": stats.__dict__, "candidates": len(items), "newly_queued": inserted}

    # -- COLD START (no query history) -------------------------------------
    def seed_cold_lookups(self, cold_cfg=None) -> dict:
        """
        Second seeding path: discover never-queried relationships by detecting
        lookup/dimension tables and probing the sketch population via LSH.
        Reuses this pipeline's sketch cache so no column is sketched twice.
        Produced candidates flow into the SAME queue and pipeline.
        """
        from .cold_lookup_seeder import ColdLookupSeeder, ColdSeedConfig

        seeder = ColdLookupSeeder(self.compute, self.sketch,
                                  cold_cfg or ColdSeedConfig())

        # supplier closure: reuse the pipeline's sketch cache
        def supplier(table_fqn: str, column_key: str):
            return self._get_sketch(table_fqn, column_key)

        items = seeder.seed(supplier)
        inserted = self.store.upsert_candidates(items)
        return {"cold_candidates": len(items), "newly_queued": inserted}

    # -- STEADY STATE -------------------------------------------------------
    def run_discovery_batch(self, budget: int, lease_seconds: int = 3600) -> dict:
        run_id = str(uuid.uuid4())
        # reclaim any crashed work first
        reclaimed = self.store.reclaim_expired(lease_seconds)

        # compute current fingerprints for the tables in play
        fingerprints = self._fingerprints_for_runnable()

        claimed = self.store.claim_batch(run_id, budget, lease_seconds, fingerprints)
        results: list[EdgeResult] = []
        skipped = 0

        for item in claimed:
            try:
                edge = self._evaluate_pair(item, fingerprints)
                # stamp the fingerprints this pair was evaluated against, so a
                # later drift in either table re-opens it (is_runnable gate).
                self._stamp_eval_fingerprints(item, fingerprints)
                if edge is None:
                    self.store.update_status(item.work_id, "SKIPPED")
                    skipped += 1
                else:
                    results.append(edge)
                    self.store.update_status(item.work_id, "DONE")
            except Exception as e:  # noqa: BLE001
                logger.exception("pair eval failed")
                status = "DEAD" if item.attempt_count >= item.max_attempts else "FAILED"
                self.store.update_status(item.work_id, status, error=str(e))

        return {
            "run_id": run_id, "claimed": len(claimed), "edges": len(results),
            "skipped": skipped, "reclaimed": reclaimed, "results": results,
        }

    # -- per-pair evaluation: the passes ------------------------------------
    def _evaluate_pair(self, item: WorkItem, fingerprints: dict) -> EdgeResult | None:
        a_cols = list(item.a_columns)
        b_cols = list(item.b_columns)

        # ---- PASS 1/2: type + cardinality fence (BQ pushdown) ----
        self.store.update_status(item.work_id, "SKETCHING")
        pa = {p.column: p for p in self.compute.profile_columns(item.table_a_fqn, a_cols)}
        pb = {p.column: p for p in self.compute.profile_columns(item.table_b_fqn, b_cols)}

        # null fence
        if any(pa[c].null_fraction > self.cfg.max_null_fraction for c in a_cols):
            return None
        if any(pb[c].null_fraction > self.cfg.max_null_fraction for c in b_cols):
            return None
        # cardinality ratio fence (per column for composites)
        for ca, cb in zip(a_cols, b_cols):
            da, db = pa[ca].distinct_estimate, pb[cb].distinct_estimate
            if da == 0 or db == 0:
                return None
            ratio = max(da, db) / max(1, min(da, db))
            if ratio > self.cfg.max_cardinality_ratio:
                return None

        # ---- PASS 3: MinHash sketch + Jaccard (Spark) ----
        key_a = make_column_key(a_cols)
        key_b = make_column_key(b_cols)
        sig_a = self._get_sketch(item.table_a_fqn, key_a)
        sig_b = self._get_sketch(item.table_b_fqn, key_b)
        jaccard = self.sketch.estimate_jaccard(
            sig_a.signature_b64, sig_b.signature_b64, self.cfg.num_perm)

        if jaccard < self.cfg.jaccard_floor:
            # Jaccard too low to be worth an IND probe. Still record as weak if
            # there's strong name signal + lineage, else drop.
            name_sim = _name_similarity(a_cols, b_cols)
            lineage = float(item.priority_signals.get("lineage_prior", 0.0))
            soft = self.cfg.w_name * name_sim + self.cfg.w_lineage * lineage
            if soft < 0.30:
                return None

        # ---- PASS 4: IND containment probe (BQ pushdown) ----
        self.store.update_status(item.work_id, "PROBING")
        ind = self.compute.probe_inclusion(
            item.table_a_fqn, a_cols, item.table_b_fqn, b_cols,
            self.cfg.ind_sample_rows)
        ind_conf = max(ind.a_in_b, ind.b_in_a)

        # ---- PASS 5: LLM semantic score (STUB - next iteration) ----
        self.store.update_status(item.work_id, "SCORING")
        llm_score = 0.0  # folded out; weights renormalized below

        # ---- composite confidence ----
        name_sim = _name_similarity(a_cols, b_cols)
        lineage = float(item.priority_signals.get("lineage_prior", 0.0))
        conf = (self.cfg.w_jaccard * jaccard
                + self.cfg.w_ind * ind_conf
                + self.cfg.w_name * name_sim
                + self.cfg.w_lineage * lineage)
        conf = round(min(conf, 0.999), 5)

        return EdgeResult(
            table_a_fqn=item.table_a_fqn, table_b_fqn=item.table_b_fqn,
            a_columns=item.a_columns, b_columns=item.b_columns,
            is_composite=item.is_composite,
            jaccard=round(jaccard, 5), ind_confidence=round(ind_conf, 5),
            ind_direction=ind.direction, name_similarity=round(name_sim, 5),
            lineage_prior=round(lineage, 5),
            composite_confidence=conf, classification=_classify(conf, self.cfg),
            work_id=item.work_id,
        )

    # -- sketch reuse cache -------------------------------------------------
    def _get_sketch(self, table_fqn: str, column_key: str):
        ck = (table_fqn, column_key)
        if ck in self._sketch_cache:
            return self._sketch_cache[ck]
        res = self.sketch.build_sketches(
            table_fqn, [column_key], self.cfg.num_perm, self.cfg.distinct_cap)[0]
        self._sketch_cache[ck] = res
        return res

    def _fingerprints_for_runnable(self) -> dict[str, str]:
        fqns: set[str] = set()
        for it in self.store.all_items():
            fqns.add(it.table_a_fqn)
            fqns.add(it.table_b_fqn)
        return {f: self.compute.compute_data_fingerprint(f) for f in fqns}

    def _stamp_eval_fingerprints(self, item, fingerprints: dict[str, str]) -> None:
        """Record which table fingerprints this pair was evaluated against.
        The is_runnable gate compares live fingerprints to these to decide
        whether a CONFIRMED/REJECTED pair is stale and needs re-evaluation."""
        item.a_fingerprint_at_eval = fingerprints.get(item.table_a_fqn)
        item.b_fingerprint_at_eval = fingerprints.get(item.table_b_fqn)


# ---------------------------------------------------------------------------
# Incremental trigger handlers — all converge on the same queue + batch run
# ---------------------------------------------------------------------------
class TriggerHandlers:
    """
    Thin event handlers. In production these are invoked by Airflow tasks /
    SpringBoot events. They mutate the queue; they never run Spark directly.
    """
    def __init__(self, store: QueueStore, pipeline: DiscoveryPipeline):
        self.store = store
        self.pipeline = pipeline

    def on_new_table(self, new_fqn: str, candidate_pairs: list[WorkItem]) -> int:
        """A new table was onboarded; caller has already scoped its candidate
        counterparties (audit/vocab/anchor). Seed them as CANDIDATE."""
        for it in candidate_pairs:
            it.trigger_source = "new_table"
        return self.store.upsert_candidates(candidate_pairs)

    def on_data_drift(self, table_fqn: str) -> int:
        """A table's fingerprint changed. Re-open its CONFIRMED/REJECTED pairs
        for re-evaluation by flipping them back to QUEUED (the runnable view /
        is_runnable already gates on fingerprint mismatch, so simply nudging
        status is enough; here we count affected items)."""
        affected = 0
        for it in self.store.all_items():
            if table_fqn in (it.table_a_fqn, it.table_b_fqn):
                if it.status in ("DONE", "SKIPPED"):
                    it.status = "QUEUED"
                    affected += 1
        return affected

    def on_steward_verdict(self, work_id: str, verdict: str) -> None:
        """confirmed -> CONFIRMED, rejected -> REJECTED, deferred -> CANDIDATE."""
        mapping = {"confirmed": "CONFIRMED", "rejected": "REJECTED",
                   "deferred": "CANDIDATE"}
        self.store.set_lifecycle(work_id, mapping[verdict])

    def on_nomination(self, candidate_pairs: list[WorkItem],
                      by: str, budget: int = 50) -> dict:
        """Analyst nominates specific pairs; enqueue at high priority and run
        immediately (bypasses the scheduled cadence). A nomination FORCES
        re-evaluation even if the pair was previously settled — the analyst is
        explicitly asking for a fresh look."""
        for it in candidate_pairs:
            it.trigger_source = "nomination"
            it.triggered_by = by
            it.priority_score = max(it.priority_score, 1000.0)  # jump the queue
        self.store.upsert_candidates(candidate_pairs)
        # force-reopen any matching settled items (upsert is idempotent and
        # won't touch status, so we explicitly re-queue the nominated pairs)
        nominated_keys = {it.dedupe_key for it in candidate_pairs}
        for existing in self.store.all_items():
            if existing.dedupe_key in nominated_keys and existing.status in (
                    "DONE", "SKIPPED", "DEAD"):
                existing.status = "QUEUED"
                existing.priority_score = max(existing.priority_score, 1000.0)
                existing.lifecycle_state = "CANDIDATE"
        return self.pipeline.run_discovery_batch(budget=budget)
