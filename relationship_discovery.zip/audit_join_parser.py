"""
audit_join_parser.py
=====================
Bootstrap candidate-pair extraction from BigQuery audit logs.

The FIRST run of relationship discovery has no prior state. Instead of the
O(N^2) explosion of comparing every table against every other, we mine the
query history in INFORMATION_SCHEMA.JOBS_BY_ORGANIZATION (fallback:
JOBS_BY_PROJECT) and extract the JOIN predicates that analysts and pipelines
have *already written*. A multi-column JOIN condition is a human-authored
declaration that those columns relate those tables.

This module is pure parsing: query text in, candidate pairs out. It has no
BigQuery or Postgres dependency, so it is trivially unit-testable.

Extraction rules (v1):
  - Explicit equi-joins:  FROM a JOIN b ON a.col = b.col
  - Implicit equi-joins:  FROM a, b WHERE a.col = b.col
  - Column-to-column equality only (a.x = b.y); filters (a.x = 'CONST') ignored
  - Both sides must resolve to DISTINCT base tables (option i: no CTE flattening)
  - Multiple equalities between the same table pair in one query collapse into
    ONE composite candidate (ON a.x=b.x AND a.y=b.y -> composite, not 2 singles)
  - Self-joins (same table both sides) excluded
  - Unparseable queries are counted and skipped, never silently dropped
"""

from __future__ import annotations

import logging
from collections import defaultdict
from dataclasses import dataclass, field
from typing import Iterable

import sqlglot
from sqlglot import exp

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------
@dataclass(frozen=True)
class ColumnRef:
    """A fully-resolved column reference: which base table, which column."""
    table_fqn: str
    column: str


@dataclass
class CandidatePair:
    """
    A candidate relationship between two tables, with the column mapping the
    query author used to join them. Composite if >1 column pair.

    Canonical ordering: table_a_fqn < table_b_fqn lexicographically, with the
    column lists permuted to match. This guarantees that the same logical pair
    discovered from different queries dedupes to one row.
    """
    table_a_fqn: str
    table_b_fqn: str
    a_columns: tuple[str, ...]
    b_columns: tuple[str, ...]
    is_composite: bool
    # How many distinct queries produced this exact candidate (frequency weight)
    query_count: int = 1
    # Which predicate styles produced it (for provenance / confidence weighting)
    sources: frozenset[str] = field(default_factory=frozenset)

    @property
    def dedupe_key(self) -> tuple:
        return (self.table_a_fqn, self.table_b_fqn, self.a_columns, self.b_columns)


@dataclass
class ParseStats:
    """Telemetry so degradation is visible, not silent."""
    total_queries: int = 0
    parsed_ok: int = 0
    parse_failed: int = 0
    no_join_found: int = 0
    candidates_emitted: int = 0


# ---------------------------------------------------------------------------
# Alias resolution
# ---------------------------------------------------------------------------
def _build_alias_map(statement: exp.Expression) -> dict[str, str | None]:
    """
    Map every table alias (and bare table name) visible in the statement to its
    fully-qualified base-table name. CTE / derived-table aliases resolve to
    None (option i: we drop predicates that touch them rather than flatten).

    Returns: { alias_or_name (lowercased) : table_fqn or None }
    """
    alias_map: dict[str, str | None] = {}

    # Names defined by WITH clauses are CTEs -> not base tables -> None
    cte_names: set[str] = set()
    for cte in statement.find_all(exp.CTE):
        if cte.alias:
            cte_names.add(cte.alias.lower())

    for tbl in statement.find_all(exp.Table):
        # exp.Table.name is the table; .db / .catalog give dataset / project
        parts = [p for p in (tbl.catalog, tbl.db, tbl.name) if p]
        fqn = ".".join(parts) if parts else tbl.name
        name_key = tbl.name.lower() if tbl.name else None

        # The alias the query uses to reference this table, if any
        alias = tbl.alias_or_name.lower() if tbl.alias_or_name else name_key

        # If this "table" is actually a CTE reference, it is not a base table
        if name_key in cte_names:
            if alias:
                alias_map.setdefault(alias, None)
            continue

        if alias:
            alias_map[alias] = fqn
        if name_key:
            alias_map.setdefault(name_key, fqn)

    # Any alias that points at a CTE name is explicitly None
    for cte_name in cte_names:
        alias_map[cte_name] = None

    return alias_map


def _resolve(col: exp.Column, alias_map: dict[str, str | None]) -> ColumnRef | None:
    """
    Resolve a column expression to a ColumnRef against a base table.
    Returns None if the column has no table qualifier (ambiguous) or resolves
    to a CTE/derived alias.
    """
    tbl_alias = col.table.lower() if col.table else None
    if not tbl_alias:
        # Unqualified column (e.g. just `customer_id`) — ambiguous in a join
        # context, so we cannot safely attribute it. Drop.
        return None
    if tbl_alias not in alias_map:
        return None
    fqn = alias_map[tbl_alias]
    if fqn is None:  # CTE / derived — option (i) drops it
        return None
    return ColumnRef(table_fqn=fqn, column=col.name)


# ---------------------------------------------------------------------------
# Predicate extraction
# ---------------------------------------------------------------------------
def _is_col_to_col_eq(eq: exp.EQ) -> bool:
    """True only if both sides of the equality are column references."""
    return isinstance(eq.left, exp.Column) and isinstance(eq.right, exp.Column)


def _extract_equalities(
    statement: exp.Expression,
    alias_map: dict[str, str | None],
) -> list[tuple[ColumnRef, ColumnRef, str]]:
    """
    Pull every column-to-column equality from both JOIN...ON clauses and the
    WHERE clause. Returns list of (left_ref, right_ref, source_style).
    """
    out: list[tuple[ColumnRef, ColumnRef, str]] = []

    # --- Explicit: JOIN ... ON ---
    for join in statement.find_all(exp.Join):
        on = join.args.get("on")
        if on is None:
            continue
        for eq in on.find_all(exp.EQ):
            if not _is_col_to_col_eq(eq):
                continue
            l = _resolve(eq.left, alias_map)
            r = _resolve(eq.right, alias_map)
            if l and r and l.table_fqn != r.table_fqn:
                out.append((l, r, "explicit_join"))

    # --- Implicit: WHERE a.x = b.y (comma join) ---
    # We scan WHERE equalities; the distinct-table check naturally filters out
    # filters (a.x = 'CONST' is not col-to-col) and same-table predicates.
    for where in statement.find_all(exp.Where):
        for eq in where.find_all(exp.EQ):
            if not _is_col_to_col_eq(eq):
                continue
            l = _resolve(eq.left, alias_map)
            r = _resolve(eq.right, alias_map)
            if l and r and l.table_fqn != r.table_fqn:
                out.append((l, r, "implicit_where"))

    return out


def _equalities_to_pairs(
    equalities: list[tuple[ColumnRef, ColumnRef, str]],
) -> list[CandidatePair]:
    """
    Group equalities by the (unordered) table pair so that multiple join
    columns between the same two tables collapse into one composite candidate.
    Apply canonical ordering (table_a_fqn < table_b_fqn).
    """
    # group_key: frozenset({tableA, tableB}) -> list of (colA_ref, colB_ref, src)
    groups: dict[frozenset[str], list[tuple[ColumnRef, ColumnRef, str]]] = defaultdict(list)
    for l, r, src in equalities:
        groups[frozenset((l.table_fqn, r.table_fqn))].append((l, r, src))

    pairs: list[CandidatePair] = []
    for table_set, eqs in groups.items():
        t_a, t_b = sorted(table_set)  # canonical lexicographic order

        # Build column mapping in canonical orientation; dedupe identical col-pairs
        seen: set[tuple[str, str]] = set()
        a_cols: list[str] = []
        b_cols: list[str] = []
        sources: set[str] = set()
        for l, r, src in eqs:
            # orient so left maps to t_a, right to t_b
            if l.table_fqn == t_a:
                a_col, b_col = l.column, r.column
            else:
                a_col, b_col = r.column, l.column
            if (a_col, b_col) in seen:
                continue
            seen.add((a_col, b_col))
            a_cols.append(a_col)
            b_cols.append(b_col)
            sources.add(src)

        # Sort the column pairs together for a stable composite signature
        paired = sorted(zip(a_cols, b_cols))
        a_sorted = tuple(p[0] for p in paired)
        b_sorted = tuple(p[1] for p in paired)

        pairs.append(
            CandidatePair(
                table_a_fqn=t_a,
                table_b_fqn=t_b,
                a_columns=a_sorted,
                b_columns=b_sorted,
                is_composite=len(a_sorted) > 1,
                query_count=1,
                sources=frozenset(sources),
            )
        )
    return pairs


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------
def parse_query(query_text: str) -> list[CandidatePair]:
    """
    Parse a single BigQuery SQL string into candidate pairs.
    Raises nothing: on parse failure returns []. Caller tracks stats.
    """
    try:
        statement = sqlglot.parse_one(query_text, dialect="bigquery")
    except Exception as e:  # noqa: BLE001 - we want to swallow every parse error
        logger.debug("parse failed: %s", e)
        return []
    if statement is None:
        return []

    alias_map = _build_alias_map(statement)
    equalities = _extract_equalities(statement, alias_map)
    if not equalities:
        return []
    return _equalities_to_pairs(equalities)


def parse_audit_rows(
    rows: Iterable[dict],
    query_field: str = "query",
    count_field: str | None = "query_count",
) -> tuple[list[CandidatePair], ParseStats]:
    """
    Parse a batch of audit-log rows and aggregate candidate pairs across the
    whole corpus, summing query frequencies for identical candidates.

    rows: iterable of dicts, each having at least `query_field`. If `count_field`
          is present it is used as a per-query frequency weight; else 1.

    Returns (deduped_aggregated_pairs, stats).
    """
    stats = ParseStats()
    agg: dict[tuple, CandidatePair] = {}

    for row in rows:
        stats.total_queries += 1
        q = row.get(query_field)
        if not q:
            stats.parse_failed += 1
            continue
        weight = int(row.get(count_field, 1)) if count_field else 1

        pairs = parse_query(q)
        if pairs is None:
            stats.parse_failed += 1
            continue
        # parse_query returns [] both for "failed" and "no join". Disambiguate
        # cheaply: try a parse to classify (already done inside, so approximate).
        try:
            sqlglot.parse_one(q, dialect="bigquery")
            stats.parsed_ok += 1
        except Exception:  # noqa: BLE001
            stats.parse_failed += 1
            continue

        if not pairs:
            stats.no_join_found += 1
            continue

        for p in pairs:
            key = p.dedupe_key
            if key in agg:
                existing = agg[key]
                existing.query_count += weight
                existing.sources = existing.sources | p.sources
            else:
                p.query_count = weight
                agg[key] = p

    result = list(agg.values())
    stats.candidates_emitted = len(result)
    return result, stats
