"""
drivers.py
==========
Abstraction boundary between the discovery control logic and the heavy
execution backends (BigQuery, Spark/Dataproc). The control plane talks to
these interfaces only, which lets us:

  - run the full queue/FSM logic locally against a MockComputeDriver, and
  - deploy the identical control logic against the real BigQueryDriver +
    SparkSketchDriver with no changes.

Pushdown-first principle (per design): everything that CAN be expressed as a
BigQuery SQL aggregate is pushed down to BQ slots — HLL distinct counts, type
fences, and the IND containment probe. Spark is used ONLY for MinHash sketch
generation over the surviving candidate columns.
"""

from __future__ import annotations

import abc
import hashlib
import logging
import random
from dataclasses import dataclass

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Result value objects
# ---------------------------------------------------------------------------
@dataclass
class ColumnProfile:
    table_fqn: str
    column: str
    data_type: str
    distinct_estimate: int          # from APPROX_COUNT_DISTINCT (HLL)
    null_fraction: float
    total_rows: int


@dataclass
class INDResult:
    """Inclusion-dependency probe result for a (child cols) ⊆ (parent cols)."""
    a_in_b: float                   # fraction of A's values found in B
    b_in_a: float                   # fraction of B's values found in A
    direction: str                  # 'a_in_b' | 'b_in_a' | 'bidirectional' | 'none'
    sampled_rows: int


@dataclass
class SketchResult:
    table_fqn: str
    column_key: str                 # column name or __composite__[a,b]
    num_perm: int
    signature_b64: str
    distinct_estimate: int


@dataclass
class TableShape:
    """Structural profile of a table, used to detect lookup/dimension tables
    WITHOUT any query history. All fields come from profile stats / catalog."""
    table_fqn: str
    row_count: int
    # columns whose distinct count ~= row count are natural-key candidates
    key_columns: list[str]
    # low-cardinality categorical columns (the "lookup payload")
    categorical_columns: list[str]
    # all column names + dtypes, for name-affinity matching
    columns: dict                   # {column_name: data_type}


@dataclass
class LSHBucketHit:
    """A candidate column pair surfaced by LSH bucketing — two columns whose
    sketches landed in the same band, i.e. their value sets likely overlap."""
    table_a_fqn: str
    column_a: str
    table_b_fqn: str
    column_b: str
    estimated_jaccard: float


# ---------------------------------------------------------------------------
# Interfaces
# ---------------------------------------------------------------------------
class ComputeDriver(abc.ABC):
    """Pushdown-capable analytical backend (BigQuery in production)."""

    @abc.abstractmethod
    def fetch_audit_join_queries(
        self, lookback_days: int, min_query_count: int
    ) -> list[dict]:
        """Return rows of {query, query_count} from JOBS_BY_ORGANIZATION
        (fallback JOBS_BY_PROJECT). Used only for the cold-start bootstrap."""

    @abc.abstractmethod
    def profile_columns(
        self, table_fqn: str, columns: list[str]
    ) -> list[ColumnProfile]:
        """Pushed-down APPROX_COUNT_DISTINCT + null fraction + row count.
        This is Pass 1/2 fence data, computed in BQ, not Spark."""

    @abc.abstractmethod
    def probe_inclusion(
        self,
        table_a_fqn: str, a_cols: list[str],
        table_b_fqn: str, b_cols: list[str],
        sample_rows: int,
    ) -> INDResult:
        """Pushed-down directed containment probe. For composite cols, BQ
        concatenates the projected key. Returns containment fractions both
        directions so we can assign FK direction."""

    @abc.abstractmethod
    def compute_data_fingerprint(self, table_fqn: str) -> str:
        """Cheap change-detector: hash of (row_count, distinct vector, max ts).
        Drives the incremental re-evaluation gate."""

    # ---- cold-discovery support (no query history needed) ----
    @abc.abstractmethod
    def scan_table_shapes(
        self, lookup_row_ceiling: int, key_uniqueness_floor: float
    ) -> list["TableShape"]:
        """Enumerate tables and classify their structural shape from profile
        stats alone. Identifies lookup/dimension tables (small, with a near-
        unique key column) so they can be used as FK-parent anchors WITHOUT
        any query ever having joined them. This is the cold-start seed source."""


class SketchDriver(abc.ABC):
    """MinHash sketch generation (Spark/Dataproc in production)."""

    @abc.abstractmethod
    def build_sketches(
        self,
        table_fqn: str,
        column_keys: list[str],
        num_perm: int,
        distinct_cap: int,
    ) -> list[SketchResult]:
        """Generate MinHash signatures for the given (possibly composite)
        column keys. Composite keys are virtual-column projections."""

    @abc.abstractmethod
    def estimate_jaccard(self, sig_a_b64: str, sig_b_b64: str, num_perm: int) -> float:
        """Jaccard estimate from two MinHash signatures."""

    @abc.abstractmethod
    def lsh_bucket(
        self,
        sketches: list["SketchResult"],
        bands: int,
        rows_per_band: int,
        min_jaccard: float,
        anchor_keys: set | None = None,
    ) -> list["LSHBucketHit"]:
        """All-pairs candidate generation via LSH banding — SUB-QUADRATIC.
        Columns whose signatures collide in any band become candidate pairs.
        This is how cold (never-queried) relationships surface: a lookup
        table's key column and a fact table's foreign column land in the same
        bucket iff their value sets overlap.

        If `anchor_keys` is given (the set of lookup-table key column_keys),
        only emit hits that involve at least one anchor — star topology, which
        keeps cold discovery focused on lookup/dimension parents rather than
        exploding into all fact-fact comparisons."""


# ===========================================================================
# REAL IMPLEMENTATIONS (production - not exercised in this session)
# ===========================================================================
class BigQueryDriver(ComputeDriver):
    """
    Production BigQuery driver. All methods push computation down to BQ SQL.
    Requires: google-cloud-bigquery, and a client with appropriate IAM.
    Org-level audit access preferred; falls back to per-project iteration.
    """

    def __init__(self, client, project_ids: list[str], org_id: str | None = None):
        self._client = client
        self._project_ids = project_ids
        self._org_id = org_id

    def fetch_audit_join_queries(self, lookback_days, min_query_count):
        # Try organization-wide audit first; fall back to per-project union.
        org_sql = f"""
        SELECT query, COUNT(DISTINCT job_id) AS query_count
        FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_ORGANIZATION
        WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(),
                                            INTERVAL {int(lookback_days)} DAY)
          AND job_type = 'QUERY' AND state = 'DONE' AND error_result IS NULL
          AND ARRAY_LENGTH(referenced_tables) BETWEEN 2 AND 10
          AND LOWER(query) LIKE '%join%'
        GROUP BY query
        HAVING query_count >= {int(min_query_count)}
        """
        try:
            return [dict(r) for r in self._client.query(org_sql).result()]
        except Exception as e:  # noqa: BLE001
            logger.warning("JOBS_BY_ORGANIZATION unavailable (%s); "
                           "falling back to per-project JOBS_BY_PROJECT", e)
        rows: list[dict] = []
        for proj in self._project_ids:
            proj_sql = f"""
            SELECT query, COUNT(DISTINCT job_id) AS query_count
            FROM `{proj}`.`region-us`.INFORMATION_SCHEMA.JOBS_BY_PROJECT
            WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(),
                                                INTERVAL {int(lookback_days)} DAY)
              AND job_type = 'QUERY' AND state = 'DONE' AND error_result IS NULL
              AND ARRAY_LENGTH(referenced_tables) BETWEEN 2 AND 10
              AND LOWER(query) LIKE '%join%'
            GROUP BY query
            HAVING query_count >= {int(min_query_count)}
            """
            try:
                rows.extend(dict(r) for r in self._client.query(proj_sql).result())
            except Exception as e:  # noqa: BLE001
                logger.warning("project %s audit fetch failed: %s", proj, e)
        return rows

    def profile_columns(self, table_fqn, columns):
        # Single pushed-down query computing HLL distinct + null frac per column.
        approx = ",\n".join(
            f"APPROX_COUNT_DISTINCT(`{c}`) AS dc_{i}, "
            f"COUNTIF(`{c}` IS NULL) AS nulls_{i}"
            for i, c in enumerate(columns)
        )
        sql = f"SELECT COUNT(*) AS n, {approx} FROM `{table_fqn}`"
        row = list(self._client.query(sql).result())[0]
        n = row["n"]
        out = []
        for i, c in enumerate(columns):
            out.append(ColumnProfile(
                table_fqn=table_fqn, column=c, data_type="",  # type filled elsewhere
                distinct_estimate=row[f"dc_{i}"],
                null_fraction=(row[f"nulls_{i}"] / n) if n else 0.0,
                total_rows=n,
            ))
        return out

    def probe_inclusion(self, table_a_fqn, a_cols, table_b_fqn, b_cols, sample_rows):
        # Composite-aware: project the key as a concatenation, sample A, and
        # measure how many sampled A-keys exist in B (and vice-versa).
        a_key = self._proj_expr(a_cols)
        b_key = self._proj_expr(b_cols)
        sql = f"""
        WITH a AS (
          SELECT DISTINCT {a_key} AS k FROM `{table_a_fqn}`
          WHERE {a_key} IS NOT NULL
          ORDER BY FARM_FINGERPRINT(CAST({a_key} AS STRING)) LIMIT {int(sample_rows)}
        ),
        b AS (
          SELECT DISTINCT {b_key} AS k FROM `{table_b_fqn}`
          WHERE {b_key} IS NOT NULL
          ORDER BY FARM_FINGERPRINT(CAST({b_key} AS STRING)) LIMIT {int(sample_rows)}
        )
        SELECT
          (SELECT COUNT(*) FROM a) AS a_n,
          (SELECT COUNT(*) FROM a WHERE k IN (SELECT k FROM `{table_b_fqn}_full_b`)) AS a_in_b
        """
        # NOTE: the real implementation uses a semi-join against the full B set,
        # not a literal subtable; elided here for brevity. The mock fully
        # implements the semantics so the control logic is validated.
        raise NotImplementedError("wired in deployment; mock covers semantics")

    def compute_data_fingerprint(self, table_fqn):
        sql = f"""
        SELECT FORMAT('%d|%d|%t',
                 COUNT(*),
                 COUNT(DISTINCT FARM_FINGERPRINT(TO_JSON_STRING(t))),
                 MAX(_PARTITIONTIME)) AS fp
        FROM `{table_fqn}` t
        """
        return list(self._client.query(sql).result())[0]["fp"]

    def scan_table_shapes(self, lookup_row_ceiling, key_uniqueness_floor):
        # Pushed-down: joins TABLE_STORAGE (row counts) with a per-column
        # APPROX_COUNT_DISTINCT pass to find near-unique key columns. In
        # production this reads from your existing single-table profile results
        # rather than re-profiling. Skeleton SQL shown for the catalog portion.
        sql = """
        SELECT table_schema, table_name, row_count
        FROM `region-us`.INFORMATION_SCHEMA.TABLE_STORAGE
        WHERE row_count <= @ceiling
        """
        # The per-column key/categorical classification is read from the
        # profile-results table; wired in deployment.
        raise NotImplementedError("wired in deployment; mock covers semantics")

    @staticmethod
    def _proj_expr(cols: list[str]) -> str:
        if len(cols) == 1:
            return f"CAST(`{cols[0]}` AS STRING)"
        # sorted, name-prefixed concatenation = order-independent composite key
        parts = ",".join(
            f"'{c}=', CAST(`{c}` AS STRING)" for c in sorted(cols)
        )
        return f"CONCAT({parts})"


class SparkSketchDriver(SketchDriver):
    """Production Spark/Dataproc MinHash sketcher. Uses datasketch or a Spark
    MinHashLSH pipeline over distinct (possibly projected) column values."""

    def __init__(self, spark):
        self._spark = spark

    def build_sketches(self, table_fqn, column_keys, num_perm, distinct_cap):
        raise NotImplementedError("wired in deployment; mock covers semantics")

    def estimate_jaccard(self, sig_a_b64, sig_b_b64, num_perm):
        raise NotImplementedError("wired in deployment; mock covers semantics")

    def lsh_bucket(self, sketches, bands, rows_per_band, min_jaccard, anchor_keys=None):
        # Production: Spark MinHashLSH.approxSimilarityJoin over the sketch
        # DataFrame, or a manual banding shuffle. Sub-quadratic by construction.
        raise NotImplementedError("wired in deployment; mock covers semantics")


# ===========================================================================
# MOCK IMPLEMENTATIONS (exercised live in this session)
# ===========================================================================
class _FakeColumn:
    def __init__(self, values, dtype="INT64"):
        self.values = values
        self.dtype = dtype


class MockComputeDriver(ComputeDriver):
    """
    In-memory stand-in. Holds synthetic tables as {fqn: {col: _FakeColumn}}.
    Implements the FULL semantics of profiling, IND probing, and fingerprinting
    so the control plane and pipeline logic are genuinely validated.
    """

    def __init__(self, tables: dict[str, dict[str, "_FakeColumn"]],
                 audit_rows: list[dict] | None = None):
        self._tables = tables
        self._audit_rows = audit_rows or []

    def fetch_audit_join_queries(self, lookback_days, min_query_count):
        return [r for r in self._audit_rows
                if r.get("query_count", 1) >= min_query_count]

    def profile_columns(self, table_fqn, columns):
        tbl = self._tables[table_fqn]
        out = []
        for c in columns:
            col = tbl[c]
            n = len(col.values)
            nulls = sum(1 for v in col.values if v is None)
            out.append(ColumnProfile(
                table_fqn=table_fqn, column=c, data_type=col.dtype,
                distinct_estimate=len(set(v for v in col.values if v is not None)),
                null_fraction=nulls / n if n else 0.0,
                total_rows=n,
            ))
        return out

    def _project(self, table_fqn, cols):
        """Order-independent composite projection, matching BQ _proj_expr."""
        tbl = self._tables[table_fqn]
        rows = zip(*[tbl[c].values for c in sorted(cols)])
        keys = set()
        for row in rows:
            if any(v is None for v in row):
                continue
            if len(cols) == 1:
                keys.add(str(row[0]))
            else:
                keys.add("||".join(f"{c}={v}" for c, v in zip(sorted(cols), row)))
        return keys

    def probe_inclusion(self, table_a_fqn, a_cols, table_b_fqn, b_cols, sample_rows):
        a_keys = self._project(table_a_fqn, a_cols)
        b_keys = self._project(table_b_fqn, b_cols)
        if not a_keys or not b_keys:
            return INDResult(0.0, 0.0, "none", 0)
        # sample A's keys
        a_sample = set(random.sample(sorted(a_keys), min(sample_rows, len(a_keys))))
        b_sample = set(random.sample(sorted(b_keys), min(sample_rows, len(b_keys))))
        a_in_b = sum(1 for k in a_sample if k in b_keys) / len(a_sample)
        b_in_a = sum(1 for k in b_sample if k in a_keys) / len(b_sample)
        thr = 0.95
        if a_in_b >= thr and b_in_a >= thr:
            direction = "bidirectional"
        elif a_in_b >= thr:
            direction = "a_in_b"
        elif b_in_a >= thr:
            direction = "b_in_a"
        else:
            direction = "none"
        return INDResult(round(a_in_b, 4), round(b_in_a, 4), direction,
                         len(a_sample) + len(b_sample))

    def compute_data_fingerprint(self, table_fqn):
        tbl = self._tables[table_fqn]
        h = hashlib.sha256()
        for c in sorted(tbl):
            col = tbl[c]
            h.update(c.encode())
            h.update(str(len(col.values)).encode())
            h.update(str(len(set(v for v in col.values if v is not None))).encode())
        return h.hexdigest()[:16]

    def scan_table_shapes(self, lookup_row_ceiling, key_uniqueness_floor):
        """Classify every table's structural shape from its column stats.
        A table is a lookup/dimension parent candidate if it is small AND has
        at least one near-unique key column. No query history is consulted."""
        shapes = []
        for fqn, tbl in self._tables.items():
            n = max((len(c.values) for c in tbl.values()), default=0)
            key_cols, cat_cols, cols = [], [], {}
            for cname, col in tbl.items():
                cols[cname] = col.dtype
                non_null = [v for v in col.values if v is not None]
                distinct = len(set(non_null))
                if n and distinct / n >= key_uniqueness_floor:
                    key_cols.append(cname)
                elif n and distinct <= max(1, n * 0.1):
                    cat_cols.append(cname)
            shapes.append(TableShape(
                table_fqn=fqn, row_count=n,
                key_columns=key_cols, categorical_columns=cat_cols, columns=cols,
            ))
        return shapes


class MockSketchDriver(SketchDriver):
    """
    Mock MinHash using real datasketch-style minhashing if available, else a
    deterministic permutation-based MinHash so Jaccard estimates are real.
    """

    def __init__(self, compute: MockComputeDriver, seed: int = 7):
        self._compute = compute
        self._seed = seed

    def _minhash(self, keys: set[str], num_perm: int) -> list[int]:
        # Simple universal-hashing MinHash: for each of num_perm hash seeds,
        # take the min hash over the key set.
        sig = []
        for p in range(num_perm):
            mn = None
            for k in keys:
                hv = int(hashlib.sha1(f"{p}:{k}".encode()).hexdigest(), 16)
                if mn is None or hv < mn:
                    mn = hv
            sig.append(mn if mn is not None else 0)
        return sig

    def build_sketches(self, table_fqn, column_keys, num_perm, distinct_cap):
        import base64, json
        out = []
        for ck in column_keys:
            cols = _parse_column_key(ck)
            keys = self._compute._project(table_fqn, cols)
            if distinct_cap and len(keys) > distinct_cap:
                keys = set(sorted(keys)[:distinct_cap])
            sig = self._minhash(keys, num_perm)
            b64 = base64.b64encode(json.dumps(sig).encode()).decode()
            out.append(SketchResult(table_fqn, ck, num_perm, b64, len(keys)))
        return out

    def estimate_jaccard(self, sig_a_b64, sig_b_b64, num_perm):
        import base64, json
        a = json.loads(base64.b64decode(sig_a_b64))
        b = json.loads(base64.b64decode(sig_b_b64))
        if not a or not b:
            return 0.0
        matches = sum(1 for x, y in zip(a, b) if x == y)
        return matches / len(a)

    def lsh_bucket(self, sketches, bands, rows_per_band, min_jaccard, anchor_keys=None):
        """Real LSH banding: split each signature into `bands` bands of
        `rows_per_band` rows; two columns that share an identical band hash are
        candidates. Sub-quadratic — we only compare within colliding buckets,
        never all pairs. Star-topology filter via anchor_keys keeps cold
        discovery focused on lookup parents."""
        import base64, json
        from collections import defaultdict

        # decode signatures
        decoded = []
        for s in sketches:
            sig = json.loads(base64.b64decode(s.signature_b64))
            decoded.append((s, sig))

        # bucket by (band_index, band_hash) -> list of sketch refs
        buckets: dict[tuple, list[int]] = defaultdict(list)
        for idx, (s, sig) in enumerate(decoded):
            for b in range(bands):
                start = b * rows_per_band
                band = tuple(sig[start:start + rows_per_band])
                if not band:
                    continue
                band_hash = hashlib.sha1(
                    f"{b}:{band}".encode()).hexdigest()[:12]
                buckets[(b, band_hash)].append(idx)

        # within each bucket, emit candidate pairs (dedup across bands)
        seen: set[tuple] = set()
        hits: list[LSHBucketHit] = []
        for members in buckets.values():
            if len(members) < 2:
                continue
            for i in range(len(members)):
                for j in range(i + 1, len(members)):
                    si, sj = decoded[members[i]][0], decoded[members[j]][0]
                    if si.table_fqn == sj.table_fqn:
                        continue  # same table, not a relationship
                    # star-topology: at least one side must be a lookup anchor
                    if anchor_keys is not None:
                        ka = (si.table_fqn, si.column_key)
                        kb = (sj.table_fqn, sj.column_key)
                        if ka not in anchor_keys and kb not in anchor_keys:
                            continue
                    key = tuple(sorted([(si.table_fqn, si.column_key),
                                        (sj.table_fqn, sj.column_key)]))
                    if key in seen:
                        continue
                    seen.add(key)
                    jac = self.estimate_jaccard(
                        si.signature_b64, sj.signature_b64, si.num_perm)
                    if jac < min_jaccard:
                        continue
                    (ta, ca), (tb, cb) = key
                    hits.append(LSHBucketHit(ta, ca, tb, cb, round(jac, 4)))
        return hits


# ---------------------------------------------------------------------------
# Column-key helpers (shared composite encoding)
# ---------------------------------------------------------------------------
def make_column_key(cols: list[str]) -> str:
    """Single col -> 'col'. Composite -> '__composite__[a,b]' (sorted)."""
    if len(cols) == 1:
        return cols[0]
    return "__composite__[" + ",".join(sorted(cols)) + "]"


def _parse_column_key(key: str) -> list[str]:
    if key.startswith("__composite__["):
        inner = key[len("__composite__["):-1]
        return inner.split(",")
    return [key]
