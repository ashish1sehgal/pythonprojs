-- =============================================================================
-- profiler_run_metrics_with_ci  (CREATE OR REPLACE)
--
-- Extends the base profiler_run_metrics table with four families of
-- computed columns — none of which are stored physically:
--
--   1. Mean CI           x̄ ± 1.96 · σ/√n  (95 % confidence interval)
--   2. Stddev CI         chi-squared critical values from chi2_critical_values
--   3. Skewness          μ₃ / σ³            (population, from power sums)
--   4. Excess kurtosis   μ₄ / σ⁴ − 3        (population, from power sums)
--
-- Power-sum derivation chain (CTEs)
-- -----------------------------------
-- The raw power sums (sum_x … sum_x4) are stored in profiler_run_metrics as
-- regular stat columns for numeric columns only; they are NULL for string /
-- date / boolean columns.
--
-- Step 1  Raw moments about zero
--         m₁ = S₁/n,  m₂ = S₂/n,  m₃ = S₃/n,  m₄ = S₄/n
--         Cast to NUMERIC before division — power sums can reach ≈10³³ on
--         billion-row tables, which exceeds float8's ~15 significant digits.
--         Subtracting nearly-equal large numbers in float8 causes catastrophic
--         cancellation.  NUMERIC is arbitrary-precision in Postgres so the
--         computation is exact.
--
-- Step 2  Central moments  (standard binomial expansion of (xᵢ − μ)ᵏ)
--         μ₂ = m₂ − m₁²
--         μ₃ = m₃ − 3·m₂·m₁ + 2·m₁³
--         μ₄ = m₄ − 4·m₃·m₁ + 6·m₂·m₁² − 3·m₁⁴
--
-- Step 3  Standardise
--         σ²  = μ₂
--         σ⁴  = μ₂²        (avoids a redundant SQRT)
--         skewness        = μ₃ / POWER(μ₂, 1.5)
--         excess_kurtosis = μ₄ / POWER(μ₂, 2) − 3
--
-- Guard conditions  →  NULL, not error
--   • sum_x IS NULL          non-numeric column, no power sums available
--   • total_rows < 3         too few observations for a stable estimate
--   • μ₂ ≤ 0                 constant column (zero variance) or numeric artefact
--
-- The internal columns (_m1 … _mu4) and the raw power sums are excluded
-- from the final projection — architecture constraint §6 prohibits exposing
-- power sums in user-facing queries.
-- =============================================================================

CREATE OR REPLACE VIEW dp.profiler_run_metrics_with_ci AS

WITH

-- ── Step 1: raw moments about zero ──────────────────────────────────────────
raw_moments AS (
    SELECT
        m.*,
        -- NUMERIC cast preserves full precision; sum_x is NULL for
        -- non-numeric columns so all _m* will be NULL there too.
        m.sum_x ::NUMERIC / NULLIF(m.total_rows, 0)  AS _m1,
        m.sum_x2::NUMERIC / NULLIF(m.total_rows, 0)  AS _m2,
        m.sum_x3::NUMERIC / NULLIF(m.total_rows, 0)  AS _m3,
        m.sum_x4::NUMERIC / NULLIF(m.total_rows, 0)  AS _m4
    FROM dp.profiler_run_metrics m
),

-- ── Step 2: central moments ──────────────────────────────────────────────────
central_moments AS (
    SELECT
        r.*,
        (_m2 - _m1^2)                                         AS _mu2,
        (_m3 - 3*_m2*_m1   + 2*_m1^3)                        AS _mu3,
        (_m4 - 4*_m3*_m1   + 6*_m2*_m1^2   - 3*_m1^4)       AS _mu4
    FROM raw_moments r
),

-- ── Step 3: join chi-squared critical values for stddev CI ──────────────────
-- chi2_critical_values is seeded once at deployment by ci_view_utils.
ci_base AS (
    SELECT
        c.*,
        cv.lower_factor,
        cv.upper_factor
    FROM central_moments c
    LEFT JOIN dp.chi2_critical_values cv
           ON cv.df = GREATEST(c.total_rows - 1, 1)
)

-- ── Final projection ─────────────────────────────────────────────────────────
SELECT

    -- identifiers
    run_id,
    column_name,
    data_type,
    total_rows,

    -- descriptive stats
    empty_count,
    distinct_count,
    distinct_pattern_count,
    mean_value,
    stddev_value,
    min_val,
    max_val,

    -- percentiles
    p25, p50, p75, p90, p95, p99,

    -- ── Mean 95 % CI:  x̄ ± 1.96 · σ/√n ─────────────────────────────────────
    -- Uses stored stddev_value (computed via VAR_POP/STDDEV_POP in Pass 1).
    -- Mean CI is numerically stable with float arithmetic — no NUMERIC needed.
    CASE
        WHEN total_rows > 0
         AND stddev_value IS NOT NULL
        THEN (  mean_value::NUMERIC
              - 1.96 * (stddev_value::NUMERIC / SQRT(total_rows::NUMERIC))
             )::double precision
    END AS mean_ci_lower,

    CASE
        WHEN total_rows > 0
         AND stddev_value IS NOT NULL
        THEN (  mean_value::NUMERIC
              + 1.96 * (stddev_value::NUMERIC / SQRT(total_rows::NUMERIC))
             )::double precision
    END AS mean_ci_upper,

    -- ── Stddev 95 % CI from chi-squared critical values ───────────────────────
    --   lower = σ · √( (n-1) / χ²_{α/2} )   expressed as a pre-computed factor
    --   upper = σ · √( (n-1) / χ²_{1-α/2} )
    CASE
        WHEN total_rows > 1
         AND stddev_value IS NOT NULL
         AND lower_factor IS NOT NULL
        THEN (stddev_value * lower_factor)::double precision
    END AS stddev_ci_lower,

    CASE
        WHEN total_rows > 1
         AND stddev_value IS NOT NULL
         AND upper_factor IS NOT NULL
        THEN (stddev_value * upper_factor)::double precision
    END AS stddev_ci_upper,

    -- ── Skewness  =  μ₃ / σ³  ────────────────────────────────────────────────
    --
    -- σ³ = POWER(σ², 1.5) = POWER(μ₂, 1.5)
    --
    -- Interpretation:
    --   skewness ≈ 0   symmetric distribution
    --   skewness > 0   right tail is longer (positive skew)
    --   skewness < 0   left  tail is longer (negative skew)
    --
    -- NULL when:
    --   • _mu2 IS NULL   → non-numeric column (no power sums in profiler_run_metrics)
    --   • total_rows < 3 → too few points; skewness estimate is unreliable
    --   • _mu2 ≤ 0       → constant column; σ = 0 → division undefined
    CASE
        WHEN total_rows >= 3
         AND _mu2 IS NOT NULL
         AND _mu2  > 0
        THEN (_mu3 / POWER(_mu2, 1.5))::double precision
    END AS skewness,

    -- ── Excess kurtosis  =  μ₄ / σ⁴ − 3  ────────────────────────────────────
    --
    -- σ⁴ = (σ²)² = μ₂²   (POWER(μ₂, 2) avoids a redundant SQRT)
    --
    -- Interpretation:
    --   excess_kurtosis ≈ 0   normal (mesokurtic)
    --   excess_kurtosis > 0   heavier tails than normal (leptokurtic)
    --   excess_kurtosis < 0   lighter tails than normal (platykurtic)
    --
    -- NULL under the same guard conditions as skewness above.
    CASE
        WHEN total_rows >= 3
         AND _mu2 IS NOT NULL
         AND _mu2  > 0
        THEN (_mu4 / POWER(_mu2, 2))::double precision - 3
    END AS excess_kurtosis,

    -- ── Normality test results (Pass 4) ──────────────────────────────────────
    normality_method,
    normality_statistic,
    normality_p_value,
    normality_critical_val,
    normality_is_normal,
    normality_result,
    normality_sample_n

    -- sum_x, sum_x2, sum_x3, sum_x4 and the _m* / _mu* intermediates are
    -- deliberately excluded from this projection.  Architecture constraint §6:
    -- power sums are internal computation aids and must never appear in
    -- user-facing queries or be stored in profiler_run_metrics.

FROM ci_base;

-- Grant read access to the application role (adjust role name as needed)
-- GRANT SELECT ON dp.profiler_run_metrics_with_ci TO profiler_app_role;

COMMENT ON VIEW dp.profiler_run_metrics_with_ci IS
'Extends profiler_run_metrics with computed CI and moment columns.
 Mean CI      : x̄ ± 1.96·σ/√n (95%).
 Stddev CI    : chi-squared critical values (chi2_critical_values table).
 Skewness     : μ₃/σ³  — population statistic from stored power sums.
 Kurtosis     : μ₄/σ⁴−3 — excess kurtosis, 0 for a normal distribution.
 Power sums (sum_x…sum_x4) and all intermediate columns are excluded.';
