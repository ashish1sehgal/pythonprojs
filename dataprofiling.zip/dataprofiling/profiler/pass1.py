"""Pass 1 — full-population DB pushdown.  All JSON-pack platforms return Shape B
(one row per profiled column, one column per stat) directly from the DB.

Shape B
-------
    total_rows | column_name | avg  | min_val | max_val | distinct_count | p25  | ...
    1000000    | cust_id     | 42.5 | 1.0     | 100.0   | 94821          | 25.0 | ...
    1000000    | created_ts  | NULL | 2023-01 | 2024-12 | 12             | NULL | ...

One UNPIVOT (not two) is needed per JSON-pack platform to reach this shape:

    wide JSON columns
      → UNPIVOT           →  (col_name, json_val) one row per column
      → JSON_VALUE / ->>  →  Shape B wide stat columns

This avoids the previous "double-UNPIVOT then re-pivot" cycle:
  double-UNPIVOT → Shape A (long) → Spark pivot → Shape B

Platform strategies
-------------------
BQ
    Single UNPIVOT converts JSON columns → (col, val) rows.
    JSON_VALUE(val, '$.stat') extracts each stat to its own column.

    SELECT total_rows, col AS column_name,
           JSON_VALUE(val, '$.avg') AS avg, ...
    FROM (SELECT COUNT(*) AS total_rows,
            TO_JSON_STRING(STRUCT(AVG(c) AS avg, ...)) AS `c`, ... FROM tbl)
    UNPIVOT(val FOR col IN (`col1`, `col2`, ...))

Postgres
    Single UNPIVOT via UNION ALL branches using the ->> JSON field operator.
    One branch per column, CTE materialized once.

    WITH profile_data AS MATERIALIZED (SELECT ..., json_build_object(...) AS "c" FROM tbl)
    SELECT total_rows, 'c' AS column_name, "c" ->> 'avg' AS avg, ...
    FROM profile_data
    UNION ALL ...

Oracle
    Same UNION ALL branch pattern using JSON_VALUE per column.

    WITH profile_data AS (SELECT /*+ MATERIALIZE */ ..., JSON_OBJECT(...) AS "c" FROM tbl)
    SELECT total_rows, 'c' AS column_name, JSON_VALUE("c", '$.avg') AS avg, ...
    FROM profile_data
    UNION ALL ...

MySQL / SingleStore
    Flat col__stat aliases (wide, 1 row).  _wide_from_flat() pivots to Shape B in Spark.
"""

from pyspark.sql import SparkSession, DataFrame, functions as F

from .constants import JSON_PACK_PLATFORMS
from .dialect import render_stat


# ---------------------------------------------------------------------------
# SQL helpers shared by all JSON-pack platforms
# ---------------------------------------------------------------------------

def _json_kv(platform: str, stat: str, sql_expr: str) -> str:
    """One key-value pair inside the platform's JSON aggregate function."""
    if platform == "BQ":
        return f"{sql_expr} AS {stat}"
    if platform == "ORACLE":
        return f"'{stat}' VALUE {sql_expr}"
    return f"'{stat}', {sql_expr}"   # POSTGRES


def _json_wrap(platform: str, pairs: list[str], col_alias: str) -> str:
    """Per-column JSON aggregate expression, quoted so reserved words are safe."""
    inner = ", ".join(pairs)
    if platform == "BQ":
        return f"to_json_string(STRUCT({inner})) AS `{col_alias}`"
    if platform == "ORACLE":
        return f'JSON_OBJECT({inner} NULL ON NULL RETURNING CLOB) AS "{col_alias}"'
    return f'json_build_object({inner}) AS "{col_alias}"'   # POSTGRES


# ---------------------------------------------------------------------------
# Dependency expansion
# ---------------------------------------------------------------------------

def expand_selected_stats(
    selected_stats: list[str],
    pass1_stats: list[str],
    dependencies: dict[str, list[str]],
) -> list[str]:
    """Expand a column's selectedStats to include all transitive prerequisites.

    Derived stats (skewness, excess_kurtosis) have no SQL template of their
    own — the Postgres view computes them from power sums.  When the user
    selects such a stat, this function automatically adds the prerequisite
    stats that DO have SQL templates so Pass 1 produces the right columns.

    Example
    -------
    User selects: ["empty_count", "skewness"]
    dependencies: {"skewness": ["sum_x","sum_x2","sum_x3","sum_x4","mean_value"]}

    Expanded: ["empty_count", "skewness",          ← kept (skewness has no SQL, skipped later)
               "sum_x","sum_x2","sum_x3","sum_x4", ← auto-added
               "mean_value"]                        ← auto-added

    The expansion is transitive (BFS) so multi-level prerequisite chains
    are resolved correctly.  Only stats that appear in pass1_stats are
    included in the result.
    """
    pass1_set = set(pass1_stats)
    expanded: list[str] = []
    seen: set[str] = set()
    queue: list[str] = list(selected_stats)

    while queue:
        stat = queue.pop(0)
        if stat in seen:
            continue
        seen.add(stat)
        if stat in pass1_set:
            expanded.append(stat)
        # Always chase dependencies even for stats not in pass1_set, in case
        # the user referenced a derived stat by name.
        for prereq in dependencies.get(stat, []):
            if prereq not in seen:
                queue.append(prereq)

    return expanded


# ---------------------------------------------------------------------------
# Public SQL builder
# ---------------------------------------------------------------------------

def build_pass1_sql(
    target_table: str,
    batch_cols: list[dict],
    dialect: dict,
    platform: str,
    pass1_stats: list[str],
    execution_tier: str,
    dependencies: dict[str, list[str]] | None = None,
) -> str | None:
    """Generates the Pass-1 aggregate SQL for one batch of columns.

    If `dependencies` is provided, any derived stat in selectedStats
    (e.g. "skewness", "excess_kurtosis") automatically pulls in its
    prerequisite stats (power sums, mean_value) via expand_selected_stats().
    Stats with no SQL template (the derived stats themselves) are silently
    skipped — the view computes them from the stored prerequisites.

    JSON-pack platforms (BQ / Oracle / Postgres): returns a single SQL
    statement whose result is Shape B — one row per column with each stat
    as its own column.

    MySQL / SingleStore: returns a wide SELECT with col__stat aliases;
    to_wide_df() / _wide_from_flat() converts to Shape B in Spark.

    Returns None when no stats survive the pass1_stats / dialect filter.
    """
    deps = dependencies or {}
    use_json = platform in JSON_PACK_PLATFORMS
    top_exprs: list[str] = ["COUNT(*) AS total_rows"]
    pii_decrypt_cols: list[str] = []
    pii_except_cols: list[str] = []

    # {col_name: [stat_name, ...]} — built only for JSON-pack platforms.
    json_col_stats: dict[str, list[str]] = {}

    for col in batch_cols:
        c = col["attributeName"]
        tag = col.get("sensitiveTag")
        if tag:
            pii_decrypt_cols.append(f"axp-lumi.dw.decrypt_sde('{tag}', {c}) AS {c}")
            pii_except_cols.append(c)

        stat_pairs: list[str] = []
        col_stat_names: list[str] = []

        # Expand selectedStats to include prerequisites of derived stats.
        effective_stats = expand_selected_stats(
            col.get("selectedStats", []), pass1_stats, deps
        )

        for stat in effective_stats:
            if (
                stat == "distinct_count"
                and execution_tier == "COMPLIANCE"
                and col.get("force_exact_distinct")
            ):
                sql_expr = f"COUNT(DISTINCT {c})"
            else:
                sql_expr = render_stat(stat, c, dialect)
            # Derived stats (skewness, kurtosis) have no SQL template — skip.
            if not sql_expr:
                continue

            if use_json:
                stat_pairs.append(_json_kv(platform, stat, sql_expr))
                col_stat_names.append(stat)
            else:
                top_exprs.append(f"{sql_expr} AS {c}__{stat}")

        if use_json and stat_pairs:
            top_exprs.append(_json_wrap(platform, stat_pairs, c))
            json_col_stats[c] = col_stat_names

    if len(top_exprs) == 1:
        return None

    if pii_decrypt_cols:
        source = (
            f"(SELECT * EXCEPT ({', '.join(pii_except_cols)}), "
            f"{', '.join(pii_decrypt_cols)} FROM {target_table}) _pii"
        )
    else:
        source = target_table

    base_sql = f"SELECT {', '.join(top_exprs)} FROM {source}"

    if not json_col_stats:
        return base_sql   # MySQL / SingleStore — flat path, Shape B done in Spark

    if platform == "BQ":
        return _bq_wide_sql(base_sql, json_col_stats)
    if platform == "POSTGRES":
        return _pg_wide_sql(base_sql, json_col_stats)
    if platform == "ORACLE":
        return _oracle_wide_sql(base_sql, json_col_stats)

    return base_sql


# ---------------------------------------------------------------------------
# BQ — single UNPIVOT + JSON_VALUE → Shape B
# ---------------------------------------------------------------------------

def _bq_wide_sql(base_sql: str, col_stat_names: dict[str, list[str]]) -> str:
    """Single UNPIVOT converts wide JSON columns to (col, val) rows; JSON_VALUE
    extracts each stat to its own column in the outer SELECT → Shape B directly.

    Only one UNPIVOT needed (vs. the previous double-UNPIVOT approach that
    went wide → Shape A long → re-pivot to Shape B).

    All stat names are enumerated at build time so BQ performs deterministic
    JSON_VALUE lookups — no JSON_KEYS, no CROSS JOIN UNNEST, no 100 MB rows.
    """
    # Union of all stat names across all columns (columns missing a stat → NULL)
    seen: set[str] = set()
    all_stats: list[str] = []
    for stats in col_stat_names.values():
        for s in stats:
            if s not in seen:
                all_stats.append(s)
                seen.add(s)

    first_unpivot_in = ", ".join(f"`{c}`" for c in col_stat_names)
    json_value_lines = ",\n  ".join(
        f"JSON_VALUE(val, '$.{s}') AS `{s}`" for s in all_stats
    )

    return f"""SELECT
  CAST(total_rows AS INT64) AS total_rows,
  col                       AS column_name,
  {json_value_lines}
FROM ({base_sql})
UNPIVOT(val FOR col IN ({first_unpivot_in}))"""


# ---------------------------------------------------------------------------
# Postgres — UNION ALL branches with ->> → Shape B
# ---------------------------------------------------------------------------

def _pg_wide_sql(base_sql: str, col_stat_names: dict[str, list[str]]) -> str:
    """->> operator extracts each JSON field as text directly in the SELECT.
    One UNION ALL branch per column; the MATERIALIZED CTE runs the aggregation once.

    col_json ->> 'stat' returns:
        numeric value 42   →  '42'   (no JSON quotes)
        string  'hello'    →  'hello'
        JSON null          →  NULL
    """
    branches: list[str] = []
    for col, stats in col_stat_names.items():
        stat_exprs = ",\n  ".join(
            f'"{col}" ->> \'{s}\' AS "{s}"' for s in stats
        )
        branches.append(
            f"SELECT total_rows, '{col}' AS column_name,\n  {stat_exprs}\n"
            f'FROM profile_data'
        )

    return (
        f"WITH profile_data AS MATERIALIZED (\n  {base_sql}\n)\n"
        + "\nUNION ALL\n".join(branches)
    )


# ---------------------------------------------------------------------------
# Oracle — UNION ALL branches with JSON_VALUE → Shape B
# ---------------------------------------------------------------------------

def _oracle_wide_sql(base_sql: str, col_stat_names: dict[str, list[str]]) -> str:
    """JSON_VALUE per stat, one UNION ALL branch per column.
    The /*+ MATERIALIZE */ hint ensures the CTE aggregation runs once.
    Double-quoted column references handle Oracle reserved-word column names.
    """
    materialized_base = base_sql.replace(
        "SELECT COUNT(*)", "SELECT /*+ MATERIALIZE */ COUNT(*)", 1
    )

    branches: list[str] = []
    for col, stats in col_stat_names.items():
        stat_exprs = ",\n  ".join(
            f"JSON_VALUE(\"{col}\", '$.{s}') AS \"{s}\"" for s in stats
        )
        branches.append(
            f"SELECT total_rows, '{col}' AS column_name,\n  {stat_exprs}\n"
            f"FROM profile_data"
        )

    return (
        f"WITH profile_data AS (\n  {materialized_base}\n)\n"
        + "\nUNION ALL\n".join(branches)
    )


# ---------------------------------------------------------------------------
# Shape B normalisation
# ---------------------------------------------------------------------------

def to_wide_df(
    spark: SparkSession,
    pass1_df: DataFrame,
    platform: str,
) -> DataFrame:
    """Returns the Pass-1 result as Shape B (one row per column, one col per stat).

    JSON-pack platforms: SQL already returned Shape B — passthrough select.
    MySQL / SingleStore:  _wide_from_flat() pivots col__stat aliases → Shape B.
    """
    if platform in JSON_PACK_PLATFORMS:
        # Columns: total_rows + column_name + one column per stat name.
        # Exclude total_rows from the stat projection — it's a scalar repeated
        # on every row and will be read separately by the engine.
        return pass1_df
    return _wide_from_flat(spark, pass1_df)


def _wide_from_flat(spark: SparkSession, df: DataFrame) -> DataFrame:
    """Converts a single-row wide DataFrame with col__stat aliases → Shape B.

    Used for MySQL/SingleStore (Pass 1) and all platforms (Pass 2), both of
    which return one aggregate row with column names like  user_id__avg.

    Result: one row per column_name with each stat as its own column.
    """
    # Collect the single aggregate row.
    row = df.first()
    if not row:
        return spark.createDataFrame([], "column_name string")

    row_dict = row.asDict()
    total_rows = row_dict.get("total_rows")

    # Group values by column name.
    from collections import defaultdict
    col_stats: dict[str, dict] = defaultdict(dict)
    for key, value in row_dict.items():
        if key == "total_rows" or "__" not in key:
            continue
        col_name, stat_name = key.split("__", 1)
        col_stats[col_name][stat_name] = value

    if not col_stats:
        return spark.createDataFrame([], "column_name string")

    # Collect all unique stat names to build a consistent schema.
    all_stats: list[str] = sorted({s for stats in col_stats.values() for s in stats})

    records: list[dict] = []
    for col_name, stats in col_stats.items():
        record = {"total_rows": total_rows, "column_name": col_name}
        for s in all_stats:
            record[s] = str(stats[s]) if stats.get(s) is not None else None
        records.append(record)

    return spark.createDataFrame(records)
