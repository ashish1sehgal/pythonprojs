"""Pass 2 — sampled aggregation for platforms without APPROX_PERCENTILE.

Fires only for Postgres and MySQL. For Oracle / BQ / SingleStore the engine
skips this pass entirely because percentiles are computed in Pass 1 via
APPROX_PERCENTILE / APPROX_QUANTILES.

SQL is generated in pure Python from the plan rows collected off plan_df —
no Spark SQL temp-view joins needed here.
"""

from .dialect import render_stat


def build_pass2_sql(
    target_table: str,
    sample_clause: str,
    plan_rows: list[dict],
    dialect: dict,
    pass2_stats: list[str],
    platform: str,
    partition_filter: str = "",
) -> str | None:
    """Returns a single SELECT with all Pass-2 stat expressions, or None.

    Args:
        plan_rows   – rows from plan_df where include_pass2 is True,
                      each with keys: column_name, pass2_stats (list[str])
        pass2_stats – authoritative list of stats routed to Pass 2 by the registry
        platform    – used for the platform guard (must not be called for BQ/Oracle/SingleStore)
    """
    if platform in ("BQ", "ORACLE", "SINGLESTORE"):
        # Hard guard: percentiles for these platforms are in Pass 1.
        # Caller should never reach here, but be explicit.
        raise ValueError(
            f"Pass 2 must not run for platform={platform}. "
            "Percentiles are computed in Pass 1 via APPROX_PERCENTILE."
        )

    fragments: list[str] = []
    for r in plan_rows:
        if not r.get("include_pass2"):
            continue
        col = r["column_name"]
        for stat in r.get("pass2_stats", []):
            if stat not in pass2_stats:
                continue
            sql_expr = render_stat(stat, col, dialect)
            if sql_expr:
                fragments.append(f"{sql_expr} AS {col}__{stat}")

    if not fragments:
        return None

    return (
        f"SELECT COUNT(*) AS total_rows, {', '.join(fragments)} "
        f"FROM {target_table}{sample_clause}{partition_filter}"
    )
