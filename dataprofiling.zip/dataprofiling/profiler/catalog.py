"""DB catalog column validation — decommission guard.

Queries the source database's system catalog to retrieve the actual column
names that exist in the target table.  The engine calls this once per job
(before the batch loop) and filters the profiling config so that columns
which have been decommissioned from the database are silently excluded from
all passes rather than causing a runtime SQL error.

Platform catalog tables
-----------------------
BQ            INFORMATION_SCHEMA.COLUMNS  (project.dataset scoped)
Postgres      information_schema.columns  (table_schema + table_name)
MySQL         information_schema.columns  (table_schema + table_name)
SingleStore   information_schema.columns  (table_schema + table_name)
Oracle        ALL_TAB_COLUMNS             (owner + table_name, always uppercase)

Failure behaviour
-----------------
If the catalog query fails for any reason (permissions, network, unsupported
connector behaviour in CI), fetch_active_columns() logs a WARNING and returns
an empty frozenset.  filter_active_columns() treats an empty set as "catalog
unavailable — skip filtering" so the job proceeds with the full config and
any downstream errors surface naturally.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .jdbc import JdbcReader

log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def fetch_active_columns(
    target_table: str,
    reader: "JdbcReader",
    platform: str,
) -> frozenset[str]:
    """Query the source DB catalog and return the set of existing column names.

    Column names are normalised to **lowercase** for case-insensitive
    comparison across all platforms (Oracle stores uppercase, Postgres
    lowercase, BQ as-defined).

    Returns an empty frozenset when the catalog is unavailable; the caller
    treats this as "skip decommission filtering" rather than an error.
    """
    sql = _catalog_sql(target_table, platform)
    if not sql:
        log.warning(
            "catalog: cannot build catalog query for platform=%s table='%s'; "
            "decommission check skipped.",
            platform, target_table,
        )
        return frozenset()

    try:
        rows = reader.read_rows(sql)
    except Exception as exc:
        log.warning(
            "catalog: %s catalog query failed for '%s' — %s. "
            "Decommission check skipped; proceeding with full config.",
            platform, target_table, exc,
        )
        return frozenset()

    active = frozenset(
        str(r.get("column_name", "")).strip().lower()
        for r in rows
        if r.get("column_name")
    )
    log.info(
        "catalog: found %d columns in %s catalog for '%s'.",
        len(active), platform, target_table,
    )
    return active


def filter_active_columns(
    config_columns: list[dict],
    active_cols: frozenset[str],
) -> tuple[list[dict], list[str]]:
    """Split config_columns into (active, decommissioned) based on the catalog.

    Args:
        config_columns – raw column config list from the profiling config
        active_cols    – frozenset of lowercase column names from fetch_active_columns()

    Returns:
        active_cols_config  – columns that exist in the DB (passed to batches)
        decommissioned_names – names that were dropped (logged by caller)

    When active_cols is empty (catalog unavailable), all config_columns are
    returned as active and decommissioned_names is empty.
    """
    if not active_cols:
        return config_columns, []

    active: list[dict] = []
    decommissioned: list[str] = []

    for col in config_columns:
        name = col["attributeName"].lower()
        if name in active_cols:
            active.append(col)
        else:
            decommissioned.append(col["attributeName"])

    return active, decommissioned


# ---------------------------------------------------------------------------
# Platform-specific catalog SQL builders
# ---------------------------------------------------------------------------

def _catalog_sql(target_table: str, platform: str) -> str | None:
    """Returns the catalog SELECT for the given platform, or None if unparseable."""
    if platform == "BQ":
        return _bq_catalog_sql(target_table)
    if platform == "ORACLE":
        return _oracle_catalog_sql(target_table)
    # Postgres / MySQL / SingleStore — all expose information_schema.columns
    return _ansi_catalog_sql(target_table)


def _bq_catalog_sql(target_table: str) -> str | None:
    """BQ: project.dataset.INFORMATION_SCHEMA.COLUMNS scoped to the table."""
    project, dataset, table = _parse_bq_ref(target_table)
    if not dataset or not table:
        return None

    if project:
        prefix = f"`{project}.{dataset}`"
    else:
        prefix = f"`{dataset}`"

    return (
        f"SELECT column_name "
        f"FROM {prefix}.INFORMATION_SCHEMA.COLUMNS "
        f"WHERE table_name = '{table}'"
    )


def _oracle_catalog_sql(target_table: str) -> str | None:
    """Oracle: ALL_TAB_COLUMNS with owner + table_name, both UPPERCASE."""
    schema, table = _parse_schema_table(target_table)
    if not table:
        return None

    table_upper = table.upper()
    if schema:
        return (
            f"SELECT column_name "
            f"FROM all_tab_columns "
            f"WHERE owner = UPPER('{schema}') "
            f"AND table_name = '{table_upper}'"
        )
    # No schema prefix — query all accessible tables with this name
    return (
        f"SELECT column_name "
        f"FROM all_tab_columns "
        f"WHERE table_name = '{table_upper}'"
    )


def _ansi_catalog_sql(target_table: str) -> str | None:
    """Postgres / MySQL / SingleStore: ANSI information_schema.columns."""
    schema, table = _parse_schema_table(target_table)
    if not table:
        return None

    if schema:
        return (
            f"SELECT column_name "
            f"FROM information_schema.columns "
            f"WHERE table_schema = '{schema}' "
            f"AND table_name = '{table}'"
        )
    # No schema prefix — match by table name only (may span schemas)
    return (
        f"SELECT column_name "
        f"FROM information_schema.columns "
        f"WHERE table_name = '{table}'"
    )


# ---------------------------------------------------------------------------
# Table reference parsers
# ---------------------------------------------------------------------------

def _parse_bq_ref(ref: str) -> tuple[str | None, str | None, str | None]:
    """`` `project.dataset.table` `` → (project, dataset, table)."""
    cleaned = ref.strip().strip("`")
    parts = cleaned.split(".")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2:
        return None, parts[0], parts[1]
    return None, None, (parts[0] if parts else None)


def _parse_schema_table(ref: str) -> tuple[str | None, str | None]:
    """``schema.table`` → (schema, table) or ``table`` → (None, table).

    For three-part BQ references the last two parts are used so this
    function can also be called safely on BQ table strings.
    """
    cleaned = ref.strip().strip("`").strip('"')
    parts = cleaned.split(".")
    if len(parts) >= 2:
        return parts[-2], parts[-1]
    return None, (parts[0] if parts else None)
