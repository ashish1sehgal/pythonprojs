"""Column planner — builds the per-column gating DataFrame from Pass-1 Shape B output.

Shape B (one row per column, one column per stat) arrives directly from
to_wide_df(), so no Spark pivot is needed here.  We simply join the raw
config rows to the wide stat columns and compute the gating flags.
"""

from pyspark.sql import SparkSession, DataFrame, functions as F
from pyspark.sql.types import (
    ArrayType,
    BooleanType,
    IntegerType,
    LongType,
    StringType,
    StructField,
    StructType,
)

_CONFIG_SCHEMA = StructType([
    StructField("column_name", StringType(),            False),
    StructField("data_type",   StringType(),            False),
    StructField("pass2_stats", ArrayType(StringType()), False),
    StructField("is_id",       BooleanType(),           False),
    StructField("hist_bins",   IntegerType(),           False),
    StructField("total_rows",  LongType(),              False),
])

# Stat columns from Shape B that feed the gating conditions.
_PLAN_COLS = ["distinct_count", "min", "max", "distinct_pattern_count", "mean_value"]

_NUMERIC_TYPES = {
    "INT", "INTEGER", "BIGINT", "SMALLINT", "FLOAT", "DOUBLE",
    "DECIMAL", "NUMERIC", "NUMBER", "BINARY_DOUBLE", "FLOAT64",
}
_STRING_TYPES = {"STRING", "VARCHAR", "TEXT", "NVARCHAR", "CHAR"}


def build_plan_df(
    spark: SparkSession,
    batch_cols: list[dict],
    wide_df: DataFrame,
    total_rows: int,
    pass2_stats: list[str],
    uniq_ratio_threshold: float = 0.90,
    freq_limit: int = 1_000,
    pattern_limit: int = 100,
) -> DataFrame:
    """Builds the per-column routing DataFrame from Pass-1 Shape B output.

    Shape B already has one row per column with stat values as columns, so
    no pivot step is required — config_df is joined directly to wide_df.

    Args:
        wide_df              – Shape B DataFrame from to_wide_df()
        total_rows           – table row count from Pass-1 COUNT(*)
        pass2_stats          – stat names routed to Pass 2 by the registry
        uniq_ratio_threshold – distinct/total below this → include_pass2
        freq_limit           – distinct_count ≤ this → eligible for freq dist
        pattern_limit        – distinct_pattern_count ≤ this → eligible for patterns
    """
    config_rows = [
        (
            col["attributeName"],
            col.get("dataTypeCategory", "STRING").upper(),
            [s for s in col.get("selectedStats", []) if s in pass2_stats],
            _is_id_column(col["attributeName"]),
            int((col.get("viz_config") or {}).get("histogram_bins", 20)),
            total_rows,
        )
        for col in batch_cols
    ]
    config_df = spark.createDataFrame(config_rows, schema=_CONFIG_SCHEMA)

    # Shape B already has stat values as columns — join directly, no pivot needed.
    # Only select the columns that exist in wide_df to avoid join key collisions.
    available_plan_cols = [c for c in _PLAN_COLS if c in wide_df.columns]
    plan_df = config_df.join(
        wide_df.select("column_name", *available_plan_cols),
        on="column_name",
        how="left",
    )

    # Normalise stat columns: cast to double, alias for consistent downstream names.
    plan_df = (
        plan_df
        .withColumn(
            "distinct_count",
            F.coalesce(F.col("distinct_count").cast("double"), F.lit(0.0))
            if "distinct_count" in plan_df.columns
            else F.lit(0.0),
        )
        .withColumn(
            "pattern_count",
            F.coalesce(F.col("distinct_pattern_count").cast("double"), F.lit(0.0))
            if "distinct_pattern_count" in plan_df.columns
            else F.lit(0.0),
        )
        .withColumn("min_val", F.col("min") if "min" in plan_df.columns else F.lit(None).cast("string"))
        .withColumn("max_val", F.col("max") if "max" in plan_df.columns else F.lit(None).cast("string"))
        .withColumn(
            "mean_value",
            F.col("mean_value") if "mean_value" in plan_df.columns else F.lit(None).cast("string"),
        )
    )

    # Gating flags
    plan_df = (
        plan_df
        .withColumn(
            "uniq_ratio",
            F.when(F.col("total_rows") > 0, F.col("distinct_count") / F.col("total_rows"))
            .otherwise(F.lit(0.0)),
        )
        .withColumn("include_pass2", F.col("uniq_ratio") < F.lit(uniq_ratio_threshold))
        .withColumn(
            "include_freq",
            (~F.col("is_id"))
            & F.col("data_type").isin(*_STRING_TYPES)
            & (F.col("distinct_count") <= F.lit(freq_limit)),
        )
        .withColumn(
            "include_pattern",
            (~F.col("is_id"))
            & F.col("data_type").isin(*_STRING_TYPES)
            & (F.col("pattern_count") <= F.lit(pattern_limit)),
        )
        .withColumn(
            "include_hist",
            F.col("data_type").isin(*_NUMERIC_TYPES)
            & (F.col("distinct_count") > F.lit(10))
            & F.col("min_val").isNotNull()
            & F.col("max_val").isNotNull()
            & (F.col("min_val") != F.col("max_val")),
        )
    )

    return plan_df.cache()


def get_plan_rows(
    plan_df: DataFrame,
    cols: list[str] | None = None,
) -> list[dict]:
    """Collects plan_df to a list of dicts, optionally projecting a subset of columns."""
    if cols:
        return [r.asDict() for r in plan_df.select(*cols).collect()]
    return [r.asDict() for r in plan_df.collect()]


def _is_id_column(name: str) -> bool:
    n = name.lower()
    return n in {"id", "pk"} or n.endswith(("_id", "_sk", "_key", "uuid"))
