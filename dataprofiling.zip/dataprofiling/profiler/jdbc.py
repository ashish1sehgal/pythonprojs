from pyspark.sql import SparkSession, DataFrame


class JdbcReader:
    """Thin wrapper around Spark JDBC reads to avoid repeating connection options."""

    def __init__(
        self,
        spark: SparkSession,
        jdbc_url: str,
        user: str,
        password: str,
        driver: str,
    ) -> None:
        self._spark = spark
        self._opts = {
            "url": jdbc_url,
            "user": user,
            "password": password,
            "driver": driver,
        }

    def read_df(self, sql: str) -> DataFrame:
        return (
            self._spark.read.format("jdbc")
            .options(**self._opts)
            .option("dbtable", f"({sql}) _t")
            .load()
        )

    def read_rows(self, sql: str) -> list[dict]:
        return [r.asDict() for r in self.read_df(sql).collect()]

    def read_one(self, sql: str) -> dict:
        rows = self.read_df(sql).collect()
        return rows[0].asDict() if rows else {}
