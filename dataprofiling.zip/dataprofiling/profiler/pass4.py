"""Pass 4 — Per-column normality tests on a pulled data sample.

Runs after Pass 1 + Pass 2 have merged into the Shape B wide_df.
Results are joined back into wide_df as additional columns so that
normality test outcomes travel with the rest of the per-column stats
to GCS and profiler_run_metrics.

Supported methods (user-specified per column via normality_test field)
----------------------------------------------------------------------
  "Shapiro-Wilk"      scipy.stats.shapiro — highest power for n ≤ 5000
  "Anderson-Darling"  scipy.stats.anderson — no hard n limit; uses critical
                      values at 5% significance rather than a p-value
  "Kolmogorov-Smirnov" scipy.stats.kstest against N(μ̂, σ̂) estimated from
                      the sample — one-sample, composite hypothesis

Column selection
----------------
Only numeric columns with normality_test != None are eligible.
The number of eligible columns is capped at MAX_PASS4_COLUMNS (25)
to control sample-pull cost.  Columns beyond the cap are marked
SKIPPED_COLUMN_LIMIT.

Sample pull
-----------
A single JDBC read fetches all eligible columns in one query so the
DB scan happens once.  Rows containing NULL in any eligible column
are dropped per-column in Python before each test (so other columns
are unaffected by a given column's nulls).

Output columns added to wide_df
--------------------------------
  normality_method        STRING   — e.g. "Shapiro-Wilk"
  normality_statistic     DOUBLE   — test statistic
  normality_p_value       DOUBLE   — p-value (NULL for Anderson-Darling)
  normality_critical_val  DOUBLE   — AD critical value at 5% (NULL otherwise)
  normality_is_normal     BOOLEAN  — True if evidence of normality at α=0.05
  normality_result        STRING   — NORMAL | NON_NORMAL | INSUFFICIENT_DATA
                                     | SKIPPED_COLUMN_LIMIT | ERROR
  normality_sample_n      INT      — actual n used for the test
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

import numpy as np
from scipy import stats as scipy_stats
from pyspark.sql import SparkSession, DataFrame
from pyspark.sql.types import (
    BooleanType, DoubleType, IntegerType, StringType,
    StructField, StructType,
)

if TYPE_CHECKING:
    from .jdbc import JdbcReader

log = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

MAX_PASS4_COLUMNS = 25
_ALPHA = 0.05          # significance level for all tests
_AD_SIG_IDX = 2        # scipy AD critical values: [15,10,5,2.5,1]%; index 2 = 5%

# scipy.stats.shapiro raises for n > 5000 and is unreliable near that limit
_SW_MAX_N = 5_000
# Practical upper bound for AD and KS to avoid pulling too many rows
_AD_KS_MAX_N = 10_000
_MIN_N = 8             # fewer points than this is not statistically meaningful

# Canonical method names and their accepted aliases
_METHOD_MAP: dict[str, str] = {
    "shapiro-wilk":       "Shapiro-Wilk",
    "shapiro_wilk":       "Shapiro-Wilk",
    "sw":                 "Shapiro-Wilk",
    "anderson-darling":   "Anderson-Darling",
    "anderson_darling":   "Anderson-Darling",
    "ad":                 "Anderson-Darling",
    "kolmogorov-smirnov": "Kolmogorov-Smirnov",
    "kolmogorov_smirnov": "Kolmogorov-Smirnov",
    "kolmogorov":         "Kolmogorov-Smirnov",
    "ks":                 "Kolmogorov-Smirnov",
}

_RESULT_SCHEMA = StructType([
    StructField("column_name",          StringType(),  True),
    StructField("normality_method",      StringType(),  True),
    StructField("normality_statistic",   DoubleType(),  True),
    StructField("normality_p_value",     DoubleType(),  True),
    StructField("normality_critical_val",DoubleType(),  True),
    StructField("normality_is_normal",   BooleanType(), True),
    StructField("normality_result",      StringType(),  True),
    StructField("normality_sample_n",    IntegerType(), True),
])


# ---------------------------------------------------------------------------
# Result carrier
# ---------------------------------------------------------------------------

@dataclass
class NormalityResult:
    column_name:          str
    method:               str
    statistic:            float | None = None
    p_value:              float | None = None
    critical_val:         float | None = None  # AD 5% critical value
    is_normal:            bool  | None = None
    result:               str          = "ERROR"
    sample_n:             int          = 0


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def run_normality_tests(
    target_table:     str,
    sample_clause:    str,
    batch_cols:       list[dict],
    reader:           "JdbcReader",
    platform:         str,
    partition_filter: str = "",
) -> list[NormalityResult]:
    """Pull a data sample for all normality-eligible columns in this batch
    and run the user-specified test per column.

    Args:
        target_table   – fully qualified table name
        sample_clause  – SQL sample clause (may be empty for non-BQ full scans)
        batch_cols     – column config dicts from profiling config
        reader         – JdbcReader for JDBC data pull
        platform       – source platform (drives LIMIT syntax)

    Returns list of NormalityResult, one per eligible column.
    Columns beyond MAX_PASS4_COLUMNS or with no normality_test set are omitted.
    """
    eligible = _select_eligible_columns(batch_cols)
    if not eligible:
        return []

    if len(eligible) > MAX_PASS4_COLUMNS:
        log.warning(
            "Pass 4: %d columns requested but cap is %d; "
            "first %d (by config order) will be tested.",
            len(eligible), MAX_PASS4_COLUMNS, MAX_PASS4_COLUMNS,
        )
        skipped = eligible[MAX_PASS4_COLUMNS:]
        eligible = eligible[:MAX_PASS4_COLUMNS]
    else:
        skipped = []

    # Determine the largest sample we need to pull for any method in this batch.
    methods_in_batch = {_canonical_method(c["normality_test"]) for c in eligible}
    max_n = _SW_MAX_N if methods_in_batch == {"Shapiro-Wilk"} else _AD_KS_MAX_N

    col_names = [c["attributeName"] for c in eligible]
    sql = _sample_sql(target_table, col_names, max_n, platform, sample_clause, partition_filter)

    log.info(
        "Pass 4: pulling normality sample — %d columns, max %d rows from %s.",
        len(col_names), max_n, target_table,
    )
    try:
        sample_rows = reader.read_rows(sql)
    except Exception as exc:
        log.error("Pass 4: sample pull failed — %s", exc)
        return [
            NormalityResult(c["attributeName"], _canonical_method(c["normality_test"]),
                            result="ERROR")
            for c in eligible
        ]

    # Convert list-of-dicts to per-column numpy arrays.
    arrays: dict[str, np.ndarray] = _to_arrays(sample_rows, col_names)

    results: list[NormalityResult] = []
    for col_cfg in eligible:
        col = col_cfg["attributeName"]
        method = _canonical_method(col_cfg["normality_test"])
        arr = arrays.get(col, np.array([]))
        results.append(_test_column(col, method, arr))

    # Emit placeholder results for columns that exceeded the cap.
    for col_cfg in skipped:
        results.append(NormalityResult(
            column_name=col_cfg["attributeName"],
            method=_canonical_method(col_cfg["normality_test"]),
            result="SKIPPED_COLUMN_LIMIT",
        ))

    return results


def results_to_df(spark: SparkSession, results: list[NormalityResult]) -> DataFrame:
    """Convert a list of NormalityResult to a Spark DataFrame for joining
    into wide_df on column_name."""
    records = [
        (
            r.column_name,
            r.method,
            float(r.statistic)    if r.statistic    is not None else None,
            float(r.p_value)      if r.p_value      is not None else None,
            float(r.critical_val) if r.critical_val is not None else None,
            r.is_normal,
            r.result,
            int(r.sample_n),
        )
        for r in results
    ]
    return spark.createDataFrame(records, schema=_RESULT_SCHEMA)


# ---------------------------------------------------------------------------
# Individual test runners
# ---------------------------------------------------------------------------

def _test_column(col: str, method: str, arr: np.ndarray) -> NormalityResult:
    """Run the specified normality test on a single column's data array."""
    base = NormalityResult(column_name=col, method=method)

    # Drop NaNs (NULLs became np.nan during conversion)
    arr = arr[~np.isnan(arr)]
    base.sample_n = len(arr)

    if base.sample_n < _MIN_N:
        base.result = "INSUFFICIENT_DATA"
        return base

    try:
        if method == "Shapiro-Wilk":
            return _shapiro_wilk(base, arr)
        if method == "Anderson-Darling":
            return _anderson_darling(base, arr)
        if method == "Kolmogorov-Smirnov":
            return _kolmogorov_smirnov(base, arr)
    except Exception as exc:
        log.warning("Pass 4: %s test failed for column '%s' — %s", method, col, exc)
        base.result = "ERROR"
        return base

    base.result = "ERROR"
    return base


def _shapiro_wilk(r: NormalityResult, arr: np.ndarray) -> NormalityResult:
    # scipy.stats.shapiro raises if n > 5000; subsample silently.
    if len(arr) > _SW_MAX_N:
        rng = np.random.default_rng(seed=42)
        arr = rng.choice(arr, size=_SW_MAX_N, replace=False)
        r.sample_n = _SW_MAX_N

    stat, p = scipy_stats.shapiro(arr)
    r.statistic = float(stat)
    r.p_value   = float(p)
    r.is_normal = p > _ALPHA
    r.result    = "NORMAL" if r.is_normal else "NON_NORMAL"
    return r


def _anderson_darling(r: NormalityResult, arr: np.ndarray) -> NormalityResult:
    if len(arr) > _AD_KS_MAX_N:
        rng = np.random.default_rng(seed=42)
        arr = rng.choice(arr, size=_AD_KS_MAX_N, replace=False)
        r.sample_n = _AD_KS_MAX_N

    res = scipy_stats.anderson(arr, dist="norm")
    crit = float(res.critical_values[_AD_SIG_IDX])
    r.statistic   = float(res.statistic)
    r.critical_val = crit
    # p_value is not produced by AD; use None
    r.is_normal  = res.statistic < crit
    r.result     = "NORMAL" if r.is_normal else "NON_NORMAL"
    return r


def _kolmogorov_smirnov(r: NormalityResult, arr: np.ndarray) -> NormalityResult:
    """One-sample KS test against a Normal distribution with parameters
    estimated from the sample (composite null hypothesis)."""
    if len(arr) > _AD_KS_MAX_N:
        rng = np.random.default_rng(seed=42)
        arr = rng.choice(arr, size=_AD_KS_MAX_N, replace=False)
        r.sample_n = _AD_KS_MAX_N

    mu, sigma = float(np.mean(arr)), float(np.std(arr, ddof=1))
    if sigma == 0:
        r.result = "INSUFFICIENT_DATA"
        return r

    stat, p = scipy_stats.kstest(arr, "norm", args=(mu, sigma))
    r.statistic = float(stat)
    r.p_value   = float(p)
    r.is_normal = p > _ALPHA
    r.result    = "NORMAL" if r.is_normal else "NON_NORMAL"
    return r


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _select_eligible_columns(batch_cols: list[dict]) -> list[dict]:
    """Return columns that have a valid normality_test value and are numeric."""
    eligible = []
    for col in batch_cols:
        test = col.get("normality_test")
        if not test:
            continue
        canonical = _canonical_method(test)
        if canonical is None:
            log.warning(
                "Pass 4: unrecognised normality_test '%s' for column '%s' — skipping.",
                test, col["attributeName"],
            )
            continue
        # Normality tests are only meaningful for numeric columns.
        dtype = col.get("dataTypeCategory", "").upper()
        if dtype not in ("NUMERIC", "INT", "INTEGER", "FLOAT", "DOUBLE",
                         "BIGINT", "DECIMAL", "NUMBER", "BINARY_DOUBLE", "FLOAT64"):
            log.info(
                "Pass 4: column '%s' has type '%s' — normality test skipped.",
                col["attributeName"], dtype,
            )
            continue
        eligible.append(col)
    return eligible


def _canonical_method(raw: str | None) -> str | None:
    if not raw:
        return None
    return _METHOD_MAP.get(raw.lower().strip())


def _sample_sql(
    target_table:     str,
    cols:             list[str],
    max_n:            int,
    platform:         str,
    sample_clause:    str,
    partition_filter: str = "",
) -> str:
    """Build a SELECT … LIMIT/FETCH FIRST SQL that pulls a raw data sample.
    NULLs are kept here and removed per-column in Python so one column's
    nulls don't reduce the usable n for other columns.

    SQL order: FROM table TABLESAMPLE ... WHERE partition_col = ... LIMIT n
    """
    col_list = ", ".join(cols)
    if platform == "ORACLE":
        # Oracle 12c+ FETCH FIRST syntax; WHERE (partition_filter) precedes FETCH
        return (
            f"SELECT {col_list} FROM {target_table}{sample_clause}{partition_filter} "
            f"FETCH FIRST {max_n} ROWS ONLY"
        )
    # BQ / Postgres / MySQL / SingleStore: TABLESAMPLE then WHERE then LIMIT
    return (
        f"SELECT {col_list} FROM {target_table}{sample_clause}{partition_filter} "
        f"LIMIT {max_n}"
    )


def _to_arrays(rows: list[dict], col_names: list[str]) -> dict[str, np.ndarray]:
    """Convert a list-of-dicts (from reader.read_rows) to per-column float arrays.
    Non-numeric values (e.g. strings that slipped through) become NaN.
    """
    arrays: dict[str, np.ndarray] = {}
    for col in col_names:
        values = []
        for row in rows:
            v = row.get(col)
            try:
                values.append(float(v) if v is not None else np.nan)
            except (TypeError, ValueError):
                values.append(np.nan)
        arrays[col] = np.array(values, dtype=np.float64)
    return arrays
