"""Pass 3 — DB-pushed frequency distributions, pattern distributions, and histograms.

Strategy by platform
--------------------
ORACLE / BQ / POSTGRES / SINGLESTORE
    Uses GROUPING SETS so the DB reads the sampled CTE only once per batch:

        WITH sampled AS (SELECT col1, col2, ... FROM table SAMPLE),
        _b0 AS (
            SELECT
                CASE WHEN GROUPING(col1_freq) = 0 THEN 'col1' ... END AS column_name,
                CASE WHEN GROUPING(col1_freq) = 0 THEN 'freq' ... END AS metric_type,
                CASE WHEN GROUPING(col1_freq) = 0 THEN CAST(col1_freq AS VARCHAR) ... END AS bucket_label,
                COUNT(*) AS cnt
            FROM (SELECT CAST(col1 AS VARCHAR) AS col1_freq, ... FROM sampled) _inner
            GROUP BY GROUPING SETS ((col1_freq), (col2_pat), ...)
        ),
        ...
        SELECT * FROM _b0 UNION ALL SELECT * FROM _b1 ...

    When the total number of grouping-set slots exceeds the platform limit
    (Oracle 32, BQ 50, Postgres/SingleStore 64), expressions are split into
    batches of that size, each batch becomes one CTE, and the CTEs are
    UNION ALL'd.  With N total expressions and limit L, this costs
    ceil(N/L) scans of sampled — always better than the N scans that a
    pure UNION ALL of individual GROUP BYs would cost.

MYSQL (fallback)
    No GROUPING SETS support assumed.  Uses a UNION ALL of one independent
    GROUP BY per expression, all referencing the shared sampled CTE.

Histogram bucketing
-------------------
Uses floor-based arithmetic — FLOOR((col - min) / width) clamped with LEAST
— instead of WIDTH_BUCKET, which is not available on MySQL and has edge-case
differences across platforms.
"""

from collections import defaultdict
from dataclasses import dataclass

from .constants import DOUBLE_TYPE, GROUPING_SETS_LIMITS, TOP_K


# ---------------------------------------------------------------------------
# Internal expression descriptor
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class _Expr:
    alias: str        # unique alias in the prepped inline view
    column_name: str  # original column name (written to output)
    metric_type: str  # 'freq' | 'pattern' | 'hist'
    value_expr: str   # SQL expression that produces the groupable value
    raw_col: str      # source column needed in the sampled CTE


# ---------------------------------------------------------------------------
# Per-expression SQL helpers
# ---------------------------------------------------------------------------

def _pattern_sql(col: str) -> str:
    return (
        f"REGEXP_REPLACE(REGEXP_REPLACE(CAST({col} AS VARCHAR(4000)), "
        f"'[A-Za-z]', 'A'), '[0-9]', 'N')"
    )


def _bucket_sql(col: str, mn: float, mx: float, bins: int, platform: str) -> str:
    width = (mx - mn) / bins
    double_t = DOUBLE_TYPE.get(platform, "DOUBLE PRECISION")
    floor_part = f"FLOOR((CAST({col} AS {double_t}) - {mn}) / {width})"
    return f"LEAST({floor_part}, {bins - 1})"


# ---------------------------------------------------------------------------
# Build the flat list of _Expr objects from plan rows
# ---------------------------------------------------------------------------

def _collect_exprs(plan_rows: list[dict], platform: str) -> list[_Expr]:
    exprs: list[_Expr] = []
    seen: set[str] = set()

    def _alias(base: str) -> str:
        candidate = base
        i = 1
        while candidate in seen:
            candidate = f"{base}_{i}"
            i += 1
        seen.add(candidate)
        return candidate

    for r in plan_rows:
        col = r["column_name"]

        if r.get("include_freq"):
            exprs.append(_Expr(
                alias=_alias(f"{col}_freq"),
                column_name=col,
                metric_type="freq",
                value_expr=f"CAST({col} AS VARCHAR(4000))",
                raw_col=col,
            ))

        if r.get("include_pattern"):
            exprs.append(_Expr(
                alias=_alias(f"{col}_pat"),
                column_name=col,
                metric_type="pattern",
                value_expr=_pattern_sql(col),
                raw_col=col,
            ))

        if r.get("include_hist"):
            mn, mx = r.get("min_val"), r.get("max_val")
            bins = int(r.get("hist_bins") or 20)
            if mn is None or mx is None or float(mn) == float(mx) or bins <= 0:
                continue
            exprs.append(_Expr(
                alias=_alias(f"{col}_hist"),
                column_name=col,
                metric_type="hist",
                value_expr=_bucket_sql(col, float(mn), float(mx), bins, platform),
                raw_col=col,
            ))

    return exprs


# ---------------------------------------------------------------------------
# GROUPING SETS path
# ---------------------------------------------------------------------------

def _grouping_sets_cte(batch: list[_Expr], batch_idx: int, sampled: str) -> str:
    """One GROUPING SETS sub-query for a batch of expressions.

    Uses CASE WHEN GROUPING(alias) = 0 for all three output columns so that:
    - rolled-up slots (GROUPING = 1) produce NULL → filtered by outer WHERE
    - data NULLs (actual null value in source) also produce NULL bucket_label
      → filtered by the same WHERE clause
    """
    prepped = ", ".join(f"{e.value_expr} AS {e.alias}" for e in batch)
    inner = f"_p3i{batch_idx}"

    def _case(attr: str) -> str:
        branches = " ".join(
            f"WHEN GROUPING({e.alias}) = 0 THEN {attr(e)}" for e in batch
        )
        return f"CASE {branches} END"

    col_case   = _case(lambda e: f"'{e.column_name}'")
    type_case  = _case(lambda e: f"'{e.metric_type}'")
    label_case = _case(lambda e: f"CAST({e.alias} AS VARCHAR(4000))")
    gs_list    = ", ".join(f"({e.alias})" for e in batch)

    inner_sql = (
        f"SELECT {col_case} AS column_name, "
        f"{type_case} AS metric_type, "
        f"{label_case} AS bucket_label, "
        f"COUNT(*) AS cnt "
        f"FROM (SELECT {prepped} FROM {sampled}) {inner} "
        f"GROUP BY GROUPING SETS ({gs_list})"
    )

    # Wrap in a subquery so we can filter with a plain WHERE on column aliases.
    return (
        f"SELECT column_name, metric_type, bucket_label, cnt "
        f"FROM ({inner_sql}) _p3f{batch_idx} "
        f"WHERE column_name IS NOT NULL AND bucket_label IS NOT NULL"
    )


# ---------------------------------------------------------------------------
# UNION ALL path (MySQL fallback)
# ---------------------------------------------------------------------------

def _union_all_branch(expr: _Expr, sampled: str) -> str:
    return (
        f"SELECT '{expr.column_name}' AS column_name, "
        f"'{expr.metric_type}' AS metric_type, "
        f"CAST({expr.value_expr} AS VARCHAR(4000)) AS bucket_label, "
        f"COUNT(*) AS cnt "
        f"FROM {sampled} "
        f"WHERE {expr.raw_col} IS NOT NULL "
        f"GROUP BY {expr.value_expr}"
    )


# ---------------------------------------------------------------------------
# Public builder
# ---------------------------------------------------------------------------

def build_pass3_sql(
    target_table: str,
    sample_clause: str,
    plan_rows: list[dict],
    platform: str,
) -> str | None:
    """Builds the complete Pass-3 SQL for all eligible columns.

    Returns None when no columns qualify for any Pass-3 metric.
    """
    exprs = _collect_exprs(plan_rows, platform)
    if not exprs:
        return None

    select_cols = sorted({e.raw_col for e in exprs})
    sampled_def = (
        f"sampled AS "
        f"(SELECT {', '.join(select_cols)} FROM {target_table}{sample_clause})"
    )

    gs_limit = GROUPING_SETS_LIMITS.get(platform)

    # --- UNION ALL fallback (MySQL or any unrecognised platform) ---
    if gs_limit is None:
        branches = [_union_all_branch(e, "sampled") for e in exprs]
        return f"WITH {sampled_def} " + " UNION ALL ".join(branches)

    # --- GROUPING SETS path (Oracle / BQ / Postgres / SingleStore) ---
    batches = [exprs[i : i + gs_limit] for i in range(0, len(exprs), gs_limit)]

    if len(batches) == 1:
        # Single batch: inline without extra CTE indirection.
        return f"WITH {sampled_def} {_grouping_sets_cte(batches[0], 0, 'sampled')}"

    # Multiple batches: one CTE per batch, UNION ALL of the CTEs.
    # The shared `sampled` CTE is referenced by every batch CTE; the DB
    # can materialise it once (Oracle / BQ always do; Postgres does with
    # the MATERIALIZED hint, but even without it the planner often does).
    cte_parts = [sampled_def]
    for i, batch in enumerate(batches):
        cte_parts.append(f"_p3_b{i} AS ({_grouping_sets_cte(batch, i, 'sampled')})")

    final = " UNION ALL ".join(f"SELECT * FROM _p3_b{i}" for i in range(len(batches)))
    return f"WITH {', '.join(cte_parts)} {final}"


# ---------------------------------------------------------------------------
# Result splitting
# ---------------------------------------------------------------------------

def split_pass3_results(
    rows: list[dict],
    extrapolation: float,
    top_k: int = TOP_K,
) -> tuple[list[dict], list[dict], list[dict]]:
    """Separates the unioned Pass-3 result into freq / pattern / histogram payloads.

    Args:
        rows          – collected rows from the Pass-3 SQL, each with
                        column_name, metric_type, bucket_label, cnt
        extrapolation – multiplier to scale sampled histogram counts back
                        to full-population estimates (1.0 for full scans)
        top_k         – number of top values/patterns to keep per column

    Returns:
        (freq_payloads, pattern_payloads, hist_payloads)
    """
    freq_map: dict[str, list] = defaultdict(list)
    pat_map:  dict[str, list] = defaultdict(list)
    hist_payloads: list[dict] = []

    for r in rows:
        col, label, ct = r["column_name"], r["bucket_label"], int(r["cnt"])
        if r["metric_type"] == "freq":
            freq_map[col].append((label, ct))
        elif r["metric_type"] == "pattern":
            pat_map[col].append((label, ct))
        elif r["metric_type"] == "hist":
            hist_payloads.append({
                "column_name": col,
                "bucket": int(float(label)),
                "count": int(ct * extrapolation),
            })

    freq_payloads = [
        {"column_name": c, "value": v, "count": ct}
        for c, vals in freq_map.items()
        for v, ct in sorted(vals, key=lambda x: x[1], reverse=True)[:top_k]
    ]
    pattern_payloads = [
        {"column_name": c, "pattern": v, "count": ct}
        for c, vals in pat_map.items()
        for v, ct in sorted(vals, key=lambda x: x[1], reverse=True)[:top_k]
    ]
    return freq_payloads, pattern_payloads, hist_payloads
