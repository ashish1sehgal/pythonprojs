import requests


def load_dialect(platform: str, api_base_url: str) -> tuple[dict, list, list, dict]:
    """Fetches stat metadata from the registry API.

    Returns:
        dialect      – {stat_name: sql_template} for all stats (None template = derived stat)
        pass1_stats  – stat names routed to Pass 1
        pass2_stats  – stat names routed to Pass 2
        dependencies – {stat_name: [prerequisite_stat_name, ...]} for derived stats
                       e.g. {"skewness": ["sum_x","sum_x2","sum_x3","sum_x4","mean_value"],
                              "excess_kurtosis": ["sum_x","sum_x2","sum_x3","sum_x4","mean_value"]}
                       Populated from the stat2sql.derived_from column in the registry.
    """
    url = f"{api_base_url}/stats/details/{platform.lower()}"
    raw: list[dict] = requests.get(url).json()

    dialect = {item["statName"]: item.get("statSql") for item in raw}
    pass1_stats = [item["statName"] for item in raw if item.get("passGrp") == 1]
    pass2_stats = [item["statName"] for item in raw if item.get("passGrp") == 2]

    dependencies: dict[str, list[str]] = {}
    for item in raw:
        derived_from = item.get("derivedFrom") or ""
        prereqs = [s.strip() for s in derived_from.split(",") if s.strip()]
        if prereqs:
            dependencies[item["statName"]] = prereqs

    return dialect, pass1_stats, pass2_stats, dependencies


def render_stat(stat: str, col: str, dialect: dict) -> str | None:
    """Substitutes the column placeholder in a stat SQL template.
    Returns None for derived stats (skewness, kurtosis) that have no direct SQL."""
    tmpl = dialect.get(stat)
    if not tmpl:
        return None
    return tmpl.replace("<<col>>", col).replace("{col}", col)
