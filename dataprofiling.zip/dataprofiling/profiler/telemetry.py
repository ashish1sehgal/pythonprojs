"""Telemetry — per-stage lifecycle logging to application log + REST API.

Every stage emits three events:
  RUNNING   — immediately before execution starts
  COMPLETED — immediately after successful completion (with elapsed seconds)
  ERROR     — if an exception escapes the stage (error is re-raised after logging)

Usage
-----
    tel = TelemetryClient(
        api_base_url="http://localhost:8080",
        run_id=1,
        source_id=42,
    )

    with tel.stage("PASS1_EXEC", "Pass 1 DB execution — 100 columns", batch_number=0):
        pass1_df = reader.read_df(p1_sql).cache()

The POST to /job_stage is sent on a daemon thread so it never blocks the Spark job.
If the API is unreachable the warning is logged and execution continues normally.
"""

import logging
import threading
import time
from contextlib import contextmanager
from datetime import datetime, timezone
from typing import Generator

import requests

log = logging.getLogger(__name__)


class TelemetryClient:
    def __init__(
        self,
        api_base_url: str,
        run_id: int,
        source_id: int,
        port: int = 8080,
        session: requests.Session | None = None,
    ) -> None:
        self.run_id = run_id
        self.source_id = source_id
        self.endpoint = f"{api_base_url.rstrip('/')}:{port}/job_stage"
        self._session = session or requests.Session()

    # ------------------------------------------------------------------
    # Public context manager
    # ------------------------------------------------------------------

    @contextmanager
    def stage(
        self,
        pass_stage: str,
        description: str,
        batch_number: int = 0,
    ) -> Generator[None, None, None]:
        """Context manager that wraps one profiling stage with RUNNING / COMPLETED / ERROR telemetry.

        Example
        -------
            with telemetry.stage("PASS1_EXEC", "Pass 1 execution", batch_number=2):
                result = db.execute(sql)
        """
        start_ts = datetime.now(timezone.utc)
        t0 = time.monotonic()

        self._emit(
            pass_stage=pass_stage,
            description=description,
            batch_number=batch_number,
            status="RUNNING",
            start_ts=start_ts,
            end_ts=None,
            error_code=None,
            error_desc=None,
        )

        try:
            yield
        except Exception as exc:
            elapsed = time.monotonic() - t0
            end_ts = datetime.now(timezone.utc)
            error_code = type(exc).__name__
            error_desc = str(exc)[:2000]      # truncate very long exception messages

            self._emit(
                pass_stage=pass_stage,
                description=description,
                batch_number=batch_number,
                status="ERROR",
                start_ts=start_ts,
                end_ts=end_ts,
                error_code=error_code,
                error_desc=error_desc,
            )
            log.error(
                "[TELEMETRY] stage=%s batch=%d ERROR after %.2fs | %s: %s",
                pass_stage, batch_number, elapsed, error_code, error_desc,
            )
            raise
        else:
            elapsed = time.monotonic() - t0
            end_ts = datetime.now(timezone.utc)

            self._emit(
                pass_stage=pass_stage,
                description=description,
                batch_number=batch_number,
                status="COMPLETED",
                start_ts=start_ts,
                end_ts=end_ts,
                error_code=None,
                error_desc=None,
            )
            log.info(
                "[TELEMETRY] stage=%s batch=%d COMPLETED in %.2fs",
                pass_stage, batch_number, elapsed,
            )

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _emit(
        self,
        *,
        pass_stage: str,
        description: str,
        batch_number: int,
        status: str,
        start_ts: datetime | None,
        end_ts: datetime | None,
        error_code: str | None,
        error_desc: str | None,
    ) -> None:
        payload = {
            "run_id":            self.run_id,
            "source_id":         self.source_id,
            "batch_number":      batch_number,
            "pass_stage":        pass_stage,
            "stage_description": description,
            "status":            status,
            "stage_start_ts":    start_ts.isoformat() if start_ts else None,
            "stage_end_ts":      end_ts.isoformat() if end_ts else None,
            "error_code":        error_code,
            "error_desc":        error_desc,
        }

        # Structured log line — always written regardless of API availability.
        _log_level = logging.ERROR if status == "ERROR" else logging.INFO
        log.log(
            _log_level,
            "[TELEMETRY] run_id=%s source_id=%s stage=%s batch=%d status=%s%s",
            self.run_id,
            self.source_id,
            pass_stage,
            batch_number,
            status,
            f" | {error_code}: {error_desc}" if error_code else "",
        )

        # Non-blocking POST — daemon thread so it never delays job completion.
        threading.Thread(
            target=self._post,
            args=(payload,),
            daemon=True,
        ).start()

    def _post(self, payload: dict) -> None:
        try:
            resp = self._session.post(self.endpoint, json=payload, timeout=5)
            if not resp.ok:
                log.warning(
                    "[TELEMETRY] POST %s returned HTTP %d", self.endpoint, resp.status_code
                )
        except Exception as exc:
            log.warning("[TELEMETRY] POST %s failed (non-fatal): %s", self.endpoint, exc)
