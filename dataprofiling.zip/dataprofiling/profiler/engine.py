"""EnterpriseProfilerEngine — top-level job orchestrator.

Pass-1 results arrive as Shape B (one row per column, one column per stat)
from to_wide_df().  Pass-2 percentile stats (Postgres/MySQL only) are merged
into the same Shape B via a LEFT JOIN + COALESCE.

Cross-batch accumulation
------------------------
_execute_batch() returns a BatchResult instead of writing to GCS directly.
execute_job() accumulates BatchResult objects across all batches, then calls
_write_all() once after the batch loop — one Parquet write for metrics across
all 60 batches (for a 6000-column table), one NDJSON write each for
distributions, patterns and histograms.

Shape B DataFrames across batches have identical schemas (same stat registry
per run), so UNION ALL works cleanly for the single metrics write.
"""

import logging
from dataclasses import dataclass, field
from functools import reduce
from pyspark.sql import SparkSession, DataFrame, functions as F

from .constants import MAX_SAMPLE_ROWS
from .dialect import load_dialect
from .jdbc import JdbcReader
from .bq_partition import detect as detect_bq_partition
from .catalog import fetch_active_columns, filter_active_columns
from .pass1 import _wide_from_flat, build_pass1_sql, to_wide_df
from .pass2 import build_pass2_sql
from .pass3 import build_pass3_sql, split_pass3_results
from .pass4 import MAX_PASS4_COLUMNS, results_to_df, run_normality_tests
from .planner import build_plan_df, get_plan_rows
from .telemetry import TelemetryClient

log = logging.getLogger(__name__)

_PASS2_PERCENTILE_STATS = ["p25", "p50", "p75", "p90", "p95", "p99"]


# ---------------------------------------------------------------------------
# Per-batch result carrier
# ---------------------------------------------------------------------------

@dataclass
class BatchResult:
    """Holds all outputs from one batch.  Collected across batches in execute_job()
    and written to GCS in a single write_all() call after the loop."""
    metrics_df: DataFrame         # Shape B — one row per column, cached
    freqs:      list[dict] = field(default_factory=list)
    patterns:   list[dict] = field(default_factory=list)
    hists:      list[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Engine
# ---------------------------------------------------------------------------

class EnterpriseProfilerEngine:
    def __init__(
        self,
        spark: SparkSession,
        pg_creds: dict,
        jdbc_url: str,
        driver: str,
        source_platform: str,
        execution_tier: str,
        api_base_url: str,
        api_port: int = 8080,
    ) -> None:
        import psycopg2

        self.spark = spark
        self.pg_conn = psycopg2.connect(**pg_creds)
        self.platform = source_platform.upper()
        self.execution_tier = execution_tier.upper()
        self.api_base_url = api_base_url
        self.api_port = api_port

        self.dialect, self.pass1_stats, self.pass2_stats, self.dependencies = load_dialect(
            self.platform, api_base_url
        )

        self.reader = JdbcReader(
            spark=spark,
            jdbc_url=jdbc_url,
            user=pg_creds.get("user", ""),
            password=pg_creds.get("password", pg_creds.get("nbfgc", "")),
            driver=driver,
        )

    # ------------------------------------------------------------------
    # Batching
    # ------------------------------------------------------------------

    def _batches(self, columns: list[dict]):
        size = 4000 if self.platform == "BQ" else 100
        for i in range(0, len(columns), size):
            yield i // size, columns[i : i + size]

    # ------------------------------------------------------------------
    # Sampling
    # ------------------------------------------------------------------

    def _sample_clause(self, total_rows: int) -> tuple[str, float]:
        if total_rows <= MAX_SAMPLE_ROWS:
            return "", 100.0
        pct = (MAX_SAMPLE_ROWS / total_rows) * 100.0
        if self.platform == "BQ":
            return f" TABLESAMPLE SYSTEM ({pct} PERCENT)", pct
        return "", 100.0

    # ------------------------------------------------------------------
    # Main entry point — accumulate across batches, write once
    # ------------------------------------------------------------------

    def execute_job(
        self,
        run_id: int,
        source_id: int,
        target_table: str,
        config_columns: list[dict],
    ) -> None:
        tel = TelemetryClient(
            api_base_url=self.api_base_url,
            run_id=run_id,
            source_id=source_id,
            port=self.api_port,
        )

        # ---- Pre-flight: decommission guard --------------------------------
        # Query the source DB catalog once before any batch runs.  Columns
        # that no longer exist in the table are removed from config_columns
        # so all four passes never reference them.  If the catalog query
        # fails the check is skipped and downstream errors surface naturally.
        with tel.stage(
            "COLUMN_VALIDATE",
            f"Validating config columns against {self.platform} catalog for {target_table}",
            batch_number=-1,
        ):
            active_cols = fetch_active_columns(target_table, self.reader, self.platform)
            config_columns, decommissioned = filter_active_columns(config_columns, active_cols)

        if decommissioned:
            log.warning(
                "run_id=%s: %d decommissioned column(s) excluded from all passes: %s",
                run_id, len(decommissioned), decommissioned,
            )
        if not config_columns:
            log.error(
                "run_id=%s: all configured columns are decommissioned — nothing to profile.",
                run_id,
            )
            return

        batch_results: list[BatchResult] = []

        for batch_num, batch_cols in self._batches(config_columns):
            result = self._execute_batch(run_id, batch_num, target_table, batch_cols, tel)
            if result is not None:
                batch_results.append(result)

        if not batch_results:
            log.warning("run_id=%s: all batches empty or skipped, nothing to write.", run_id)
            return

        # Single GCS write for the whole run.
        with tel.stage("OUTPUT", f"GCS write — run_id={run_id} table={target_table}", batch_number=-1):
            # UNION ALL Shape B DataFrames across batches — identical schemas per run.
            all_metrics_df = reduce(lambda a, b: a.union(b),
                                    [r.metrics_df for r in batch_results])
            all_freqs     = [row for r in batch_results for row in r.freqs]
            all_patterns  = [row for r in batch_results for row in r.patterns]
            all_hists     = [row for r in batch_results for row in r.hists]

            self._write_all(run_id, all_metrics_df, all_freqs, all_patterns, all_hists)

            # Release batch caches after the union and write are complete.
            for r in batch_results:
                r.metrics_df.unpersist()

    # ------------------------------------------------------------------
    # Per-batch execution — returns BatchResult, never writes directly
    # ------------------------------------------------------------------

    def _execute_batch(
        self,
        run_id: int,
        batch_num: int,
        target_table: str,
        batch_cols: list[dict],
        tel: TelemetryClient,
    ) -> BatchResult | None:
        n_cols = len(batch_cols)

        # ---- BQ partition detection (runs once per batch, before Pass 1) --
        # For partitioned BQ tables, constrains all passes to the latest
        # partition only, avoiding petabyte-scale full-table scans.
        # Returns empty string for non-BQ platforms or unpartitioned tables.
        if self.platform == "BQ":
            with tel.stage(
                "PARTITION_DETECT",
                f"Detecting latest BQ partition for {target_table}",
                batch_number=batch_num,
            ):
                bq_part = detect_bq_partition(target_table, self.reader)
            partition_filter = bq_part.where_clause
            if partition_filter:
                log.info(
                    "Batch %d: BQ partition filter applied —%s",
                    batch_num, partition_filter,
                )
        else:
            partition_filter = ""

        # ---- Pass 1 -------------------------------------------------------
        p1_sql = build_pass1_sql(
            target_table=target_table,
            batch_cols=batch_cols,
            dialect=self.dialect,
            platform=self.platform,
            pass1_stats=self.pass1_stats,
            execution_tier=self.execution_tier,
            dependencies=self.dependencies,
            partition_filter=partition_filter,
        )
        if not p1_sql:
            log.info("Batch %d: no Pass-1 stats selected, skipping.", batch_num)
            return None

        with tel.stage(
            "PASS1_EXEC",
            f"Pass 1 DB execution — {n_cols} columns on {target_table}",
            batch_number=batch_num,
        ):
            pass1_df = self.reader.read_df(p1_sql).cache()
            total_rows = int(pass1_df.select("total_rows").first()[0])

        if not total_rows:
            log.info("Batch %d: source table is empty, skipping.", batch_num)
            pass1_df.unpersist()
            return None

        sample_clause, sample_pct = self._sample_clause(total_rows)

        # ---- Plan / column classification ---------------------------------
        # to_wide_df() is a passthrough for JSON-pack platforms and a Spark
        # pivot for MySQL/SingleStore.  Defer pass1_df.unpersist() until
        # plan_df is first materialised (first get_plan_rows call).
        with tel.stage(
            "PLAN_BUILD",
            f"Column classification — {n_cols} columns, {total_rows:,} rows",
            batch_number=batch_num,
        ):
            wide_df = to_wide_df(self.spark, pass1_df, self.platform)
            plan_df = build_plan_df(
                spark=self.spark,
                batch_cols=batch_cols,
                wide_df=wide_df,
                total_rows=total_rows,
                pass2_stats=self.pass2_stats,
            )

        # ---- Pass 2: sampled percentiles (Postgres / MySQL only) ----------
        if self.platform not in ("BQ", "ORACLE", "SINGLESTORE"):
            p2_rows = get_plan_rows(
                plan_df,
                cols=["column_name", "include_pass2", "pass2_stats"],
            )
            pass1_df.unpersist()   # plan_df now cached; pass1 lineage released

            p2_sql = build_pass2_sql(
                target_table=target_table,
                sample_clause=sample_clause,
                plan_rows=p2_rows,
                dialect=self.dialect,
                pass2_stats=self.pass2_stats,
                platform=self.platform,
                partition_filter=partition_filter,
            )
            if p2_sql:
                with tel.stage(
                    "PASS2_EXEC",
                    f"Pass 2 sampled percentiles — {target_table}",
                    batch_number=batch_num,
                ):
                    p2_df = self.reader.read_df(p2_sql)
                    # _wide_from_flat converts flat col__stat aliases → Shape B
                    # (column_name, p25, p50, p75, …) one row per eligible column.
                    p2_wide = _wide_from_flat(self.spark, p2_df)

                    # Merge pass2 percentile columns into wide_df via LEFT JOIN +
                    # COALESCE.  Pass1 wide_df has NULL for these stats on
                    # Postgres/MySQL; p2_wide fills them in for eligible columns.
                    p2_stat_cols = [
                        c for c in p2_wide.columns
                        if c != "column_name" and c in _PASS2_PERCENTILE_STATS
                    ]
                    if p2_stat_cols:
                        p2_select = p2_wide.select(
                            "column_name",
                            *[F.col(s).alias(f"_p2_{s}") for s in p2_stat_cols],
                        )
                        wide_df = wide_df.join(p2_select, on="column_name", how="left")
                        for s in p2_stat_cols:
                            src = F.col(s) if s in wide_df.columns else F.lit(None)
                            wide_df = wide_df.withColumn(
                                s, F.coalesce(src, F.col(f"_p2_{s}"))
                            ).drop(f"_p2_{s}")
            else:
                log.info("Batch %d: Pass 2 — no eligible columns.", batch_num)
        else:
            log.info(
                "Batch %d: Pass 2 skipped — platform=%s, percentiles in Pass 1.",
                batch_num, self.platform,
            )

        # ---- Pass 3: distributions + histograms ---------------------------
        p3_rows = get_plan_rows(
            plan_df,
            cols=["column_name", "data_type", "include_freq", "include_pattern",
                  "include_hist", "min_val", "max_val", "hist_bins"],
        )
        if self.platform in ("BQ", "ORACLE", "SINGLESTORE"):
            pass1_df.unpersist()   # first plan materialisation for these platforms

        p3_sql = build_pass3_sql(
            target_table=target_table,
            sample_clause=sample_clause,
            plan_rows=p3_rows,
            platform=self.platform,
        )

        freq_payloads:    list[dict] = []
        pattern_payloads: list[dict] = []
        hist_payloads:    list[dict] = []

        if p3_sql:
            gs_or_union = (
                "GROUPING SETS"
                if self.platform in ("BQ", "ORACLE", "POSTGRES", "SINGLESTORE")
                else "UNION ALL"
            )
            with tel.stage(
                "PASS3_EXEC",
                f"Pass 3 distributions+histograms — {gs_or_union} path on {target_table}",
                batch_number=batch_num,
            ):
                p3_rows_result = self.reader.read_rows(p3_sql)
                extrapolation = 100.0 / sample_pct if sample_pct < 100.0 else 1.0
                freq_payloads, pattern_payloads, hist_payloads = split_pass3_results(
                    p3_rows_result, extrapolation
                )
        else:
            log.info("Batch %d: Pass 3 — no eligible columns.", batch_num)

        # ---- Pass 4: normality tests (up to MAX_PASS4_COLUMNS per batch) ----
        # Runs after pass1+pass2 are merged so wide_df already has mean/stddev
        # that could inform the KS test's parameter estimation.
        # Results are joined back into wide_df as additional columns.
        norm_eligible = [
            c for c in batch_cols if c.get("normality_test")
        ]
        if norm_eligible:
            with tel.stage(
                "PASS4_EXEC",
                f"Pass 4 normality tests — up to {MAX_PASS4_COLUMNS} columns",
                batch_number=batch_num,
            ):
                norm_results = run_normality_tests(
                    target_table=target_table,
                    sample_clause=sample_clause,
                    batch_cols=batch_cols,
                    reader=self.reader,
                    platform=self.platform,
                )
                if norm_results:
                    norm_df = results_to_df(self.spark, norm_results)
                    wide_df = wide_df.join(norm_df, on="column_name", how="left")
        else:
            log.info("Batch %d: Pass 4 — no columns have normality_test set.", batch_num)

        # ---- Build metrics Shape B for this batch -------------------------
        # Add run_id column so the accumulated DataFrame is self-describing.
        # Cache so that execute_job() can UNION ALL across batches without
        # re-triggering the JDBC reads.
        metrics_df = wide_df.withColumn("run_id", F.lit(run_id)).cache()

        plan_df.unpersist()

        return BatchResult(
            metrics_df=metrics_df,
            freqs=freq_payloads,
            patterns=pattern_payloads,
            hists=hist_payloads,
        )

    # ------------------------------------------------------------------
    # Single-run output — replaced by GCSOutputWriter in production
    # ------------------------------------------------------------------

    def _write_all(
        self,
        run_id: int,
        metrics_df: DataFrame,
        freqs: list[dict],
        patterns: list[dict],
        hists: list[dict],
    ) -> None:
        """Stub — production implementation writes to GCS as Parquet (metrics)
        and NDJSON (distributions, patterns, histograms) then publishes to PubSub.

        metrics_df  — Shape B, one row per profiled column across all batches
        freqs       — frequency distribution payloads
        patterns    — pattern distribution payloads
        hists       — histogram bucket payloads
        """
        _ = (run_id, metrics_df, freqs, patterns, hists)
