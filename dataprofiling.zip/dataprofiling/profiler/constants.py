MAX_SAMPLE_ROWS = 1_000_000
TOP_K = 10
FREQ_LIMIT = 1_000
PATTERN_LIMIT = 100

# Maximum number of grouping-set slots per platform before we split into
# batches (each batch is one GROUPING SETS clause, batches are UNION ALL'd).
# MySQL is absent: it uses the pure UNION ALL path.
GROUPING_SETS_LIMITS: dict[str, int] = {
    "ORACLE": 32,
    "BQ": 50,
    "POSTGRES": 64,
    "SINGLESTORE": 64,
}

# Platforms where Pass 1 packs all per-column stats into a single JSON
# aggregate column instead of N*stats flat aliases, keeping the SELECT list
# under each platform's column-count ceiling.
JSON_PACK_PLATFORMS: frozenset[str] = frozenset({"BQ", "ORACLE", "POSTGRES"})

# CAST type name for floating-point arithmetic in bucket expressions.
DOUBLE_TYPE: dict[str, str] = {
    "BQ": "FLOAT64",
    "ORACLE": "BINARY_DOUBLE",
    "POSTGRES": "DOUBLE PRECISION",
    "MYSQL": "DOUBLE",
    "SINGLESTORE": "DOUBLE",
}
