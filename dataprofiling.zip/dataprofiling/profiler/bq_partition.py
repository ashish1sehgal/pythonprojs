"""BigQuery partition detection and latest-partition WHERE clause generation.

When a BQ table is partitioned, profiling every pass on the full table can
scan petabytes of data.  This module detects the partition column and finds
the latest partition_id from INFORMATION_SCHEMA, then builds a WHERE clause
that constrains all passes to that partition only.

Partition-id format → WHERE clause
------------------------------------
  YYYYMMDD  (8 digits, date column)
      WHERE {col} = SAFE.PARSE_DATE('%Y%m%d', '{partition_id}')

  YYYYMM    (6 digits, date column)
      WHERE {col} = SAFE.PARSE_DATE('%Y%m', '{partition_id}')

  YYYY      (4 digits, date column)
      WHERE {col} = SAFE.PARSE_DATE('%Y', '{partition_id}')

  Numeric   (INT64 / NUMERIC partition column)
      WHERE {col} = {partition_id}

Non-partitioned tables return an empty string so all passes run unchanged.

Detection query
---------------
Two INFORMATION_SCHEMA tables are joined:
  INFORMATION_SCHEMA.PARTITIONS  — latest partition_id per table
  INFORMATION_SCHEMA.COLUMNS     — partition column name and data_type

Both are scoped to the same project.dataset prefix as the target table.
Sentinel partition_ids (__NULL__, __UNPARTITIONED__, etc.) are excluded.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .jdbc import JdbcReader

log = logging.getLogger(__name__)

# Partition IDs emitted by BQ for unpartitioned / streaming rows
_SENTINEL_IDS = frozenset({
    "__NULL__",
    "__UNPARTITIONED__",
    "__STREAMING_UNPARTITIONED__",
})

# BQ column data types that represent date/time and need SAFE.PARSE_DATE
_DATE_TYPES = frozenset({"DATE", "DATETIME", "TIMESTAMP"})


@dataclass
class BQPartitionInfo:
    """Holds the detected partition metadata for one BQ table."""
    is_partitioned:  bool  = False
    column_name:     str   = ""
    data_type:       str   = ""   # BQ data type, e.g. DATE, INT64
    partition_id:    str   = ""   # raw value from INFORMATION_SCHEMA
    where_clause:    str   = ""   # ready-to-use WHERE ... clause (leading space)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect(target_table: str, reader: "JdbcReader") -> BQPartitionInfo:
    """Query INFORMATION_SCHEMA to find partition metadata for *target_table*.

    Returns a BQPartitionInfo with is_partitioned=False and an empty
    where_clause if the table is unpartitioned or if the detection query
    fails (the caller then falls back to a full-table scan).

    Args:
        target_table – fully-qualified BQ table reference,
                       e.g. ``axp-lumi.data.risk_indv_cust``
                       or   `` `axp-lumi.data.risk_indv_cust` ``
        reader       – JdbcReader used to execute the INFORMATION_SCHEMA query
    """
    project, dataset, table_name = _parse_table_ref(target_table)
    if not dataset or not table_name:
        log.warning("bq_partition: cannot parse table ref '%s'; skipping detection.", target_table)
        return BQPartitionInfo()

    sql = _info_schema_sql(project, dataset, table_name)
    try:
        rows = reader.read_rows(sql)
    except Exception as exc:
        log.warning(
            "bq_partition: INFORMATION_SCHEMA query failed for '%s' — %s. "
            "Falling back to full-table scan.",
            target_table, exc,
        )
        return BQPartitionInfo()

    if not rows:
        log.info("bq_partition: '%s' is not partitioned — full-table scan.", table_name)
        return BQPartitionInfo()

    row = rows[0]
    partition_id = str(row.get("partition_id", "")).strip()
    column_name  = str(row.get("column_name", "")).strip()
    data_type    = str(row.get("data_type", "")).strip().upper()

    if not partition_id or partition_id in _SENTINEL_IDS:
        log.info("bq_partition: '%s' has only sentinel partitions; full-table scan.", table_name)
        return BQPartitionInfo()

    where = _build_where(column_name, data_type, partition_id)
    log.info(
        "bq_partition: '%s' partitioned by %s (%s); latest partition_id=%s — %s",
        table_name, column_name, data_type, partition_id, where.strip(),
    )
    return BQPartitionInfo(
        is_partitioned=True,
        column_name=column_name,
        data_type=data_type,
        partition_id=partition_id,
        where_clause=where,
    )


# ---------------------------------------------------------------------------
# INFORMATION_SCHEMA query builder
# ---------------------------------------------------------------------------

def _info_schema_sql(project: str | None, dataset: str, table_name: str) -> str:
    """Builds the query that returns (partition_id, column_name, data_type)
    for the latest non-sentinel partition of *table_name*."""
    if project:
        prefix = f"`{project}.{dataset}`"
    else:
        prefix = f"`{dataset}`"

    return f"""
SELECT
  p.partition_id,
  c.column_name,
  c.data_type
FROM {prefix}.INFORMATION_SCHEMA.PARTITIONS p
JOIN {prefix}.INFORMATION_SCHEMA.COLUMNS c
  ON  c.table_name            = p.table_name
  AND c.is_partitioning_column = 'YES'
WHERE p.table_name   = '{table_name}'
  AND p.partition_id NOT IN (
        '__NULL__', '__UNPARTITIONED__', '__STREAMING_UNPARTITIONED__'
  )
ORDER BY p.partition_id DESC
LIMIT 1
""".strip()


# ---------------------------------------------------------------------------
# WHERE clause builder
# ---------------------------------------------------------------------------

def _build_where(column_name: str, data_type: str, partition_id: str) -> str:
    """Returns a WHERE clause string (with a leading space) for the given
    partition column and latest partition_id.

    Date/time columns: SAFE.PARSE_DATE with the appropriate format for the
    partition_id length (daily=8, monthly=6, yearly=4 digits).

    Numeric columns: direct integer comparison.
    """
    if data_type in _DATE_TYPES:
        pid_len = len(partition_id.replace("-", "").replace("_", ""))
        if pid_len == 8:
            fmt = "%Y%m%d"
        elif pid_len == 6:
            fmt = "%Y%m"
        elif pid_len == 4:
            fmt = "%Y"
        else:
            log.warning(
                "bq_partition: unrecognised partition_id length %d for '%s'; "
                "skipping partition filter.",
                pid_len, partition_id,
            )
            return ""
        return f" WHERE {column_name} = SAFE.PARSE_DATE('{fmt}', '{partition_id}')"

    # Numeric / INT64 / NUMERIC partition column
    try:
        int(partition_id)   # validate it's a plain integer
        return f" WHERE {column_name} = {partition_id}"
    except ValueError:
        log.warning(
            "bq_partition: partition_id '%s' is not numeric and column type is %s; "
            "falling back to full scan.",
            partition_id, data_type,
        )
        return ""


# ---------------------------------------------------------------------------
# Table-reference parser
# ---------------------------------------------------------------------------

def _parse_table_ref(table_ref: str) -> tuple[str | None, str | None, str | None]:
    """Splits a BQ table reference into (project, dataset, table).

    Handles:
      project.dataset.table
      `project.dataset.table`
      dataset.table
    """
    cleaned = table_ref.strip().strip("`")
    parts = cleaned.split(".")
    if len(parts) == 3:
        return parts[0], parts[1], parts[2]
    if len(parts) == 2:
        return None, parts[0], parts[1]
    return None, None, parts[0] if parts else None
