-- ==============================================================================
-- stat_cost_config revision: remove max_standard_columns_per_run
-- ==============================================================================
--
-- Rationale
-- ---------
-- max_standard_columns_per_run was introduced to prevent hitting Oracle's
-- ~1000 SELECT expression limit per query.
--
-- With 50-column batching in place:
--   max aliases per SELECT = batch_size × avg_aliases_per_column
--                         = 50 × ~8 = ~400   (well below Oracle's limit)
--
-- The per-run column count is therefore NOT a DB expression concern.
-- Removing it eliminates a misleading guardrail that would block a legitimate
-- 2000-column table from being profiled at STANDARD pack.
--
-- What replaces it
-- ----------------
-- The alias limit is now enforced at the BATCH level via:
--   batch_size_pass1             (max columns per SQL SELECT)
--   oracle_max_aliases_per_select (safety ceiling the governor uses to
--                                  auto-reduce batch_size when a column
--                                  has many stat aliases)
--
-- The time/load concern is addressed by:
--   max_advanced_columns_per_run (still enforced — each ADVANCED column
--                                 adds a dedicated full-table GROUP BY scan)
--
-- Migration
-- ---------
-- DELETE the row. Any reference to this key in application code will return
-- NULL from the config lookup, which callers must handle as "no limit".
-- The config_validator.py _check_limits() method is updated below to remove
-- the STANDARD column count check entirely.

DELETE FROM stat_cost_config WHERE config_key = 'max_standard_columns_per_run';
DELETE FROM stat_cost_config WHERE config_key = 'warn_standard_columns';

-- Add a clarifying comment to batch_size_pass1 explaining it IS the alias guard
UPDATE stat_cost_config
SET    description = 'Columns per Pass-1 JDBC batch. '
                  || 'This is the primary guard against Oracle''s ~1000 SELECT expression limit. '
                  || 'max_aliases_per_batch = batch_size_pass1 × avg_stat_aliases_per_column. '
                  || 'At 50 columns × 8 aliases = 400 — well below Oracle''s ceiling. '
                  || 'Reduce this (not total column count) if a specific column config '
                  || 'generates an unusually high alias count.'
WHERE  config_key = 'batch_size_pass1';

UPDATE stat_cost_config
SET    description = 'Safety ceiling below Oracle''s hard 1000-expression SELECT limit. '
                  || 'CostGovernor computes: safe_batch_size = FLOOR(this_value / max_aliases_in_worst_case_column). '
                  || 'If safe_batch_size < batch_size_pass1, the batch size is automatically reduced '
                  || 'for that run — no user action required. '
                  || 'Not a per-run column count limit; purely a per-SELECT expression guard.'
WHERE  config_key = 'oracle_max_aliases_per_select';

-- Add a new key that makes the time-based concern explicit and configurable
INSERT INTO stat_cost_config (config_key, config_value, description) VALUES
('max_run_duration_minutes', 240,
 'Soft wall-clock limit for a single profiling run in minutes. '
 'At batch_size=50 and ~3 min/batch, 2000 STANDARD columns ≈ 120 min. '
 'The Airflow DAG uses this value to set its task timeout. '
 'Not enforced by the profiler engine itself — enforced by the scheduler. '
 'Increase for very wide tables on fast source DBs; decrease for SLA-sensitive pipelines.')
ON CONFLICT (config_key) DO NOTHING;

-- Final state of stat_cost_config after this migration:
--
--   max_advanced_columns_per_run   25    (still enforced — GROUP BY scan per col)
--   warn_advanced_columns          10    (still enforced — advisory)
--   batch_size_pass1               50    (alias guard, replaces per-run col limit)
--   batch_size_pass2               10    (pass 2 batch size)
--   oracle_max_aliases_per_select  900   (auto-reduces batch_size if needed)
--   histogram_default_buckets      20
--   target_sample_rows             1000000
--   min_sample_rows                50000
--   distribution_cardinality_cap   50000
--   categorical_threshold          1000
--   primary_key_ratio              0.95
--   high_cardinality_ratio         0.10
--   max_run_duration_minutes       240   (NEW — scheduler timeout reference)

-- ==============================================================================
-- Pass 3 batch size config
-- ==============================================================================
-- batch_size_pass3 governs the UNION ALL batch size for distributions,
-- patterns, and histograms. Separate from Pass 1/2 because the constraint
-- is result set height (top_n rows × batch_size), not SELECT alias width.
--
-- At top_n=10 and batch_size_pass3=10: 100 rows per JDBC call — negligible.
-- At top_n=10 and batch_size_pass3=25: 250 rows per JDBC call — still fine.
-- The practical ceiling is DB query plan complexity for large UNION ALL chains.
-- Oracle starts showing plan instability above ~20 UNION ALL branches.
-- BigQuery: APPROX_QUANTILES batch uses a single SELECT (no UNION ALL) — batch
-- size can be higher; governed by query byte budget, not branch count.

INSERT INTO stat_cost_config (config_key, config_value, description) VALUES
('batch_size_pass3', 10,
 'Columns per Pass-3 UNION ALL batch (distributions, patterns, histograms). '
 'Governs result set height, not SELECT alias width. '
 'Each column contributes top_n rows to the UNION ALL result. '
 'Oracle: keep <= 20 (plan instability above ~20 UNION ALL branches). '
 'BigQuery: histogram batch uses a single SELECT with APPROX_QUANTILES per column '
 '— governed by query complexity budget, not branch count; can be higher (up to 50).')
ON CONFLICT (config_key) DO UPDATE SET
    config_value = EXCLUDED.config_value,
    description  = EXCLUDED.description;
