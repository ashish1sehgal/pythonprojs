"""Entry point for the Enterprise Data Profiler Spark job.

Usage:
    spark-submit main.py --sourceid 42 --version 3
"""

import argparse
import logging
import os

import requests
from pyspark.sql import SparkSession

from profiler.engine import EnterpriseProfilerEngine

logging.basicConfig(level=logging.INFO)
log = logging.getLogger(__name__)


def _parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Enterprise Data Profiler")
    p.add_argument("--sourceid", type=int, required=True)
    p.add_argument("--version",  type=int, required=True)
    return p.parse_args()


def _fetch_config(api_base: str, source_id: int, version: int) -> list[dict]:
    url = f"{api_base}/api/v1/profiling/configs/attributeselectedstats"
    resp = requests.get(url, params={"sourceId": source_id, "version": version})
    resp.raise_for_status()
    return resp.json()


def _build_spark() -> SparkSession:
    os.environ.setdefault("SPARK_LOCAL_HOSTNAME", "localhost")
    return (
        SparkSession.builder
        .appName("EnterpriseProfiler")
        .config("spark.jars", "/Users/asehg24/EDM/postgresql-42.7.3.jar")
        .config("spark.driver.bindAddress", "127.0.0.1")
        .getOrCreate()
    )


def main() -> None:
    args = _parse_args()

    API_BASE = "http://localhost:8080"
    SOURCE_PLATFORM = "PSQL"          # PSQL | ORACLE | BQ | MYSQL | SINGLESTORE
    EXECUTION_TIER  = "ADVANCED"
    TARGET_TABLE    = "dqf.dqf_source"
    RUN_ID          = 1

    config_columns = _fetch_config(API_BASE, args.sourceid, args.version)
    log.info("Loaded %d column configs for sourceId=%d v%d.",
             len(config_columns), args.sourceid, args.version)

    spark = _build_spark()

    engine = EnterpriseProfilerEngine(
        spark=spark,
        pg_creds={
            "host":   "hvidldqmdb03.phx.aexp.com",
            "port":   5432,
            "dbname": "dqfdb",
            "user":   "dqf_app",
            "password": "Dq!f@E1usr",
        },
        jdbc_url="jdbc:postgresql://hvidldqmdb03.phx.aexp.com:5432/dqfdb",
        driver="org.postgresql.Driver",
        source_platform=SOURCE_PLATFORM,
        execution_tier=EXECUTION_TIER,
        api_base_url=API_BASE,
    )

    engine.execute_job(
        run_id=RUN_ID,
        source_id=args.sourceid,
        target_table=TARGET_TABLE,
        config_columns=config_columns,
    )


if __name__ == "__main__":
    main()
