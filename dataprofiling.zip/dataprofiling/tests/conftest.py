"""Shared pytest fixtures for the profiler test suite.

All DB/network boundaries are mocked here so no external connections are
required.  The local SparkSession is scoped to the test session so Spark
starts once and is reused across all Spark-dependent tests.
"""

import pytest
from unittest.mock import MagicMock
from pyspark.sql import SparkSession


# ---------------------------------------------------------------------------
# Spark
# ---------------------------------------------------------------------------

@pytest.fixture(scope="session")
def spark():
    return (
        SparkSession.builder
        .master("local[2]")
        .appName("profiler-tests")
        .config("spark.sql.shuffle.partitions", "2")
        .config("spark.ui.enabled", "false")
        .getOrCreate()
    )


# ---------------------------------------------------------------------------
# Dialect / stat registry (replaces the real API call)
# ---------------------------------------------------------------------------

@pytest.fixture
def dialect():
    """Minimal stat registry covering all stat names used in tests.

    Key format mirrors what `render_stat()` expects: `{col}` or `<<col>>` as
    the column placeholder (both are substituted by render_stat).
    """
    return {
        "empty_count":            "COUNT(CASE WHEN {col} IS NULL THEN 1 END)",
        "distinct_count":         "APPROX_COUNT_DISTINCT({col})",
        "min":                    "MIN({col})",
        "max":                    "MAX({col})",
        "mean_value":             "AVG({col})",
        "distinct_pattern_count": "APPROX_COUNT_DISTINCT(REGEXP_REPLACE({col},'[A-Za-z0-9]','X'))",
        "p25":                    "APPROX_QUANTILES({col},100)[OFFSET(25)]",
        "p50":                    "APPROX_QUANTILES({col},100)[OFFSET(50)]",
        "p75":                    "APPROX_QUANTILES({col},100)[OFFSET(75)]",
        "zero_count":             "COUNTIF({col} = 0)",
    }


@pytest.fixture
def pass1_stats(dialect):
    return list(dialect.keys())


@pytest.fixture
def pass2_stats():
    return ["p25", "p50", "p75"]


# ---------------------------------------------------------------------------
# Standard batch of two columns (one numeric, one string)
# ---------------------------------------------------------------------------

@pytest.fixture
def batch_cols():
    return [
        {
            "attributeName": "user_id",
            "dataTypeCategory": "numeric",
            "selectedStats": ["empty_count", "distinct_count", "min", "max", "mean_value"],
            "sensitiveTag": None,
        },
        {
            "attributeName": "status",
            "dataTypeCategory": "string",
            "selectedStats": ["empty_count", "distinct_count", "distinct_pattern_count"],
            "sensitiveTag": None,
        },
    ]


# ---------------------------------------------------------------------------
# Mock JdbcReader
# ---------------------------------------------------------------------------

@pytest.fixture
def mock_reader(spark):
    """JdbcReader stub.  Tests set .read_df.return_value / .read_rows.return_value
    to control what the 'DB' returns."""
    reader = MagicMock()
    reader.read_df.return_value = spark.createDataFrame([], "column_name string")
    reader.read_rows.return_value = []
    return reader


# ---------------------------------------------------------------------------
# Realistic Shape B DataFrame (simulates Postgres Pass-1 output)
# ---------------------------------------------------------------------------

@pytest.fixture
def pass1_shape_b(spark):
    """Two-column Shape B DataFrame as Postgres/Oracle/BQ pass1 SQL would return:
    one row per column, one column per stat.
    """
    return spark.createDataFrame(
        [
            # user_id: numeric, high-cardinality
            (1_000_000, "user_id", "900000", "1",    "999999", None,  "500000", None,  None,  None),
            # status: string, low-cardinality
            (1_000_000, "status",  "8",      None,   None,     "4",   None,     None,  None,  None),
        ],
        "total_rows long, column_name string, distinct_count string, "
        "min string, max string, distinct_pattern_count string, mean_value string, "
        "p25 string, p50 string, p75 string",
    )
