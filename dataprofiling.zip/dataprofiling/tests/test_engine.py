"""Integration tests for EnterpriseProfilerEngine._execute_batch().

All four external call boundaries are mocked:
  - psycopg2.connect()          → patch("psycopg2.connect")
  - dialect.load_dialect()      → patch("profiler.engine.load_dialect")
  - JdbcReader (JDBC)           → eng.reader = MagicMock()
  - TelemetryClient._post()     → TelemetryClient(session=MagicMock())

No real database connections or network calls occur.
"""

import pytest
import requests
from unittest.mock import MagicMock, patch, call

from profiler.engine import EnterpriseProfilerEngine
from profiler.telemetry import TelemetryClient


# ---------------------------------------------------------------------------
# Engine fixture factory — shared across all test classes
# ---------------------------------------------------------------------------

_PG_CREDS = {"host": "h", "port": 5432, "dbname": "d", "user": "u", "password": "p"}


def _make_engine(spark, dialect, pass1_stats, pass2_stats, platform="POSTGRES"):
    """Build an engine with all network/DB calls mocked out."""
    with patch("psycopg2.connect"), \
         patch("profiler.engine.load_dialect",
               return_value=(dialect, pass1_stats, pass2_stats, {})):
        eng = EnterpriseProfilerEngine(
            spark=spark,
            pg_creds=_PG_CREDS,
            jdbc_url="jdbc:postgresql://h:5432/d",
            driver="org.postgresql.Driver",
            source_platform=platform,
            execution_tier="ADVANCED",
            api_base_url="http://localhost",
            api_port=8080,
        )
    eng.reader = MagicMock()
    # Suppress telemetry HTTP calls by injecting a mock session
    eng._tel_session = MagicMock(spec=requests.Session)
    return eng


def _run_job(eng, spark, pass1_shape_b, batch_cols, pass3_rows=None):
    """Run execute_job() with the given mocked shapes and capture _write_all args."""
    eng.reader.read_df.return_value = pass1_shape_b
    eng.reader.read_rows.return_value = pass3_rows or []

    captured = {}

    def fake_write_all(run_id, metrics_df, freqs, patterns, hists):
        captured["metrics"] = metrics_df.collect()
        captured["freqs"] = freqs
        captured["patterns"] = patterns
        captured["hists"] = hists

    eng._write_all = fake_write_all

    # Patch TelemetryClient so stage() context managers work without network
    with patch("profiler.engine.TelemetryClient") as MockTel:
        # Make TelemetryClient().stage() a no-op context manager
        mock_tel_instance = MagicMock()
        mock_tel_instance.stage.return_value.__enter__ = MagicMock(return_value=None)
        mock_tel_instance.stage.return_value.__exit__ = MagicMock(return_value=False)
        MockTel.return_value = mock_tel_instance

        eng.execute_job(
            run_id=1,
            source_id=42,
            target_table="public.test_table",
            config_columns=batch_cols,
        )

    return captured


# ---------------------------------------------------------------------------
# Basic smoke tests
# ---------------------------------------------------------------------------

class TestExecuteJobSmoke:
    def test_produces_one_metric_row_per_column(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, pass1_shape_b, batch_cols)
        assert "metrics" in captured
        assert len(captured["metrics"]) == len(batch_cols)

    def test_metric_rows_have_expected_columns(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, pass1_shape_b, batch_cols)
        row_keys = set(captured["metrics"][0].asDict().keys())
        for expected_col in ["column_name", "total_rows", "distinct_count", "mean_value"]:
            assert expected_col in row_keys

    def test_column_names_match_config(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, pass1_shape_b, batch_cols)
        result_cols = {r["column_name"] for r in captured["metrics"]}
        expected_cols = {c["attributeName"] for c in batch_cols}
        assert result_cols == expected_cols


# ---------------------------------------------------------------------------
# Empty table guard
# ---------------------------------------------------------------------------

class TestEmptyTableGuard:
    def test_empty_table_writes_nothing(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols
    ):
        """total_rows == 0 → _write_all never called."""
        empty_df = spark.createDataFrame([(0,)], "total_rows long")
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, empty_df, batch_cols)
        assert "metrics" not in captured

    def test_empty_table_does_not_call_read_rows(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols
    ):
        empty_df = spark.createDataFrame([(0,)], "total_rows long")
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        eng.reader.read_df.return_value = empty_df

        with patch("profiler.engine.TelemetryClient") as MockTel:
            mock_tel_instance = MagicMock()
            mock_tel_instance.stage.return_value.__enter__ = MagicMock(return_value=None)
            mock_tel_instance.stage.return_value.__exit__ = MagicMock(return_value=False)
            MockTel.return_value = mock_tel_instance

            eng.execute_job(run_id=1, source_id=1,
                            target_table="t", config_columns=batch_cols)

        eng.reader.read_rows.assert_not_called()


# ---------------------------------------------------------------------------
# Pass 2 platform guard
# ---------------------------------------------------------------------------

class TestPass2PlatformGuard:
    @pytest.mark.parametrize("platform", ["BQ", "ORACLE", "SINGLESTORE"])
    def test_pass2_not_executed_for_these_platforms(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols
    ):
        """For BQ/Oracle/SingleStore, Pass 2 must not trigger an extra read_df call."""
        wide_df = spark.createDataFrame(
            [(1_000_000, "user_id", "50", "1", "100", None, "50"),
             (1_000_000, "status", "8", None, None, "4", None)],
            "total_rows long, column_name string, distinct_count string, "
            "min string, max string, distinct_pattern_count string, mean_value string",
        )
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats, platform=platform)
        _run_job(eng, spark, wide_df, batch_cols)

        # read_df called exactly once (Pass 1 only); Pass 2 must not add a call
        assert eng.reader.read_df.call_count == 1, (
            f"Platform {platform}: expected 1 read_df call (Pass 1 only), "
            f"got {eng.reader.read_df.call_count}"
        )

    def test_pass2_executes_for_postgres(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        """Postgres is the one platform where Pass 2 fires (adds a second read_df call)."""
        # Make pass2 eligible: user_id has pass2_stats in selectedStats
        cols_with_p2 = [
            {"attributeName": "user_id", "dataTypeCategory": "numeric",
             "selectedStats": ["empty_count", "distinct_count", "p25", "p50"],
             "sensitiveTag": None},
        ]
        # low-cardinality pass1 (distinct_count=5000, total=1M → uniq_ratio 0.5% → include_pass2=True)
        low_card_df = spark.createDataFrame(
            [(1_000_000, "user_id", "5000", "1", "100", None, "50")],
            "total_rows long, column_name string, distinct_count string, "
            "min string, max string, distinct_pattern_count string, mean_value string",
        )
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats, platform="POSTGRES")
        # Pass 2 read_df must return a flat wide row
        p2_flat = spark.createDataFrame(
            [(1_000_000, 25.0, 50.0)],
            "total_rows long, user_id__p25 double, user_id__p50 double",
        )
        eng.reader.read_df.side_effect = [low_card_df, p2_flat]
        eng.reader.read_rows.return_value = []
        _run_job(eng, spark, low_card_df, cols_with_p2)
        # 2 calls: Pass 1 + Pass 2
        assert eng.reader.read_df.call_count == 2


# ---------------------------------------------------------------------------
# Pass 3 results forwarded to _write_all
# ---------------------------------------------------------------------------

class TestPass3ResultsForwarded:
    def test_pass3_freq_payloads_in_write_all(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        p3_rows = [
            {"metric_type": "freq", "column_name": "status",
             "bucket_label": "ACTIVE", "cnt": "900"},
        ]
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, pass1_shape_b, batch_cols, pass3_rows=p3_rows)
        assert len(captured.get("freqs", [])) >= 1
        assert captured["freqs"][0]["value"] == "ACTIVE"

    def test_pass3_hist_payloads_in_write_all(
        self, spark, dialect, pass1_stats, pass2_stats, batch_cols, pass1_shape_b
    ):
        p3_rows = [
            {"metric_type": "hist", "column_name": "user_id",
             "bucket_label": "3", "cnt": "5000"},
        ]
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        captured = _run_job(eng, spark, pass1_shape_b, batch_cols, pass3_rows=p3_rows)
        assert len(captured.get("hists", [])) == 1
        assert captured["hists"][0]["bucket"] == 3


# ---------------------------------------------------------------------------
# Cross-batch accumulation
# ---------------------------------------------------------------------------

class TestCrossBatchAccumulation:
    def test_metrics_from_all_batches_combined(
        self, spark, dialect, pass1_stats, pass2_stats
    ):
        """With 3 columns and batch_size=2 (would need batch_size=2 config — here
        we force 2 separate batches by providing 3 columns when batch size is 100.
        Use 101 columns to force 2 batches in non-BQ mode (size=100)."""
        # Build 101 simple columns to force 2 batches (100 + 1)
        cols = [
            {"attributeName": f"col_{i}", "dataTypeCategory": "numeric",
             "selectedStats": ["distinct_count", "min", "max", "mean_value"],
             "sensitiveTag": None}
            for i in range(101)
        ]

        def _make_wide(n):
            rows = [(1_000_000, f"col_{i}", str(i * 10), str(i), str(i * 100), None, str(i * 5))
                    for i in range(n)]
            return spark.createDataFrame(
                rows,
                "total_rows long, column_name string, distinct_count string, "
                "min string, max string, distinct_pattern_count string, mean_value string",
            )

        # First batch returns 100 rows, second batch returns 1 row
        eng = _make_engine(spark, dialect, pass1_stats, pass2_stats)
        eng.reader.read_df.side_effect = [_make_wide(100), _make_wide(1)]
        eng.reader.read_rows.return_value = []

        captured = {}

        def fake_write(run_id, metrics_df, freqs, patterns, hists):
            captured["count"] = metrics_df.count()

        eng._write_all = fake_write

        with patch("profiler.engine.TelemetryClient") as MockTel:
            mock_tel = MagicMock()
            mock_tel.stage.return_value.__enter__ = MagicMock(return_value=None)
            mock_tel.stage.return_value.__exit__ = MagicMock(return_value=False)
            MockTel.return_value = mock_tel
            eng.execute_job(run_id=1, source_id=1, target_table="t", config_columns=cols)

        # Both batches merged — total should equal 100 + 1 = 101 rows
        assert captured.get("count") == 101
