"""Tests for build_plan_df() — column gating and routing flags.

Uses a local SparkSession with synthetic Shape B DataFrames; no DB calls.
"""

import pytest
from profiler.planner import build_plan_df, get_plan_rows


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _wide_df(spark, rows):
    """Helper: create a Shape B wide DataFrame for testing build_plan_df()."""
    return spark.createDataFrame(
        rows,
        "total_rows long, column_name string, distinct_count string, "
        "min string, max string, distinct_pattern_count string, mean_value string",
    )


def _plan_row(spark, batch_cols, wide_df, pass2_stats, total_rows=1_000_000):
    plan = build_plan_df(spark, batch_cols, wide_df, total_rows, pass2_stats)
    return {r["column_name"]: r for r in plan.collect()}


# ---------------------------------------------------------------------------
# include_hist
# ---------------------------------------------------------------------------

class TestIncludeHist:
    def test_numeric_with_range_enabled(self, spark, pass2_stats):
        wide = _wide_df(spark, [(1_000_000, "amount", "500000", "1.0", "100.0", None, "50.0")])
        batch = [{"attributeName": "amount", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["amount"]["include_hist"] is True

    def test_numeric_min_equals_max_disabled(self, spark, pass2_stats):
        """Constant column (min == max) must not get a histogram."""
        wide = _wide_df(spark, [(1_000_000, "const", "1", "42", "42", None, "42.0")])
        batch = [{"attributeName": "const", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["const"]["include_hist"] is False

    def test_numeric_null_min_disabled(self, spark, pass2_stats):
        wide = _wide_df(spark, [(1_000_000, "col", "500", None, "100", None, None)])
        batch = [{"attributeName": "col", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["col"]["include_hist"] is False

    def test_string_column_never_gets_hist(self, spark, pass2_stats):
        wide = _wide_df(spark, [(1_000_000, "label", "50", "A", "Z", "10", None)])
        batch = [{"attributeName": "label", "dataTypeCategory": "STRING",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["label"]["include_hist"] is False

    def test_low_distinct_count_disabled(self, spark, pass2_stats):
        """distinct_count ≤ 10 → include_hist=False (likely constant or near-constant)."""
        wide = _wide_df(spark, [(1_000_000, "flag", "5", "0", "1", None, "0.5")])
        batch = [{"attributeName": "flag", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["flag"]["include_hist"] is False


# ---------------------------------------------------------------------------
# include_freq / include_pattern
# ---------------------------------------------------------------------------

class TestIncludeFreqPattern:
    def test_string_under_freq_limit(self, spark, pass2_stats):
        wide = _wide_df(spark, [(1_000_000, "status", "8", None, None, "4", None)])
        batch = [{"attributeName": "status", "dataTypeCategory": "STRING",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["status"]["include_freq"] is True
        assert rows["status"]["include_pattern"] is True

    def test_string_over_freq_limit_disabled(self, spark, pass2_stats):
        """distinct_count > FREQ_LIMIT (1000) → include_freq=False."""
        wide = _wide_df(spark, [(1_000_000, "email", "5000", None, None, "4000", None)])
        batch = [{"attributeName": "email", "dataTypeCategory": "STRING",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["email"]["include_freq"] is False

    def test_numeric_column_never_gets_freq(self, spark, pass2_stats):
        wide = _wide_df(spark, [(1_000_000, "amount", "50", "1", "100", None, "50")])
        batch = [{"attributeName": "amount", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["amount"]["include_freq"] is False
        assert rows["amount"]["include_pattern"] is False

    def test_id_column_excluded_from_freq(self, spark, pass2_stats):
        """Column names ending in _id are flagged is_id=True and excluded from freq."""
        wide = _wide_df(spark, [(1_000_000, "customer_id", "50", None, None, "5", None)])
        batch = [{"attributeName": "customer_id", "dataTypeCategory": "STRING",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["customer_id"]["include_freq"] is False
        assert rows["customer_id"]["is_id"] is True

    def test_pattern_over_limit_disabled(self, spark, pass2_stats):
        """distinct_pattern_count > PATTERN_LIMIT (100) → include_pattern=False."""
        wide = _wide_df(spark, [(1_000_000, "descr", "200", None, None, "150", None)])
        batch = [{"attributeName": "descr", "dataTypeCategory": "STRING",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["descr"]["include_pattern"] is False


# ---------------------------------------------------------------------------
# include_pass2
# ---------------------------------------------------------------------------

class TestIncludePass2:
    def test_low_cardinality_enabled(self, spark, pass2_stats):
        """uniq_ratio < 0.90 → include_pass2=True (still worth computing percentiles)."""
        wide = _wide_df(spark, [(1_000_000, "amount", "500000", "1", "100", None, "50")])
        batch = [{"attributeName": "amount", "dataTypeCategory": "NUMERIC",
                  "selectedStats": ["p25", "p50"], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["amount"]["include_pass2"] is True

    def test_high_cardinality_disabled(self, spark, pass2_stats):
        """uniq_ratio ≥ 0.90 → include_pass2=False."""
        wide = _wide_df(spark, [(1_000_000, "card_num", "950000", "1", "999999", None, "500000")])
        batch = [{"attributeName": "card_num", "dataTypeCategory": "NUMERIC",
                  "selectedStats": ["p25", "p50"], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats)
        assert rows["card_num"]["include_pass2"] is False

    def test_empty_table_no_error(self, spark, pass2_stats):
        """total_rows=0 must not cause division-by-zero; uniq_ratio defaults to 0."""
        wide = _wide_df(spark, [(0, "x", "0", None, None, None, None)])
        batch = [{"attributeName": "x", "dataTypeCategory": "NUMERIC",
                  "selectedStats": [], "sensitiveTag": None}]
        rows = _plan_row(spark, batch, wide, pass2_stats, total_rows=0)
        assert rows["x"]["uniq_ratio"] == 0.0


# ---------------------------------------------------------------------------
# Multi-column batch
# ---------------------------------------------------------------------------

class TestMultiColumnBatch:
    def test_mixed_batch_all_columns_present(self, spark, pass2_stats, batch_cols,
                                              pass1_shape_b):
        plan = build_plan_df(spark, batch_cols, pass1_shape_b, 1_000_000, pass2_stats)
        col_names = {r["column_name"] for r in plan.collect()}
        expected = {c["attributeName"] for c in batch_cols}
        assert col_names == expected

    def test_plan_df_is_cached(self, spark, pass2_stats, batch_cols, pass1_shape_b):
        plan = build_plan_df(spark, batch_cols, pass1_shape_b, 1_000_000, pass2_stats)
        assert plan.is_cached


# ---------------------------------------------------------------------------
# get_plan_rows
# ---------------------------------------------------------------------------

class TestGetPlanRows:
    def test_returns_all_rows_as_dicts(self, spark, pass2_stats, batch_cols, pass1_shape_b):
        plan = build_plan_df(spark, batch_cols, pass1_shape_b, 1_000_000, pass2_stats)
        rows = get_plan_rows(plan)
        assert len(rows) == len(batch_cols)
        assert all(isinstance(r, dict) for r in rows)

    def test_column_projection(self, spark, pass2_stats, batch_cols, pass1_shape_b):
        plan = build_plan_df(spark, batch_cols, pass1_shape_b, 1_000_000, pass2_stats)
        rows = get_plan_rows(plan, cols=["column_name", "include_hist"])
        assert set(rows[0].keys()) == {"column_name", "include_hist"}
