"""Pass 3 SQL generation and result-splitting tests — pure Python, no DB/Spark."""

import pytest
from profiler.pass3 import build_pass3_sql, split_pass3_results
from profiler.constants import GROUPING_SETS_LIMITS, TOP_K


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _freq_row(col, label, cnt):
    return {"metric_type": "freq", "column_name": col, "bucket_label": label, "cnt": str(cnt)}

def _pattern_row(col, label, cnt):
    return {"metric_type": "pattern", "column_name": col, "bucket_label": label, "cnt": str(cnt)}

def _hist_row(col, bucket, cnt):
    return {"metric_type": "hist", "column_name": col, "bucket_label": str(bucket), "cnt": str(cnt)}

def _string_plan_row(col, include_freq=True, include_pattern=True):
    return {"column_name": col, "data_type": "STRING",
            "include_freq": include_freq, "include_pattern": include_pattern,
            "include_hist": False, "min_val": None, "max_val": None, "hist_bins": 20}

def _numeric_plan_row(col, mn="0", mx="100", bins=10):
    return {"column_name": col, "data_type": "NUMERIC",
            "include_freq": False, "include_pattern": False, "include_hist": True,
            "min_val": mn, "max_val": mx, "hist_bins": bins}


# ---------------------------------------------------------------------------
# build_pass3_sql — platform routing
# ---------------------------------------------------------------------------

class TestPass3SqlPlatformRouting:
    @pytest.mark.parametrize("platform", ["BQ", "ORACLE", "POSTGRES", "SINGLESTORE"])
    def test_grouping_sets_for_supported_platforms(self, platform):
        sql = build_pass3_sql("t", "", [_string_plan_row("status")], platform)
        assert sql is not None
        assert "GROUPING SETS" in sql

    def test_union_all_for_mysql(self):
        sql = build_pass3_sql("t", "", [_string_plan_row("status")], "MYSQL")
        assert sql is not None
        assert "GROUPING SETS" not in sql
        assert "UNION ALL" in sql

    def test_returns_none_when_no_eligible_columns(self):
        plan_rows = [{"column_name": "x", "data_type": "STRING",
                      "include_freq": False, "include_pattern": False, "include_hist": False,
                      "min_val": None, "max_val": None, "hist_bins": 20}]
        assert build_pass3_sql("t", "", plan_rows, "BQ") is None

    def test_sample_clause_injected(self):
        sql = build_pass3_sql("tbl", " TABLESAMPLE SYSTEM (10 PERCENT)",
                              [_string_plan_row("col")], "BQ")
        assert "TABLESAMPLE SYSTEM (10 PERCENT)" in sql


# ---------------------------------------------------------------------------
# build_pass3_sql — SQL content
# ---------------------------------------------------------------------------

class TestPass3SqlContent:
    def test_histogram_uses_floor_not_width_bucket(self):
        sql = build_pass3_sql("t", "", [_numeric_plan_row("amount", "0", "100", 10)], "POSTGRES")
        assert "FLOOR(" in sql
        assert "WIDTH_BUCKET" not in sql

    def test_histogram_uses_least_for_clamping(self):
        """Bucket index must be clamped to bins-1 via LEAST."""
        sql = build_pass3_sql("t", "", [_numeric_plan_row("amount", "0", "100", 20)], "BQ")
        assert "LEAST(" in sql

    def test_pattern_uses_regexp_replace(self):
        sql = build_pass3_sql("t", "", [_string_plan_row("email", include_pattern=True)], "POSTGRES")
        assert "REGEXP_REPLACE" in sql

    def test_sampled_cte_selects_only_needed_columns(self):
        """CTE must SELECT only the columns eligible for Pass 3, not SELECT *."""
        plan_rows = [_string_plan_row("status"), _numeric_plan_row("amount")]
        sql = build_pass3_sql("t", "", plan_rows, "BQ")
        assert "SELECT *" not in sql
        # CTE selects specific columns
        assert "FROM t" in sql

    def test_grouping_sets_batching_for_oracle(self):
        """Oracle limit is 32.  With 33 expressions the SQL must batch them."""
        plan_rows = [_string_plan_row(f"col_{i}") for i in range(17)]
        # 17 string cols × 2 expressions each (freq + pattern) = 34 > Oracle limit 32
        sql = build_pass3_sql("t", "", plan_rows, "ORACLE")
        assert sql is not None
        # Multiple GROUPING SETS clauses when batched
        assert sql.count("GROUPING SETS") >= 1

    def test_hist_skipped_when_min_equals_max(self):
        """A constant column (min == max) must be excluded from histograms."""
        plan_rows = [_numeric_plan_row("const_col", "42", "42", 10)]
        assert build_pass3_sql("t", "", plan_rows, "BQ") is None

    def test_hist_skipped_when_min_or_max_is_none(self):
        plan_rows = [{"column_name": "c", "data_type": "NUMERIC",
                      "include_freq": False, "include_pattern": False, "include_hist": True,
                      "min_val": None, "max_val": "100", "hist_bins": 10}]
        assert build_pass3_sql("t", "", plan_rows, "BQ") is None

    def test_having_filters_null_rows_grouping_sets(self):
        """GROUPING SETS rows where all slots are rolled up should be filtered out.
        The generated SQL must contain a NULL-exclusion WHERE or HAVING clause."""
        sql = build_pass3_sql("t", "", [_string_plan_row("s")], "BQ")
        assert "IS NOT NULL" in sql


# ---------------------------------------------------------------------------
# split_pass3_results — payload routing and top-K
# ---------------------------------------------------------------------------

class TestSplitPass3Results:
    def test_routes_freq_pattern_hist_correctly(self):
        rows = [
            _freq_row("status", "ACTIVE", 900),
            _pattern_row("status", "AAAAAA", 800),
            _hist_row("amount", 2, 500),
        ]
        freqs, patterns, hists = split_pass3_results(rows, extrapolation=1.0)
        assert len(freqs) == 1 and freqs[0]["value"] == "ACTIVE"
        assert len(patterns) == 1 and patterns[0]["pattern"] == "AAAAAA"
        assert len(hists) == 1 and hists[0]["bucket"] == 2

    def test_top_k_limits_freq_results(self):
        rows = [_freq_row("col", f"val_{i}", 100 - i) for i in range(20)]
        freqs, _, _ = split_pass3_results(rows, extrapolation=1.0, top_k=5)
        assert len(freqs) == 5
        assert freqs[0]["value"] == "val_0"  # highest count first

    def test_top_k_defaults_to_constant(self):
        rows = [_freq_row("col", f"v{i}", i) for i in range(TOP_K + 5)]
        freqs, _, _ = split_pass3_results(rows, extrapolation=1.0)
        assert len(freqs) == TOP_K

    def test_histogram_extrapolation_multiplied(self):
        rows = [_hist_row("amount", 0, 100)]
        _, _, hists = split_pass3_results(rows, extrapolation=10.0)
        assert hists[0]["count"] == 1000

    def test_extrapolation_1_leaves_counts_unchanged(self):
        rows = [_hist_row("amount", 1, 250)]
        _, _, hists = split_pass3_results(rows, extrapolation=1.0)
        assert hists[0]["count"] == 250

    def test_bucket_label_parsed_to_int(self):
        rows = [_hist_row("x", 7, 10)]
        _, _, hists = split_pass3_results(rows, extrapolation=1.0)
        assert isinstance(hists[0]["bucket"], int)
        assert hists[0]["bucket"] == 7

    def test_multiple_columns_split_correctly(self):
        rows = [
            _freq_row("col_a", "X", 500),
            _freq_row("col_b", "Y", 300),
        ]
        freqs, _, _ = split_pass3_results(rows, extrapolation=1.0)
        col_names = {r["column_name"] for r in freqs}
        assert col_names == {"col_a", "col_b"}

    def test_empty_rows_returns_empty_payloads(self):
        freqs, patterns, hists = split_pass3_results([], extrapolation=1.0)
        assert freqs == []
        assert patterns == []
        assert hists == []
