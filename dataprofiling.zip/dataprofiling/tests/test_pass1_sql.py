"""Pure-Python SQL generation tests — no SparkSession, no DB required.

All assertions are string-level checks on the SQL produced by build_pass1_sql()
and its platform-specific helpers.  Each test documents the contract that must
hold regardless of internal refactoring.
"""

import pytest
from profiler.pass1 import build_pass1_sql, expand_selected_stats


# ---------------------------------------------------------------------------
# BQ
# ---------------------------------------------------------------------------

class TestBqPass1Sql:
    def test_single_unpivot_not_double(self, dialect, pass1_stats, batch_cols):
        """BQ must use exactly ONE UNPIVOT (not the old double-UNPIVOT approach)."""
        sql = build_pass1_sql("proj.ds.tbl", batch_cols, dialect, "BQ", pass1_stats, "ADVANCED")
        assert sql.count("UNPIVOT") == 1

    def test_json_value_per_stat(self, dialect, pass1_stats, batch_cols):
        """Each stat name must appear as a JSON_VALUE extraction."""
        sql = build_pass1_sql("t", batch_cols, dialect, "BQ", pass1_stats, "ADVANCED")
        for stat in ["distinct_count", "mean_value", "min", "max", "empty_count"]:
            assert f"JSON_VALUE(val, '$.{stat}')" in sql, f"Missing JSON_VALUE for {stat}"

    def test_no_json_keys_or_unnest(self, dialect, pass1_stats, batch_cols):
        """The old JSON_KEYS + CROSS JOIN UNNEST approach must be absent."""
        sql = build_pass1_sql("t", batch_cols, dialect, "BQ", pass1_stats, "ADVANCED")
        assert "JSON_KEYS" not in sql
        assert "CROSS JOIN UNNEST" not in sql

    def test_all_columns_in_unpivot_list(self, dialect, pass1_stats, batch_cols):
        """Both column aliases must appear backtick-quoted in the UNPIVOT IN list."""
        sql = build_pass1_sql("t", batch_cols, dialect, "BQ", pass1_stats, "ADVANCED")
        assert "`user_id`" in sql
        assert "`status`" in sql

    def test_to_json_string_struct_present(self, dialect, pass1_stats, batch_cols):
        """BQ aggregate uses TO_JSON_STRING(STRUCT(...))."""
        sql = build_pass1_sql("t", batch_cols, dialect, "BQ", pass1_stats, "ADVANCED")
        assert "TO_JSON_STRING" in sql.upper() or "to_json_string" in sql
        assert "STRUCT(" in sql.upper() or "STRUCT(" in sql


# ---------------------------------------------------------------------------
# Postgres
# ---------------------------------------------------------------------------

class TestPostgresPass1Sql:
    def test_materialized_cte(self, dialect, pass1_stats, batch_cols):
        """CTE must use MATERIALIZED to ensure single aggregation scan."""
        sql = build_pass1_sql("t", batch_cols, dialect, "POSTGRES", pass1_stats, "ADVANCED")
        assert "AS MATERIALIZED" in sql

    def test_arrow_operator(self, dialect, pass1_stats, batch_cols):
        """Uses ->> operator for scalar JSON field extraction."""
        sql = build_pass1_sql("t", batch_cols, dialect, "POSTGRES", pass1_stats, "ADVANCED")
        assert "->>" in sql

    def test_union_all_branches(self, dialect, pass1_stats, batch_cols):
        """One UNION ALL branch per column."""
        sql = build_pass1_sql("t", batch_cols, dialect, "POSTGRES", pass1_stats, "ADVANCED")
        assert "UNION ALL" in sql

    def test_no_json_each(self, dialect, pass1_stats, batch_cols):
        """The old json_each LATERAL approach must be absent."""
        sql = build_pass1_sql("t", batch_cols, dialect, "POSTGRES", pass1_stats, "ADVANCED")
        assert "json_each" not in sql

    def test_json_build_object_present(self, dialect, pass1_stats, batch_cols):
        sql = build_pass1_sql("t", batch_cols, dialect, "POSTGRES", pass1_stats, "ADVANCED")
        assert "json_build_object" in sql


# ---------------------------------------------------------------------------
# Oracle
# ---------------------------------------------------------------------------

class TestOraclePass1Sql:
    def test_materialize_hint(self, dialect, pass1_stats, batch_cols):
        """Oracle uses /*+ MATERIALIZE */ hint inside the CTE."""
        sql = build_pass1_sql("t", batch_cols, dialect, "ORACLE", pass1_stats, "ADVANCED")
        assert "/*+ MATERIALIZE */" in sql

    def test_json_value_extraction(self, dialect, pass1_stats, batch_cols):
        sql = build_pass1_sql("t", batch_cols, dialect, "ORACLE", pass1_stats, "ADVANCED")
        assert "JSON_VALUE" in sql

    def test_union_all_branches(self, dialect, pass1_stats, batch_cols):
        sql = build_pass1_sql("t", batch_cols, dialect, "ORACLE", pass1_stats, "ADVANCED")
        assert "UNION ALL" in sql

    def test_no_json_table_or_inner_unpivot(self, dialect, pass1_stats, batch_cols):
        """The old JSON_TABLE + inner UNPIVOT approach must be absent."""
        sql = build_pass1_sql("t", batch_cols, dialect, "ORACLE", pass1_stats, "ADVANCED")
        assert "JSON_TABLE" not in sql

    def test_json_object_present(self, dialect, pass1_stats, batch_cols):
        sql = build_pass1_sql("t", batch_cols, dialect, "ORACLE", pass1_stats, "ADVANCED")
        assert "JSON_OBJECT" in sql
        assert "NULL ON NULL" in sql


# ---------------------------------------------------------------------------
# MySQL / SingleStore — flat path
# ---------------------------------------------------------------------------

class TestFlatPass1Sql:
    @pytest.mark.parametrize("platform", ["MYSQL", "SINGLESTORE"])
    def test_flat_col_stat_aliases(self, platform, dialect, pass1_stats, batch_cols):
        """Flat platforms emit col__stat aliases, no JSON wrapping."""
        sql = build_pass1_sql("t", batch_cols, dialect, platform, pass1_stats, "ADVANCED")
        assert "user_id__mean_value" in sql
        assert "status__distinct_count" in sql
        assert "STRUCT" not in sql
        assert "json_build_object" not in sql


# ---------------------------------------------------------------------------
# Edge cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_returns_none_when_no_matching_stats(self, dialect):
        """Returns None when none of the selected stats exist in the dialect."""
        cols = [{"attributeName": "x", "dataTypeCategory": "numeric",
                 "selectedStats": ["nonexistent_stat"], "sensitiveTag": None}]
        assert build_pass1_sql("t", cols, dialect, "BQ", list(dialect.keys()), "ADVANCED") is None

    def test_compliance_forces_count_distinct(self, dialect, pass1_stats):
        """COMPLIANCE tier + force_exact_distinct uses COUNT(DISTINCT) not APPROX."""
        cols = [{"attributeName": "col_a", "dataTypeCategory": "numeric",
                 "selectedStats": ["distinct_count"],
                 "force_exact_distinct": True, "sensitiveTag": None}]
        sql = build_pass1_sql("t", cols, dialect, "MYSQL", pass1_stats, "COMPLIANCE")
        assert "COUNT(DISTINCT col_a)" in sql
        assert "APPROX_COUNT_DISTINCT" not in sql

    def test_sensitive_column_pii_decrypt(self, dialect, pass1_stats):
        """Sensitive columns must use decrypt_sde() and appear in EXCEPT list."""
        cols = [{"attributeName": "ssn", "dataTypeCategory": "string",
                 "selectedStats": ["distinct_count"],
                 "sensitiveTag": "NGBD-SDE-PII"}]
        sql = build_pass1_sql("t", cols, dialect, "MYSQL", pass1_stats, "ADVANCED")
        assert "decrypt_sde('NGBD-SDE-PII', ssn)" in sql
        assert "EXCEPT" in sql.upper()

    def test_bq_stat_names_union_across_columns(self, dialect, pass1_stats):
        """Stat names in the outer SELECT are the union across all columns.
        user_id has mean_value but status does not — mean_value still appears once."""
        sql = build_pass1_sql("t",
            [
                {"attributeName": "user_id", "dataTypeCategory": "numeric",
                 "selectedStats": ["mean_value", "distinct_count"], "sensitiveTag": None},
                {"attributeName": "status", "dataTypeCategory": "string",
                 "selectedStats": ["distinct_count"], "sensitiveTag": None},
            ],
            dialect, "BQ", pass1_stats, "ADVANCED")
        # mean_value must appear exactly once in the outer SELECT (union, not per-column)
        assert sql.count("JSON_VALUE(val, '$.mean_value')") == 1


# ---------------------------------------------------------------------------
# Dependency expansion
# ---------------------------------------------------------------------------

class TestExpandSelectedStats:
    """expand_selected_stats() must resolve prerequisite stats for derived stats."""

    @pytest.fixture
    def deps(self):
        return {
            "skewness":        ["sum_x", "sum_x2", "sum_x3", "sum_x4", "mean_value"],
            "excess_kurtosis": ["sum_x", "sum_x2", "sum_x3", "sum_x4", "mean_value"],
        }

    @pytest.fixture
    def all_stats(self, dialect, deps):
        """pass1_stats extended with power-sum stats to simulate a real registry."""
        return list(dialect.keys()) + ["sum_x", "sum_x2", "sum_x3", "sum_x4",
                                        "skewness", "excess_kurtosis"]

    def test_derived_stat_pulls_in_prerequisites(self, deps, all_stats):
        result = expand_selected_stats(["skewness"], all_stats, deps)
        for prereq in ["sum_x", "sum_x2", "sum_x3", "sum_x4", "mean_value"]:
            assert prereq in result, f"Expected prereq '{prereq}' to be auto-added"

    def test_non_derived_stat_unchanged(self, deps, all_stats):
        result = expand_selected_stats(["min", "max", "distinct_count"], all_stats, deps)
        assert set(result) == {"min", "max", "distinct_count"}

    def test_mixed_selection_expands_only_derived(self, deps, all_stats):
        result = expand_selected_stats(["empty_count", "skewness", "min"], all_stats, deps)
        assert "empty_count" in result
        assert "min" in result
        assert "sum_x" in result        # auto-added for skewness
        assert "mean_value" in result   # auto-added for skewness

    def test_kurtosis_shares_same_prereqs_as_skewness_no_duplicates(self, deps, all_stats):
        result = expand_selected_stats(["skewness", "excess_kurtosis"], all_stats, deps)
        # Power sums are shared prerequisites — each should appear exactly once
        assert result.count("sum_x4") == 1

    def test_skewness_auto_adds_power_sums_to_bq_sql(self, dialect, deps, all_stats):
        """End-to-end: selecting skewness on BQ must produce sum_x…sum_x4 in Pass 1 SQL."""
        extended_dialect = {
            **dialect,
            "sum_x":  "CAST(SUM({col}) AS BIGNUMERIC)",
            "sum_x2": "CAST(SUM({col}*{col}) AS BIGNUMERIC)",
            "sum_x3": "CAST(SUM(POWER(CAST({col} AS BIGNUMERIC),3)) AS BIGNUMERIC)",
            "sum_x4": "CAST(SUM(POWER(CAST({col} AS BIGNUMERIC),4)) AS BIGNUMERIC)",
            "skewness": None,           # derived stat — no direct SQL
        }
        cols = [{"attributeName": "amount", "dataTypeCategory": "numeric",
                 "selectedStats": ["skewness", "min", "max"], "sensitiveTag": None}]

        sql = build_pass1_sql("t", cols, extended_dialect, "BQ", all_stats, "ADVANCED",
                              dependencies=deps)

        assert sql is not None
        # Power sums must appear (auto-added by dependency resolver)
        assert "JSON_VALUE(val, '$.sum_x')"  in sql
        assert "JSON_VALUE(val, '$.sum_x4')" in sql
        assert "JSON_VALUE(val, '$.mean_value')" in sql
        # 'skewness' itself has no SQL — it must NOT appear as a JSON_VALUE extraction
        assert "JSON_VALUE(val, '$.skewness')" not in sql

    def test_no_deps_provided_gracefully_ignores(self, dialect, pass1_stats):
        """Calling build_pass1_sql without dependencies= must still work (no crash)."""
        cols = [{"attributeName": "col_a", "dataTypeCategory": "numeric",
                 "selectedStats": ["min", "max"], "sensitiveTag": None}]
        sql = build_pass1_sql("t", cols, dialect, "MYSQL", pass1_stats, "ADVANCED")
        assert sql is not None
