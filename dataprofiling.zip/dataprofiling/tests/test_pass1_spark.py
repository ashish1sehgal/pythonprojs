"""Spark-level tests for pass1 transformation helpers.

These tests exercise _wide_from_flat() and to_wide_df() using a local
SparkSession with in-memory DataFrames — no JDBC, no DB connections.
"""

import pytest
from profiler.pass1 import _wide_from_flat, to_wide_df
from profiler.constants import JSON_PACK_PLATFORMS


# ---------------------------------------------------------------------------
# _wide_from_flat — converts a single wide aggregate row to Shape B
# ---------------------------------------------------------------------------

class TestWideFromFlat:
    def test_produces_one_row_per_column(self, spark):
        flat_df = spark.createDataFrame(
            [(1_000_000, 42.5, 900_000.0, 1.0, 100.0, 8.0, None)],
            "total_rows long, "
            "user_id__mean_value double, user_id__distinct_count double, "
            "user_id__min double,        user_id__max double, "
            "status__distinct_count double, status__mean_value double",
        )
        wide = _wide_from_flat(spark, flat_df)
        col_names = {r["column_name"] for r in wide.collect()}
        assert col_names == {"user_id", "status"}

    def test_stat_values_converted_to_string(self, spark):
        flat_df = spark.createDataFrame(
            [(500, 42.5, 1.0)],
            "total_rows long, user_id__mean_value double, user_id__min double",
        )
        wide = _wide_from_flat(spark, flat_df)
        row = wide.filter("column_name = 'user_id'").first().asDict()
        assert row["mean_value"] == "42.5"
        assert row["min"] == "1.0"

    def test_null_stat_preserved_as_none(self, spark):
        """A column that has no mean_value stat should get None, not a string 'None'."""
        flat_df = spark.createDataFrame(
            [(1000, None, 8.0)],
            "total_rows long, status__mean_value double, status__distinct_count double",
        )
        wide = _wide_from_flat(spark, flat_df)
        row = wide.filter("column_name = 'status'").first().asDict()
        assert row["mean_value"] is None
        assert row["distinct_count"] == "8.0"

    def test_all_stat_columns_present_even_if_not_all_columns_have_them(self, spark):
        """Stat union: if user_id has mean_value but status does not, both rows
        still carry a mean_value column (None for status)."""
        flat_df = spark.createDataFrame(
            [(1000, 42.5, 8.0)],
            "total_rows long, user_id__mean_value double, status__distinct_count double",
        )
        wide = _wide_from_flat(spark, flat_df)
        rows = {r["column_name"]: r for r in wide.collect()}
        assert "mean_value" in rows["user_id"]
        assert "mean_value" in rows["status"]
        assert rows["status"]["mean_value"] is None

    def test_total_rows_preserved(self, spark):
        flat_df = spark.createDataFrame(
            [(999_999, 5.0)],
            "total_rows long, col_a__distinct_count double",
        )
        wide = _wide_from_flat(spark, flat_df)
        row = wide.first().asDict()
        assert row["total_rows"] == 999_999

    def test_empty_dataframe_returns_empty(self, spark):
        flat_df = spark.createDataFrame([], "total_rows long")
        wide = _wide_from_flat(spark, flat_df)
        assert wide.count() == 0

    def test_no_col_stat_columns_returns_empty(self, spark):
        """DataFrame with only total_rows and no col__stat columns → empty Shape B."""
        flat_df = spark.createDataFrame([(1000,)], "total_rows long")
        wide = _wide_from_flat(spark, flat_df)
        assert wide.count() == 0

    def test_multiple_stat_types_per_column(self, spark):
        flat_df = spark.createDataFrame(
            [(1_000_000, 42.5, 1.0, 100.0, 900_000.0)],
            "total_rows long, "
            "amount__mean_value double, amount__min double, "
            "amount__max double,        amount__distinct_count double",
        )
        wide = _wide_from_flat(spark, flat_df)
        row = wide.filter("column_name = 'amount'").first().asDict()
        assert row["mean_value"] == "42.5"
        assert row["min"] == "1.0"
        assert row["max"] == "100.0"
        assert row["distinct_count"] == "900000.0"


# ---------------------------------------------------------------------------
# to_wide_df — platform dispatch
# ---------------------------------------------------------------------------

class TestToWideDf:
    @pytest.mark.parametrize("platform", sorted(JSON_PACK_PLATFORMS))
    def test_passthrough_for_json_pack_platforms(self, spark, platform):
        """For BQ/Oracle/Postgres the SQL already returns Shape B.
        to_wide_df must return the same DataFrame object unchanged."""
        wide_df = spark.createDataFrame(
            [(1_000_000, "user_id", "42.5", "1.0")],
            "total_rows long, column_name string, mean_value string, min string",
        )
        result = to_wide_df(spark, wide_df, platform)
        assert result is wide_df, (
            f"to_wide_df for {platform} should be a no-op passthrough, "
            f"but returned a different object"
        )

    @pytest.mark.parametrize("platform", ["MYSQL", "SINGLESTORE"])
    def test_flat_platforms_pivot_to_shape_b(self, spark, platform):
        """For MySQL/SingleStore, flat col__stat aliases must be pivoted to Shape B."""
        flat_df = spark.createDataFrame(
            [(1_000_000, 42.5, 900_000.0, 8.0)],
            "total_rows long, "
            "user_id__mean_value double, user_id__distinct_count double, "
            "status__distinct_count double",
        )
        result = to_wide_df(spark, flat_df, platform)
        col_names = {r["column_name"] for r in result.collect()}
        assert col_names == {"user_id", "status"}, (
            f"Expected one row per column for {platform}; got {col_names}"
        )
        # Shape B must have column_name column
        assert "column_name" in result.columns
