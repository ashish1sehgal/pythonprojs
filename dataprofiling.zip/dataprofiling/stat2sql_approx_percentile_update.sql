-- ==============================================================================
-- stat2sql: Approximate Percentile Update
-- ==============================================================================
-- Replaces exact PERCENTILE_CONT with APPROX_PERCENTILE wherever native
-- sketch-based functions exist. Key effects:
--
--   1. O(n log n) sort → O(n) sketch: eliminates the most expensive operation
--      in Pass 1 for large Oracle and BigQuery tables.
--
--   2. Percentiles move from Pass 2 (sampled) to Pass 1 (full population)
--      on Oracle, BigQuery, and SingleStore, because the sketch is cheap
--      enough to run on the full table in the main aggregation scan.
--
--   3. Postgres and MySQL retain Pass 2 PERCENTILE_CONT on the sample.
--      PERCENTILE_CONT on 1M sampled rows is already an approximation via
--      sampling; no additional approx function needed.
--
-- Error bounds (all implementations guarantee ε < 0.5% relative error):
--   Oracle APPROX_PERCENTILE  : deterministic sketch, ε ≤ 0.005
--   BigQuery APPROX_QUANTILES : HLL-based, typical ε < 0.001 on large tables
--   SingleStore APPROX_PERCENTILE: t-digest, ε ≤ 0.01
--
-- Platform notes:
--   Oracle: APPROX_PERCENTILE introduced in 12.2.
--           For 12.1 and below, fall back to PERCENTILE_CONT on sample (Pass 2).
--           Detect via: SELECT version FROM v$instance — if >= 12.2, use approx.
--           The stat2sql oracle column uses 12.2+ syntax; the orchestrator checks
--           the DB version before routing to Pass 1 vs Pass 2.
--
--   BigQuery: APPROX_QUANTILES(col, 100) returns ARRAY<T> of 101 elements.
--             [OFFSET(25)] = P25, [OFFSET(50)] = P50, etc.
--             One call covers ALL percentiles — far cheaper than 6 separate calls.
--             Already implemented in pass2_sql_generator.py; now moved to Pass 1.
--
--   SingleStore: APPROX_PERCENTILE(col, fraction) matches Oracle syntax exactly.
--
--   Postgres: No native approx percentile. percentile_disc(0.95) WITHIN GROUP
--             is exact and requires a sort. Kept in Pass 2 on the sample where
--             the sort cost is bounded by sample size (O(1M log 1M)).
--
--   MySQL: No PERCENTILE_CONT or APPROX_PERCENTILE. Kept in Pass 2; the
--          Python result_unpivot layer extracts values from the sample DF.
-- ==============================================================================

-- pass_group 'A' = runs in Pass 1 (full table) when platform supports it.
-- pass_group 'B' = runs in Pass 2 (sampled) as fallback.
-- The orchestrator reads pass_group per-platform (not the global default)
-- using a new helper column: approx_pass_group.

ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS approx_pass_group_oracle      CHAR(1) DEFAULT 'B';
ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS approx_pass_group_bigquery    CHAR(1) DEFAULT 'B';
ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS approx_pass_group_singlestore CHAR(1) DEFAULT 'B';
ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS approx_pass_group_postgres    CHAR(1) DEFAULT 'B';
ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS approx_pass_group_mysql       CHAR(1) DEFAULT 'B';

COMMENT ON COLUMN stat2sql.approx_pass_group_oracle IS
    'A = stat can run in Pass 1 (full table) on Oracle using approx function. '
    'B = stat must run in Pass 2 (sample) because no approx function exists.';

-- ==============================================================================
-- Update P25 through P99
-- ==============================================================================

UPDATE stat2sql SET
    -- Oracle 12.2+: APPROX_PERCENTILE — O(n) sketch, full table in Pass 1
    oracle              = 'APPROX_PERCENTILE(<<col>>, 0.25)',
    approx_pass_group_oracle = 'A',

    -- BigQuery: APPROX_QUANTILES handles ALL percentiles in one call.
    -- The generator emits one APPROX_QUANTILES(col,100) per column in Pass 1
    -- and unpacks indices post-query. NULL here signals the generator to use
    -- the batched array call instead of a per-percentile expression.
    bigquery            = NULL,   -- handled by BQ-specific array logic in generator
    approx_pass_group_bigquery = 'A',

    -- SingleStore: APPROX_PERCENTILE — identical syntax to Oracle
    singlestore         = 'APPROX_PERCENTILE(<<col>>, 0.25)',
    approx_pass_group_singlestore = 'A',

    -- Postgres: no native approx — keep exact PERCENTILE_CONT on sample (Pass 2)
    postgres            = 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
    approx_pass_group_postgres = 'B',

    -- MySQL: no percentile function — Pass 2 sample, Python extracts from pandas DF
    mysql               = NULL,
    approx_pass_group_mysql = 'B',

    -- ANSI fallback (used if platform not recognised)
    sql                 = 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier           = 1,    -- downgraded from 2 (sort) to 1 (O(n) sketch)
    cost_weight         = 5,    -- was 10; approx is cheaper but not free
    pass_group          = 'A'   -- global default now A; platform overrides via approx_pass_group_*
WHERE stat = 'p25';

UPDATE stat2sql SET
    oracle='APPROX_PERCENTILE(<<col>>, 0.50)', approx_pass_group_oracle='A',
    bigquery=NULL, approx_pass_group_bigquery='A',
    singlestore='APPROX_PERCENTILE(<<col>>, 0.50)', approx_pass_group_singlestore='A',
    postgres='PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY <<col>>)', approx_pass_group_postgres='B',
    mysql=NULL, approx_pass_group_mysql='B',
    sql='PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier=1, cost_weight=5, pass_group='A'
WHERE stat = 'median_val';

UPDATE stat2sql SET
    oracle='APPROX_PERCENTILE(<<col>>, 0.75)', approx_pass_group_oracle='A',
    bigquery=NULL, approx_pass_group_bigquery='A',
    singlestore='APPROX_PERCENTILE(<<col>>, 0.75)', approx_pass_group_singlestore='A',
    postgres='PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)', approx_pass_group_postgres='B',
    mysql=NULL, approx_pass_group_mysql='B',
    sql='PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier=1, cost_weight=5, pass_group='A'
WHERE stat = 'p75';

UPDATE stat2sql SET
    oracle='APPROX_PERCENTILE(<<col>>, 0.90)', approx_pass_group_oracle='A',
    bigquery=NULL, approx_pass_group_bigquery='A',
    singlestore='APPROX_PERCENTILE(<<col>>, 0.90)', approx_pass_group_singlestore='A',
    postgres='PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)', approx_pass_group_postgres='B',
    mysql=NULL, approx_pass_group_mysql='B',
    sql='PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier=1, cost_weight=5, pass_group='A'
WHERE stat = 'p90';

UPDATE stat2sql SET
    oracle='APPROX_PERCENTILE(<<col>>, 0.95)', approx_pass_group_oracle='A',
    bigquery=NULL, approx_pass_group_bigquery='A',
    singlestore='APPROX_PERCENTILE(<<col>>, 0.95)', approx_pass_group_singlestore='A',
    postgres='PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)', approx_pass_group_postgres='B',
    mysql=NULL, approx_pass_group_mysql='B',
    sql='PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier=1, cost_weight=5, pass_group='A'
WHERE stat = 'p95';

UPDATE stat2sql SET
    oracle='APPROX_PERCENTILE(<<col>>, 0.99)', approx_pass_group_oracle='A',
    bigquery=NULL, approx_pass_group_bigquery='A',
    singlestore='APPROX_PERCENTILE(<<col>>, 0.99)', approx_pass_group_singlestore='A',
    postgres='PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)', approx_pass_group_postgres='B',
    mysql=NULL, approx_pass_group_mysql='B',
    sql='PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
    cost_tier=1, cost_weight=5, pass_group='A'
WHERE stat = 'p99';

-- ==============================================================================
-- Update box_plot (meta-stat that expands to p25 + median + p75)
-- box_plot itself has no SQL expression; the generator expands it.
-- Update cost to reflect the approx improvement.
-- ==============================================================================

UPDATE stat2sql SET cost_tier=1, cost_weight=12, pass_group='A' WHERE stat='box_plot';

-- ==============================================================================
-- Update stat_pack_contents: move percentile stats to cost class that reflects
-- they are now Pass-1 eligible (no longer require Pass-B batch for Oracle/BQ).
-- The pack membership is unchanged; only the cost metadata shifts.
-- ==============================================================================

-- Reduce STANDARD pack's effective cost for Oracle/BQ deployments since
-- percentiles no longer add a separate sorted pass.
-- No DDL change needed — cost_weight update in stat2sql above propagates.

-- ==============================================================================
-- View: per-platform pass routing
-- ==============================================================================
-- The orchestrator queries this view to decide whether a stat runs in Pass 1
-- or Pass 2 for the current platform. Avoids hardcoding platform checks in Python.

CREATE OR REPLACE VIEW stat_pass_routing AS
SELECT
    stat,
    CASE platform
        WHEN 'oracle'      THEN COALESCE(approx_pass_group_oracle,      pass_group)
        WHEN 'bigquery'    THEN COALESCE(approx_pass_group_bigquery,    pass_group)
        WHEN 'singlestore' THEN COALESCE(approx_pass_group_singlestore, pass_group)
        WHEN 'postgres'    THEN COALESCE(approx_pass_group_postgres,    pass_group)
        WHEN 'mysql'       THEN COALESCE(approx_pass_group_mysql,       pass_group)
        ELSE pass_group
    END AS effective_pass_group
FROM stat2sql
CROSS JOIN (VALUES ('oracle'),('bigquery'),('singlestore'),('postgres'),('mysql')) AS platforms(platform);

COMMENT ON VIEW stat_pass_routing IS
    'Per-platform pass assignment for each stat. '
    'Pass A = runs in Pass 1 (full population scan). '
    'Pass B = runs in Pass 2 (sampled query). '
    'Query: SELECT effective_pass_group FROM stat_pass_routing '
    'WHERE stat = ''p95'' AND platform = ''oracle'' → A (runs in Pass 1 via APPROX_PERCENTILE). '
    'WHERE stat = ''p95'' AND platform = ''postgres'' → B (runs in Pass 2 via PERCENTILE_CONT on sample).';
