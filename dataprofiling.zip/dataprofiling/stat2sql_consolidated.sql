-- ==============================================================================
-- stat2sql consolidated — merges stat_ui_map and stat_pack_contents into stat2sql
-- ==============================================================================
-- Run this migration against an existing schema, or use the full DDL below
-- for a fresh install.
--
-- Why this simplification is correct
-- ------------------------------------
-- stat_ui_map and stat_pack_contents have no independent lifecycle.
-- Every row in both tables is a property of a stat2sql row.
-- The join is pure overhead.
--
-- stat_pack_contents is many-to-many (one stat belongs to multiple packs).
-- Encoding as three boolean columns (in_basic, in_standard, in_advanced) is
-- correct here because the pack set is fixed by design — packs are not a
-- dynamic lookup that grows. If custom packs were ever needed, revisit.
--
-- stat_packs table is RETAINED. It holds pack-level metadata
-- (display_name, description, cost_class, sort_order) that belongs
-- to the pack, not to individual stats.
--
-- What is removed
-- ----------------
-- DROP TABLE stat_ui_map        → ui_label, applies_to added to stat2sql
-- DROP TABLE stat_pack_contents → in_basic, in_standard, in_advanced added to stat2sql
-- ==============================================================================


-- ==============================================================================
-- 1. Migrate existing schema
-- ==============================================================================

ALTER TABLE stat2sql
    ADD COLUMN IF NOT EXISTS ui_label   TEXT,
    ADD COLUMN IF NOT EXISTS applies_to TEXT,       -- 'numeric' | 'string' | 'all'
    ADD COLUMN IF NOT EXISTS in_basic    BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS in_standard BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS in_advanced BOOLEAN NOT NULL DEFAULT FALSE;

-- Populate from stat_ui_map (if it exists)
UPDATE stat2sql s
SET    ui_label   = m.ui_label,
       applies_to = m.applies_to
FROM   stat_ui_map m
WHERE  m.stat_key = s.stat;

-- Populate pack membership from stat_pack_contents (if it exists)
UPDATE stat2sql s
SET    in_basic = TRUE
WHERE  EXISTS (SELECT 1 FROM stat_pack_contents c WHERE c.stat_key = s.stat AND c.pack_name = 'BASIC');

UPDATE stat2sql s
SET    in_standard = TRUE
WHERE  EXISTS (SELECT 1 FROM stat_pack_contents c WHERE c.stat_key = s.stat AND c.pack_name = 'STANDARD');

UPDATE stat2sql s
SET    in_advanced = TRUE
WHERE  EXISTS (SELECT 1 FROM stat_pack_contents c WHERE c.stat_key = s.stat AND c.pack_name = 'ADVANCED');

-- Drop the satellite tables
DROP TABLE IF EXISTS stat_pack_contents;
DROP TABLE IF EXISTS stat_ui_map;


-- ==============================================================================
-- 2. Complete stat2sql DDL (fresh install — replaces the version in 01_postgres_schema.sql)
-- ==============================================================================

CREATE TABLE IF NOT EXISTS stat2sql (
    -- Identity
    stat         TEXT PRIMARY KEY,
    ui_label     TEXT,               -- human-readable label shown in UI (e.g. "Skewness")
    applies_to   TEXT,               -- 'numeric' | 'string' | 'all' — controls matrix column type filter

    -- Platform-specific SQL expressions
    -- NULL = platform does not support this stat natively
    oracle       TEXT,
    bigquery     TEXT,
    mysql        TEXT,
    postgres     TEXT,
    singlestore  TEXT,
    sql          TEXT,               -- ANSI fallback; used when platform column is NULL

    -- Cost and routing metadata
    cost_tier    INT     NOT NULL DEFAULT 0,
    cost_weight  NUMERIC NOT NULL DEFAULT 1,
    pass_group   CHAR(1) NOT NULL DEFAULT 'A',   -- global default: A=Pass1, B=Pass2, C=Pass3

    -- Per-platform pass routing for approximate percentiles
    approx_pass_group_oracle      CHAR(1) DEFAULT 'B',
    approx_pass_group_bigquery    CHAR(1) DEFAULT 'B',
    approx_pass_group_singlestore CHAR(1) DEFAULT 'B',
    approx_pass_group_postgres    CHAR(1) DEFAULT 'B',
    approx_pass_group_mysql       CHAR(1) DEFAULT 'B',

    -- Pack membership (replaces stat_pack_contents junction table)
    -- A stat in STANDARD is also in ADVANCED; a stat in BASIC is in all three.
    -- These flags encode that directly — no join needed.
    in_basic     BOOLEAN NOT NULL DEFAULT FALSE,
    in_standard  BOOLEAN NOT NULL DEFAULT FALSE,
    in_advanced  BOOLEAN NOT NULL DEFAULT FALSE
);

COMMENT ON COLUMN stat2sql.in_basic IS
    'TRUE if this stat is included in the BASIC pack.';
COMMENT ON COLUMN stat2sql.in_standard IS
    'TRUE if this stat is included in the STANDARD pack (which is a superset of BASIC).';
COMMENT ON COLUMN stat2sql.in_advanced IS
    'TRUE if this stat is included in the ADVANCED pack (which is a superset of STANDARD).';


-- ==============================================================================
-- 3. Complete seed data — all stat rows with ui_label, applies_to, pack membership
-- ==============================================================================

INSERT INTO stat2sql (stat, ui_label, applies_to, in_basic, in_standard, in_advanced,
    oracle, bigquery, mysql, postgres, singlestore, sql,
    cost_tier, cost_weight, pass_group) VALUES

-- ── Pass A: Full population aggregates ───────────────────────────────────────

('empty_count',     'Empty Count',   'all',     TRUE,TRUE,TRUE,
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'COUNTIF(<<col>> IS NULL)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 0, 1, 'A'),

('distinct_count',  'Distinct Count (Approx)', 'all', TRUE,TRUE,TRUE,
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'COUNT(DISTINCT <<col>>)',
 0, 2, 'A'),

('exact_distinct_count', 'Exact Distinct Count', 'all', FALSE,FALSE,TRUE,
 'COUNT(DISTINCT <<col>>)', 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)', 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)', 'COUNT(DISTINCT <<col>>)',
 1, 8, 'A'),

('valid_count',  NULL, NULL, FALSE,FALSE,FALSE,
 NULL,NULL,NULL,NULL,NULL, 'COUNT(<<col>>)', 0, 1, 'A'),

('total_rows',   NULL, NULL, FALSE,FALSE,FALSE,
 NULL,NULL,NULL,NULL,NULL, 'COUNT(*)', 0, 0, 'A'),

('min_val',      'Min',  'numeric', TRUE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'MIN(<<col>>)', 0, 1, 'A'),

('max_val',      'Max',  'numeric', TRUE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'MAX(<<col>>)', 0, 1, 'A'),

('mean_val',     'Mean', 'numeric', TRUE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'AVG(<<col>>)', 0, 1, 'A'),

('stddev_val',   'Std Dev', 'numeric', FALSE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'STDDEV(<<col>>)', 0, 2, 'A'),

('zero_count',   'Zero Count',     'numeric', FALSE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'SUM(CASE WHEN <<col>> = 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),

('positive_count','Positive Count', 'numeric', FALSE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'SUM(CASE WHEN <<col>> > 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),

('negative_count','Negative Count', 'numeric', FALSE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'SUM(CASE WHEN <<col>> < 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),

('min_length',   'Min Length', 'string', TRUE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'MIN(LENGTH(<<col>>))', 0, 1, 'A'),

('max_length',   'Max Length', 'string', TRUE,TRUE,TRUE,
 NULL,NULL,NULL,NULL,NULL, 'MAX(LENGTH(<<col>>))', 0, 1, 'A'),

-- Percentiles: approx in Pass A for Oracle/BQ/SingleStore; exact on sample for Postgres/MySQL
-- approx_pass_group columns control per-platform routing (see stat_pass_routing view)
('p25', 'P25', 'numeric', FALSE,TRUE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.25)', NULL,
 NULL,
 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.25)',
 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

('median_val', 'Median', 'numeric', FALSE,TRUE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.50)', NULL,
 NULL,
 'PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.50)',
 'PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

('p75', 'P75', 'numeric', FALSE,TRUE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.75)', NULL,
 NULL,
 'PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.75)',
 'PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

('p90', 'P90', 'numeric', FALSE,FALSE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.90)', NULL,
 NULL,
 'PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.90)',
 'PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

('p95', 'P95', 'numeric', FALSE,TRUE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.95)', NULL,
 NULL,
 'PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.95)',
 'PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

('p99', 'P99', 'numeric', FALSE,FALSE,TRUE,
 'APPROX_PERCENTILE(<<col>>, 0.99)', NULL,
 NULL,
 'PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
 'APPROX_PERCENTILE(<<col>>, 0.99)',
 'PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
 1, 5, 'A'),

-- ── Pass B: Sampled distributional stats ──────────────────────────────────────
-- <<mean>> injected from Pass 1 results at query-build time (centred moment formula)

('skewness', 'Skewness', 'numeric', FALSE,TRUE,TRUE,
 'SKEWNESS_POP(<<col>>)',
 'SAFE_DIVIDE(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,3)),POW(NULLIF(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,2)),0),1.5))',
 'AVG(POW(<<col>>-<<mean>>,3))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),1.5),0)',
 'AVG(POWER(<<col>>::NUMERIC-<<mean>>,3))/NULLIF(POWER(AVG(POWER(<<col>>::NUMERIC-<<mean>>,2)),1.5),0)',
 'AVG(POW(<<col>>-<<mean>>,3))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),1.5),0)',
 'AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,3))/NULLIF(POWER(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,2)),1.5),0)',
 1, 3, 'B'),

('kurtosis', 'Kurtosis', 'numeric', FALSE,TRUE,TRUE,
 'KURTOSIS_POP(<<col>>)',
 'SAFE_DIVIDE(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,4)),POW(NULLIF(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,2)),0),2))-3',
 '(AVG(POW(<<col>>-<<mean>>,4))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),2),0))-3',
 '(AVG(POWER(<<col>>::NUMERIC-<<mean>>,4))/NULLIF(POWER(AVG(POWER(<<col>>::NUMERIC-<<mean>>,2)),2),0))-3',
 '(AVG(POW(<<col>>-<<mean>>,4))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),2),0))-3',
 '(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,4))/NULLIF(POWER(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,2)),2),0))-3',
 1, 3, 'B'),

('box_plot', 'Box Plot', 'numeric', FALSE,FALSE,TRUE,
 NULL,NULL,NULL,NULL,NULL,NULL, 2, 12, 'B'),
-- box_plot is a meta-stat; generator expands to p25 + median + p75.

-- ── Pass C: Group-by expressions ─────────────────────────────────────────────

('cast_to_string', 'Distribution', 'all', FALSE,TRUE,TRUE,
 'TO_CHAR(<<col>>)', 'CAST(<<col>> AS STRING)', 'CAST(<<col>> AS CHAR)',
 '<<col>>::TEXT', 'CAST(<<col>> AS CHAR)', 'CAST(<<col>> AS VARCHAR)',
 0, 1, 'C'),

('pattern_mask', 'Pattern Distribution', 'string', FALSE,FALSE,TRUE,
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,r''[A-Za-z]'',''A''),r''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 0, 2, 'C'),

('histogram', 'Histogram', 'numeric', FALSE,FALSE,TRUE,
 'WIDTH_BUCKET(CAST(<<col>> AS FLOAT),CAST(<<min>> AS FLOAT),CAST(<<max>> AS FLOAT),<<n_buckets>>)',
 NULL,
 NULL,
 'WIDTH_BUCKET(<<col>>::FLOAT,<<min>>::FLOAT,<<max>>::FLOAT,<<n_buckets>>)',
 NULL,
 'WIDTH_BUCKET(CAST(<<col>> AS FLOAT),CAST(<<min>> AS FLOAT),CAST(<<max>> AS FLOAT),<<n_buckets>>)',
 3, 20, 'C'),

('shapiro_wilk', 'Shapiro-Wilk', 'numeric', FALSE,FALSE,TRUE,
 NULL,NULL,NULL,NULL,NULL,NULL, 0, 0, 'B'),
-- Computed in Python (scipy), not pushed to DB. Listed here for pack membership
-- and UI label only. No SQL expression.

-- ── Structural helpers (not user-facing — ui_label NULL, no pack membership) ─

('deterministic_sample_where', NULL, NULL, FALSE,FALSE,FALSE,
 'ORA_HASH(<<pk_col>>,<<bucket_count>>)=0',
 'MOD(ABS(FARM_FINGERPRINT(CAST(<<pk_col>> AS STRING))),<<bucket_count>>)=0',
 'MOD(CRC32(<<pk_col>>),<<bucket_count>>)=0',
 'MOD(ABS(hashtext(<<pk_col>>::TEXT)),<<bucket_count>>)=0',
 'MOD(CRC32(<<pk_col>>),<<bucket_count>>)=0',
 'MOD(ABS(CAST(HASH(<<pk_col>>) AS BIGINT)),<<bucket_count>>)=0',
 0, 0, 'B'),

('block_sample_from', NULL, NULL, FALSE,FALSE,FALSE,
 '<<table>> SAMPLE BLOCK(<<pct>>)',
 '<<table>> TABLESAMPLE SYSTEM (<<pct>> PERCENT)',
 NULL,
 '<<table>> TABLESAMPLE SYSTEM (<<pct>>)',
 NULL, NULL, 0, 0, 'B'),

('subquery_alias', NULL, NULL, FALSE,FALSE,FALSE,
 '(<<sql>>) <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 0, 0, 'A'),

('top_n_clause', NULL, NULL, FALSE,FALSE,FALSE,
 'FETCH FIRST <<n>> ROWS ONLY', 'LIMIT <<n>>', 'LIMIT <<n>>',
 'LIMIT <<n>>', 'LIMIT <<n>>', 'LIMIT <<n>>',
 0, 0, 'A'),

('random_order', NULL, NULL, FALSE,FALSE,FALSE,
 'DBMS_RANDOM.VALUE', 'RAND()', 'RAND()', 'RANDOM()', 'RAND()', 'RANDOM()',
 0, 0, 'A'),

('total_rows', NULL, NULL, FALSE,FALSE,FALSE,
 NULL,NULL,NULL,NULL,NULL, 'COUNT(*)', 0, 0, 'A')

ON CONFLICT (stat) DO UPDATE SET
    ui_label   = EXCLUDED.ui_label,
    applies_to = EXCLUDED.applies_to,
    in_basic   = EXCLUDED.in_basic,
    in_standard = EXCLUDED.in_standard,
    in_advanced = EXCLUDED.in_advanced,
    oracle      = EXCLUDED.oracle,
    bigquery    = EXCLUDED.bigquery,
    mysql       = EXCLUDED.mysql,
    postgres    = EXCLUDED.postgres,
    singlestore = EXCLUDED.singlestore,
    sql         = EXCLUDED.sql,
    cost_tier   = EXCLUDED.cost_tier,
    cost_weight = EXCLUDED.cost_weight,
    pass_group  = EXCLUDED.pass_group;

-- Set approx_pass_group for percentiles
UPDATE stat2sql SET
    approx_pass_group_oracle      = 'A',
    approx_pass_group_bigquery    = 'A',
    approx_pass_group_singlestore = 'A',
    approx_pass_group_postgres    = 'B',
    approx_pass_group_mysql       = 'B'
WHERE stat IN ('p25','median_val','p75','p90','p95','p99');


-- ==============================================================================
-- 4. Updated effective_column_stats view (no longer joins stat_pack_contents)
-- ==============================================================================

CREATE OR REPLACE VIEW effective_column_stats AS
SELECT
    pcc.column_config_id,
    pcc.config_id,
    pcc.column_name,
    pcc.data_type,
    pcc.stat_pack,
    pcc.is_active,
    pcc.deselected_stats,
    COALESCE(pcc.runtime_cardinality_class,
             pcc.schema_cardinality_class,
             'PRE_UNKNOWN') AS effective_cardinality_class,

    -- All stat_keys in the pack (direct filter on stat2sql boolean columns)
    ARRAY_AGG(s.stat ORDER BY s.stat)
        FILTER (WHERE
            CASE pcc.stat_pack
                WHEN 'BASIC'     THEN s.in_basic
                WHEN 'STANDARD'  THEN s.in_standard
                WHEN 'ADVANCED'  THEN s.in_advanced
                ELSE FALSE
            END
        ) AS pack_stat_keys,

    -- Stat keys after user deselections and cardinality restrictions are applied
    ARRAY_AGG(s.stat ORDER BY s.stat)
        FILTER (WHERE
            CASE pcc.stat_pack
                WHEN 'BASIC'     THEN s.in_basic
                WHEN 'STANDARD'  THEN s.in_standard
                WHEN 'ADVANCED'  THEN s.in_advanced
                ELSE FALSE
            END
            AND NOT (s.stat = ANY(COALESCE(pcc.deselected_stats, ARRAY[]::TEXT[])))
            AND NOT EXISTS (
                SELECT 1
                FROM   stat_cardinality_restrictions r
                WHERE  r.cardinality_class = COALESCE(
                           pcc.runtime_cardinality_class,
                           pcc.schema_cardinality_class,
                           'PRE_UNKNOWN')
                AND    r.stat_key          = s.stat
                AND    r.restriction_type  = 'BLOCK'
            )
        ) AS effective_stat_keys

FROM profiler_config_columns pcc
CROSS JOIN stat2sql s
WHERE pcc.is_active = TRUE
AND   s.ui_label IS NOT NULL   -- exclude structural helpers from pack resolution
GROUP BY
    pcc.column_config_id, pcc.config_id, pcc.column_name, pcc.data_type,
    pcc.stat_pack, pcc.is_active, pcc.deselected_stats,
    pcc.schema_cardinality_class, pcc.runtime_cardinality_class;


-- ==============================================================================
-- 5. Updated stat_pass_routing view (source unchanged, still works)
-- ==============================================================================

CREATE OR REPLACE VIEW stat_pass_routing AS
SELECT
    stat,
    platform,
    CASE platform
        WHEN 'oracle'      THEN COALESCE(approx_pass_group_oracle,      pass_group)
        WHEN 'bigquery'    THEN COALESCE(approx_pass_group_bigquery,    pass_group)
        WHEN 'singlestore' THEN COALESCE(approx_pass_group_singlestore, pass_group)
        WHEN 'postgres'    THEN COALESCE(approx_pass_group_postgres,    pass_group)
        WHEN 'mysql'       THEN COALESCE(approx_pass_group_mysql,       pass_group)
        ELSE pass_group
    END AS effective_pass_group
FROM stat2sql
CROSS JOIN (VALUES ('oracle'),('bigquery'),('singlestore'),('postgres'),('mysql')) AS p(platform);
