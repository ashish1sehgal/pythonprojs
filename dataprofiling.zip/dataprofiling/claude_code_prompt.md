# Claude Code Prompt — Enterprise Data Profiler Implementation

## Project Overview

Implement a production-grade, enterprise-scale federated data profiling engine. The architecture and all design decisions are finalised. Your job is to implement them faithfully, resolve any gaps in the code that already exists, wire the modules together, and produce a deployable package.

The system profiles wide tables (500–6000 columns, billions of rows) across Oracle, BigQuery, MySQL, Postgres, and SingleStore source databases. It runs in a federated GCP architecture where multiple teams execute the profiler in their own environments and results flow to a central storage layer.

---

## Repository Structure to Create

```
profiler/
├── sql/
│   ├── 01_postgres_schema.sql
│   ├── 02_stat2sql_seed.sql
│   ├── 03_bq_schema.sql
│   ├── migrations/
│   │   ├── 04_stat2sql_consolidated.sql        # merge stat_ui_map + stat_pack_contents
│   │   ├── 05_stat2sql_min_pack.sql            # replace three booleans with min_pack
│   │   ├── 06_stat2sql_approx_percentile.sql   # APPROX_PERCENTILE routing
│   │   ├── 07_stat2sql_pass1_moments.sql       # power-sum aggregates
│   │   ├── 08_stat_cost_config_revision.sql    # remove max_standard_columns
│   │   └── 09_ondemand_schema.sql              # profiler_ondemand_stats table
├──
- man.py
---

## Architecture — Read This in Full Before Writing Any Code

### The Pass Structure (Final)

```
Pass 1 — Full population scan, DB-native pushdown via stat2sql
  Computes per batch (batch_size = 50 columns):
    - null count, min, max, mean, stddev, valid count
    - approx distinct (HLL: APPROX_COUNT_DISTINCT)
    - sign counts (zero, positive, negative)
    - string lengths (min_length, max_length)
    - APPROX_PERCENTILE p25/median/p75/p90/p95/p99
      (Oracle 12.2+, BigQuery, SingleStore only — O(n) sketch)
    - Power sums: SUM(col), SUM(col²), SUM(col³), SUM(col⁴)
      Cast to BIGNUMERIC/NUMBER/NUMERIC for precision
  Python post-processing (moment_calculator.py):
    - skewness and kurtosis from power sums via decimal module (prec=50)
    - power sums stripped before storage (internal intermediates only)

Pass 2 — Sampled aggregation (Postgres and MySQL ONLY)
  Fires ONLY for platforms without APPROX_PERCENTILE.
  For Oracle/BigQuery/SingleStore: Pass 2 does not run.
  Computes PERCENTILE_CONT on deterministic hash sample (~1M rows):
    - p25, median, p75, p90, p95, p99
  Sampling: same SamplingClause as all other passes (deterministic hash)

Pass 3 — Spark grouping sets on cached 1M-row sample
  One JDBC read of Pass-3-eligible columns (ADVANCED pack, ≤ 100 columns)
  Same deterministic hash sample clause as Pass 2
  Pull → cache in Spark → three computations on cached DataFrame:
    - Frequency distributions (stack/melt → groupBy → top-N per column)
    - Pattern distributions (regex mask then same stack approach)
    - Histograms (floor-based bucketing using Pass-1 min/max)
  max_pass3_columns_per_run = 100 (stat_cost_config)
  For columns beyond 100: on-demand tier handles them

On-demand tier (user-triggered, results cached in profiler_ondemand_stats)
  - Distributions, patterns, histograms for columns beyond the 100 limit
  - Normality tests: Shapiro-Wilk, Anderson-Darling, Kolmogorov-Smirnov
  - TTL: 24 hours default (stat_cost_config: ondemand_cache_ttl_hours)
  - PSI stays in scheduled runs only (needs point-in-time baseline)
```

### Stat Registry and stat2sql

`stat2sql` is the single source of truth for all SQL expressions and stat metadata. No SQL expression is hardcoded anywhere in Python. All rendering goes through `StatTemplateRegistry.render(stat, **params)`.

Key columns on `stat2sql`:
- `stat` — primary key
- `oracle`, `bigquery`, `mysql`, `postgres`, `singlestore`, `sql` — platform expressions
- `min_pack` — `'BASIC'|'STANDARD'|'ADVANCED'|NULL`. A stat is in a pack if `pack_level(min_pack) <= pack_level(requested_pack)`. NULL = internal helper, not user-facing.
- `ui_label` — display name for the UI matrix. NULL = internal helper.
- `applies_to` — `'numeric'|'string'|'all'`
- `pass_group` — `'A'|'B'|'C'` (global default pass)
- `approx_pass_group_oracle/bigquery/singlestore/postgres/mysql` — per-platform pass routing for percentiles (overrides pass_group)
- `derived_from` — comma-separated stat keys whose Pass-1 aggregates are needed to compute this stat in Python (used by skewness/kurtosis)

The `stat_pass_routing` view resolves effective_pass_group per stat per platform.

### Sampling

`SamplingManager` builds one `SamplingClause` per run, reused across all batches.

Default (DETERMINISTIC): `WHERE ORA_HASH(pk_col, bucket_count) = 0` — same rows in all batches.
Opt-in (BLOCK): `TABLESAMPLE` — faster on >50B rows, slightly different rows per batch.

**All 10 batches of a 2000-column table use the identical WHERE clause. This is the guarantee of cross-batch consistency.**

PK column resolution order:
1. `pk_cols` in profiler_configs (user-specified)
2. information_schema auto-detection
3. ROW_NUMBER() fallback (non-deterministic — flagged in gating log)

### Cardinality Classification

Two-layer system:

`schema_cardinality_class` (PRE_PK, PRE_UNIQUE, PRE_HIGH, PRE_LOW, PRE_INDEXED, PRE_UNKNOWN):
- Derived from information_schema at config-save time
- No data read; purely structural

`runtime_cardinality_class` (PRIMARY_KEY, HIGH_CARDINALITY, CATEGORICAL, LOW_CARDINALITY, BINARY, CONSTANT, ALL_NULL):
- Derived from Pass-1 HLL distinct count
- Takes precedence via COALESCE(runtime, schema, 'PRE_UNKNOWN')

Classification thresholds (all in stat_cost_config, not hardcoded):
- `primary_key_ratio = 0.95` — distinct/total > this → PRIMARY_KEY
- `high_cardinality_ratio = 0.10` — distinct/total > this → HIGH_CARDINALITY
- `categorical_threshold = 1000` — distinct < this → CATEGORICAL

Gating rules:
- Pass 2: numeric only, not CONSTANT/ALL_NULL/PRIMARY_KEY
- Pass 3 distributions/patterns: string only, CATEGORICAL or LOW_CARDINALITY
- Pass 3 histograms: numeric, min != max, not CONSTANT/ALL_NULL

### Unpivot Strategy

JDBC returns one wide row per batch (all column stats as aliases). Python unpivots via longest-suffix-match against `ALL_STAT_SUFFIXES`. After unpivot, `moment_calculator.enrich_moments_from_power_sums()` derives skewness/kurtosis per column and strips the power-sum intermediates. Then `result_unpivot.enrich_column_metrics()` computes stddev CI, box-plot whiskers, and TEXT-casts min/max.

**Database UNPIVOT is  used for Bigquery**

### Wide table Strategy
Because Bigquery supports upto 10000 column and we have wide tables upto 6000 columns. If we calculate even 2 stats per column, it goes beyond the acceptable limit. While we do have baatching included, we caaan easily bypass the limit of 10000 by using to_json_string(struct(avg(col) as avg,min(col) as min)) as col.
If similar approah exists for Oracle, please include it as well. We will still have batching strategy to keep a balance between the query execution and memory requirements.

### Federated Output (GCS → PubSub → Dataflow → BQ + Postgres)

Team-side (Dataproc):
1. `GCSOutputWriter.write_all()` writes 5 NDJSON files to `gs://bucket/runs/{run_id}/`
2. Manifest written LAST (atomicity guarantee)
3. PubSub notification published with manifest URI only (<1KB)

Central-side (Dataflow streaming):
1. `ReadFromPubSub` → parse manifest URI
2. `ReadManifest` → expand to per-file read tasks
3. `ReadNDJSON` → tag with ingested_at
4. `RouteByFile` → tagged outputs
5. `WriteToBigQuery` (Storage Write API, exactly-once, triggering_frequency=60s)
6. `WriteToPostgres` (JDBC upsert via VPC, batch_size=500, ON CONFLICT DO UPDATE)
7. Dead-letter routing → PubSub topic for any malformed records

### CI View (No Stored CI Columns)

Mean CI and StdDev CI are never stored in `profiler_run_metrics`. They are computed at query time in the `profiler_run_metrics_with_ci` view:
- Mean CI: pure SQL arithmetic (stddev/sqrt(n))
- StdDev CI: chi-squared lookup table join (`chi2_critical_values`, populated by `ci_view_utils.populate_chi2_table()`)

Run `ci_view_utils.populate_chi2_table(pg_creds)` once at deployment.

### On-Demand Tier

`OnDemandQueryService.get_histogram/get_distribution/get_pattern()` follows a fetch-or-cache pattern:
1. Check `profiler_ondemand_stats` for a non-expired cached result
2. If fresh: return with `"source": "cache"`
3. If stale/absent: run live query, store (upsert), return with `"source": "live"`

On-demand results are NEVER tagged with a `run_id`. They are never used for PSI/drift. The UI must label them "Live query — current data."

---

## Implementation Tasks

Work through these in order. Do not start task N+1 until task N is complete and tested.

### Task 1: SQL Setup
- Consolidate all SQL files into correct migration order
- Create `sql/` directory with numbered files in execution order
- Verify all foreign key references resolve (stat_cardinality_restrictions → stat2sql, stat_packs stay as separate table)
- Run `ci_view_utils.populate_chi2_table()` as a migration step
- Ensure `stat_pass_routing` view, `effective_column_stats` view, `profiler_run_metrics_with_ci` view, `pack_level()` function all exist

### Task 2: StatTemplateRegistry
- Implement the consolidated single-query load (all stat metadata, pack membership via min_pack, per-platform pass routing in one SQL call)
- `get_pack_stats(pack_name)` uses `pack_level(min_pack) <= pack_level(pack_name)` logic
- `pass1_stats()`, `pass2_stats()`, `pass3_stats()` filter by effective_pass_group
- `ui_stats_for_pack(pack_name, data_type)` excludes NULL ui_label rows
- `derived_from` loaded per stat (for skewness/kurtosis power-sum routing)

### Task 3: Pass 1 SQL Generator
- `generate_pass1_sql(table, batch_cols, registry, pass_routing)` emits:
  - Always-on basics (empty_count, distinct_count, min, max, mean, valid_count, total_rows)
  - Numeric extras from pack (stddev, sign counts, exact_distinct)
  - String lengths
  - APPROX_PERCENTILE for Oracle/BQ/SingleStore (skip for Postgres/MySQL — Pass 2 handles these)
  - Power sums (sum_x, sum_x2, sum_x3, sum_x4) for all numeric columns — always, when skewness or kurtosis is in the effective stat set
  - For BigQuery: one APPROX_QUANTILES(col,100) call per numeric column covers ALL percentiles
- Returns `(sql, bq_array_cols)` where `bq_array_cols = {col_name: alias}` for BQ unpacking

### Task 4: Column Classifier
- Loads all thresholds from stat_cost_config (no hardcoded values)
- `classify_all()` runs after Pass 1; sets `cardinality_class` on each ColumnProfile
- Sets `run_pass2`, `run_pass3`, `run_pass4_psi` flags with skip reasons
- Writes gating decisions to `profiler_run_column_gating`

### Task 5: Moment Calculator
- `compute_skewness_kurtosis(sum_x, sum_x2, sum_x3, sum_x4, n)` using `decimal.Decimal` at precision 50
- Handles None inputs, n < 3, zero variance — returns (None, None) not exceptions
- `enrich_moments_from_power_sums(column_metrics)` strips power sums, adds skewness/kurtosis
- Unit test with known values: for a normal distribution N(μ=10^6, σ=10^3), skewness should be ~0, kurtosis ~0

### Task 6: Sampling Manager
- `resolve(total_rows, source_table, source_conn)` builds one SamplingClause
- Deterministic default: hash WHERE clause using platform-appropriate function
- PK resolution in order: config → information_schema → ROW_NUMBER() fallback
- `SamplingClause.inject_into_sql(sql, table_name)` handles both WHERE injection and FROM suffix (BLOCK mode)
- Log a warning when ROW_NUMBER() fallback is used

### Task 7: Pass 2 Generator (Postgres/MySQL only)
- Guard: if `registry.platform in ('oracle','bigquery','singlestore')`, return empty immediately
- Percentile stats only — skewness/kurtosis no longer in Pass 2
- Same sampling clause injected as all other passes
- BQ path: dead code (never called for BQ) — add assertion to confirm

### Task 8: Pass 3 Spark Module
- `pull_and_cache_pass3_sample()`: JDBC pull of eligible columns only (not SELECT *), `.cache()`
- `compute_distributions()`: stack() melt + groupBy + window top-N
- `compute_patterns()`: F.regexp_replace mask then same stack approach
- `compute_histograms()`: floor-based bucketing per column, baseline-aligned when PSI configured
- `run_pass3_spark()`: orchestrates all three, calls `.unpersist()` after all computations complete
- Respect `max_pass3_columns_per_run` from stat_cost_config

### Task 9: PSI Calculator
- `BaselineHistogramLoader.load()`: loads baseline buckets from profiler_run_histograms
- `PSICalculator.compute()`: PSI formula with epsilon guard, classifies STABLE/MODERATE/UNSTABLE
- Baseline boundaries reused for Pass 3 histogram queries (PSI alignment)
- Stays in scheduled run only — on-demand does not do PSI

### Task 10: Result Unpivot
- `unpivot_pass_results(flat, col_names)`: longest-suffix-match against ALL_STAT_SUFFIXES
- `enrich_moments_from_power_sums()`: call before enrichment, strips intermediates
- `enrich_column_metrics()`: stddev CI via scipy, box-plot whiskers (q3-q1, ±1.5*IQR), TEXT cast for min/max
- `build_column_metric_rows()`: merges pass1 + pass2 + pass4 results
- `write_metrics_batch()`, `write_distributions()`, `write_patterns()`, `write_histograms()`, `write_gating()`: batched upserts

### Task 11: Pass Orchestrator
- `execute_profiling_job()` coordinates the revised 2-pass + on-demand structure:
  1. Pre-load baseline histograms (if baseline_run_id configured)
  2. Build SamplingClause (resolve after Pass 1 gives total_rows)
  3. Pass 1: batch loop, JDBC, BQ quantile unpack, moment enrichment
  4. Classify columns (ColumnClassifier)
  5. Pass 2: only if platform in (postgres, mysql) AND any column has unresolved percentiles
  6. Pass 3: Spark grouping sets on sample
  7. Pass 4: PSI only (normality moved to on-demand)
  8. Unpivot + enrich
  9. Federated output (GCS + PubSub) or local Postgres write
- Log pass skipping clearly: "Pass 2 skipped — platform=oracle, percentiles computed in Pass 1"

### Task 12: GCS Output Writer + Dataflow Pipeline
- `GCSOutputWriter.write_all()`: data files first, manifest last, PubSub after manifest confirmed
- Manifest includes schema_version, file row counts, GCS paths
- Dataflow pipeline: streaming, Storage Write API for BQ, JDBC upsert for Postgres
- Dead-letter routing on every DoFn
- `WriteToPostgres` uses ON CONFLICT DO UPDATE for idempotent replay

### Task 13: On-Demand Services
- `OnDemandQueryService`: fetch-or-cache pattern, TTL from stat_cost_config
- `normality_ondemand.run_normality_tests()`: SW (n≤5000), Anderson-Darling, KS
- Both store results in `profiler_ondemand_stats` with no run_id
- Results tagged with interpretation note warning against over-interpretation

### Task 14: Config Validator
- `validate()`: pack membership check, cardinality restriction check, ADVANCED count limit
- STANDARD column count: NO LIMIT (batching solves alias ceiling)
- `compute_safe_batch_size()`: per-batch alias guard for Oracle (not per-run)
- `update_runtime_cardinality()`: writes back from profiler_run_metrics after each run
- All limits from stat_cost_config — zero hardcoded thresholds

### Task 15: Airflow DAG
- DAG reads config via Spring Boot API (no direct DB access from team environment)
- Submits Dataproc Serverless job with `execute_profiling_job()` as entry point
- Task timeout from `max_run_duration_minutes` in stat_cost_config
- On completion: notify Central API to flip run status → triggers runtime cardinality update

### Task 16: Tests
- Unit tests for: moment_calculator (precision validation), sampling_manager (determinism), config_validator (all error paths), stat_registry (pack resolution, pass routing)
- Integration tests: full Pass 1 against a local Postgres fixture table; Pass 3 Spark against a small cached DataFrame
- Fixture: a 100-column table with known statistical properties (seeded random data with specific skewness/kurtosis targets)

---

## Hard Constraints — Do Not Violate These

1. **No SQL expressions hardcoded in Python.** Every SQL fragment must come from `registry.render()` or `registry.render_or_none()`. The only exception is structural Python string operations like f-string table name injection.

2. **No DB UNPIVOT.** Python-side dict iteration for the wide-to-per-column transformation.

3. **No sampling percentage exposed to users.** `target_sample_rows` is admin-only in stat_cost_config. The UI shows computed sample size as read-only information.

4. **No CI values stored in profiler_run_metrics.** They are view-computed. Do not add mean_ci_lower/upper or stddev_ci_lower/upper columns.

5. **Manifest written last.** GCS data files first, manifest only after all five files are confirmed written. PubSub published only after manifest is confirmed.

6. **Power sums are internal intermediates.** Never stored in profiler_run_metrics. Stripped by `enrich_moments_from_power_sums()` before any write.

7. **On-demand results have no run_id.** Never join profiler_ondemand_stats to profiler_runs. Never use on-demand results for drift/PSI.

8. **All thresholds in stat_cost_config.** No numeric threshold (cardinality ratios, batch sizes, column limits, TTLs) hardcoded in Python. Load at job start; cache in memory for the duration of the run.

9. **Pass 2 platform guard.** For Oracle, BigQuery, and SingleStore, `run_pass2` must return immediately after the platform check. Add an assertion in tests.

10. **BIGNUMERIC/NUMBER casting for power sums.** `sum_x3` and `sum_x4` must use arbitrary-precision decimal casting in SQL. Using FLOAT/FLOAT64 for these is a correctness bug, not a performance trade-off.

---

## Key Design Decisions Already Made — Do Not Reopen

- **stat_ui_map and stat_pack_contents are dropped.** Merged into stat2sql via ui_label, applies_to, min_pack.
- **max_standard_columns_per_run is removed.** Batching solves the Oracle alias ceiling. Only ADVANCED count is limited.
- **Normality tests (Shapiro-Wilk, Anderson-Darling, KS) are on-demand only.** Not batch.
- **Pass 3 runs on a 1M-row Spark sample, not full population.** Shape analysis does not require exact counts.
- **Grouping sets for Pass 3 via Spark stack()/groupBy(), not DB GROUPING SETS.** DB limits (Oracle 32, BQ 50) are avoided entirely.
- **Histograms use floor-based bucket arithmetic in Spark, not WIDTH_BUCKET.** Avoids platform SQL differences for Pass 3.
- **CI is a view, not stored columns.** chi2_critical_values populated once at deploy.
- **PSI stays in scheduled batch runs.** On-demand tier does not compute PSI.
- **stat_packs table is retained.** It holds pack-level metadata (display name, description) separate from per-stat metadata.

---

## Dependencies

```
# requirements.txt
pyspark>=3.4.0
apache-beam[gcp]>=2.50.0
google-cloud-storage>=2.10.0
google-cloud-pubsub>=2.18.0
psycopg2-binary>=2.9.9
scipy>=1.11.0
numpy>=1.24.0
# decimal is stdlib — no install needed
```

Platform JDBC drivers (provided at runtime by Dataproc image):
- Oracle: ojdbc8.jar
- BigQuery: spark-bigquery-connector
- MySQL: mysql-connector-java.jar
- Postgres: postgresql.jar
- SingleStore: singlestore-jdbc-client.jar

---

## Verification Checklist Before Marking Any Task Complete

For each module:
- [ ] No hardcoded SQL expressions
- [ ] No hardcoded numeric thresholds (all from stat_cost_config)
- [ ] All platform differences handled via stat2sql registry
- [ ] All error paths return structured errors, not bare exceptions
- [ ] Power sums never written to profiler_run_metrics
- [ ] On-demand results never tagged with run_id
- [ ] Manifest written after all data files confirmed
- [ ] Pass 2 platform guard present and tested

---

## What Not to Build

- No REST API implementation (that is Spring Boot / Java, out of scope)
- No Airflow plugin (DAG only)
- No Docker configuration
- No Terraform / infrastructure as code
- No UI components
- No Cloud Run or Cloud Functions (infosec restriction — Dataflow only for central ingestion)
