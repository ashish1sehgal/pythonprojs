-- ==============================================================================
-- stat2sql: Replace three boolean pack columns with single min_pack column
-- ==============================================================================
-- The three-boolean model (in_basic, in_standard, in_advanced) encodes a
-- subset hierarchy with an implicit constraint:
--   in_standard = TRUE implies in_basic = TRUE
--   in_advanced = TRUE implies in_standard = TRUE
-- Maintaining this constraint across three columns is redundant state that
-- can drift. One column expressing the minimum required pack level is correct.
--
-- min_pack values: 'BASIC' | 'STANDARD' | 'ADVANCED'
-- Membership rule: a stat belongs to a pack if min_pack <= pack (by level order)
-- Pack order:      BASIC=1, STANDARD=2, ADVANCED=3
-- ==============================================================================

-- 1. Add the single column
ALTER TABLE stat2sql
    ADD COLUMN IF NOT EXISTS min_pack VARCHAR(20)
        CHECK (min_pack IN ('BASIC','STANDARD','ADVANCED'));

-- 2. Populate from existing three-boolean columns (migration path)
UPDATE stat2sql SET min_pack =
    CASE
        WHEN in_basic    THEN 'BASIC'
        WHEN in_standard THEN 'STANDARD'
        WHEN in_advanced THEN 'ADVANCED'
        ELSE NULL   -- structural helpers (no pack membership)
    END;

-- 3. Drop the three redundant columns
ALTER TABLE stat2sql
    DROP COLUMN IF EXISTS in_basic,
    DROP COLUMN IF EXISTS in_standard,
    DROP COLUMN IF EXISTS in_advanced;

-- 4. Add a helper function for pack level ordering
--    Avoids repeating the CASE expression in every query.
CREATE OR REPLACE FUNCTION pack_level(pack_name TEXT)
RETURNS INT LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
    SELECT CASE pack_name
        WHEN 'BASIC'    THEN 1
        WHEN 'STANDARD' THEN 2
        WHEN 'ADVANCED' THEN 3
        ELSE 0
    END
$$;

-- 5. Updated effective_column_stats view
--    Membership check: pack_level(s.min_pack) <= pack_level(pcc.stat_pack)
CREATE OR REPLACE VIEW effective_column_stats AS
SELECT
    pcc.column_config_id,
    pcc.config_id,
    pcc.column_name,
    pcc.data_type,
    pcc.stat_pack,
    pcc.is_active,
    pcc.deselected_stats,
    COALESCE(pcc.runtime_cardinality_class,
             pcc.schema_cardinality_class,
             'PRE_UNKNOWN') AS effective_cardinality_class,

    -- All stats available in this column's pack
    ARRAY_AGG(s.stat ORDER BY s.stat)
        FILTER (WHERE pack_level(s.min_pack) <= pack_level(pcc.stat_pack))
        AS pack_stat_keys,

    -- Stats that will actually run: pack membership - deselections - blocked
    ARRAY_AGG(s.stat ORDER BY s.stat)
        FILTER (WHERE
            pack_level(s.min_pack) <= pack_level(pcc.stat_pack)
            AND NOT (s.stat = ANY(COALESCE(pcc.deselected_stats, ARRAY[]::TEXT[])))
            AND NOT EXISTS (
                SELECT 1
                FROM   stat_cardinality_restrictions r
                WHERE  r.cardinality_class = COALESCE(
                           pcc.runtime_cardinality_class,
                           pcc.schema_cardinality_class,
                           'PRE_UNKNOWN')
                AND    r.stat_key         = s.stat
                AND    r.restriction_type = 'BLOCK'
            )
        ) AS effective_stat_keys

FROM profiler_config_columns pcc
CROSS JOIN stat2sql s
WHERE pcc.is_active = TRUE
AND   s.min_pack IS NOT NULL   -- exclude structural helpers
GROUP BY
    pcc.column_config_id, pcc.config_id, pcc.column_name, pcc.data_type,
    pcc.stat_pack, pcc.is_active, pcc.deselected_stats,
    pcc.schema_cardinality_class, pcc.runtime_cardinality_class;


-- 6. Seed data with min_pack (complete replacement for stat2sql INSERT)
--    Only the min_pack column shown for brevity — full row context unchanged.
--
--    BASIC     : empty_count, distinct_count, min_val, max_val, mean_val,
--                min_length, max_length
--    STANDARD  : stddev_val, zero/positive/negative_count, median_val,
--                p25, p75, p95, skewness, kurtosis, cast_to_string
--    ADVANCED  : exact_distinct_count, p90, p99, box_plot, histogram,
--                pattern_mask, shapiro_wilk
--    NULL      : structural helpers (deterministic_sample_where, subquery_alias, etc.)

UPDATE stat2sql SET min_pack = 'BASIC'    WHERE stat IN
    ('empty_count','distinct_count','min_val','max_val','mean_val','min_length','max_length');

UPDATE stat2sql SET min_pack = 'STANDARD' WHERE stat IN
    ('stddev_val','zero_count','positive_count','negative_count',
     'median_val','p25','p75','p95','skewness','kurtosis','cast_to_string');

UPDATE stat2sql SET min_pack = 'ADVANCED' WHERE stat IN
    ('exact_distinct_count','p90','p99','box_plot','histogram','pattern_mask','shapiro_wilk');

UPDATE stat2sql SET min_pack = NULL WHERE stat IN
    ('valid_count','total_rows','deterministic_sample_where','block_sample_from',
     'subquery_alias','top_n_clause','random_order');
