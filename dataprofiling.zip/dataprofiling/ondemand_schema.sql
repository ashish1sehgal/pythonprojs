-- ==============================================================================
-- On-demand / lazy profiling schema
-- ==============================================================================
-- Separates on-demand column stats from scheduled batch profiling results.
-- Batch results have a run_id (point-in-time anchor).
-- On-demand results have no run_id — they represent current state at query time.
--
-- Industry pattern: Databricks Unity Catalog, Atlan, Alation, Dataplex all
-- use this two-tier model. Scheduled = historical record. On-demand = now.
--
-- TTL strategy
-- ------------
-- On-demand results expire after ondemand_cache_ttl_hours (stat_cost_config).
-- The Spring Boot API checks queried_at + TTL before deciding to re-query.
-- Default: 24 hours. For fast-moving tables, set lower. For static reference
-- data, set higher (7 days or NULL = never expire).
-- ==============================================================================

CREATE TABLE IF NOT EXISTS profiler_ondemand_stats (
    ondemand_id       SERIAL PRIMARY KEY,

    -- Identity — what was queried
    source_platform   VARCHAR(50)  NOT NULL,
    database_schema   VARCHAR(255) NOT NULL,
    target_table      VARCHAR(255) NOT NULL,
    column_name       VARCHAR(255) NOT NULL,
    stat_type         VARCHAR(30)  NOT NULL,
    -- 'distribution' | 'pattern' | 'histogram'

    -- Who requested it and when
    requested_by      VARCHAR(255),
    queried_at        TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    query_duration_ms INT,

    -- The query that was executed (for audit / replay)
    source_sql        TEXT,

    -- Expiry — NULL means never expire (for static reference tables)
    expires_at        TIMESTAMPTZ,

    -- Result payload — stored as JSONB for schema flexibility
    -- distribution: [{"val": "PENDING", "freq": 42000, "pct": 42.0}, ...]
    -- pattern:      [{"pattern_mask": "NNNN-NN-NN", "freq": 91000, "pct": 91.0}, ...]
    -- histogram:    [{"bucket_index": 1, "bucket_lower": 0, "bucket_upper": 500,
    --                 "frequency_count": 12000, "percentage": 12.0}, ...]
    result_payload    JSONB        NOT NULL,

    -- Metadata
    sample_rows_used  BIGINT,       -- NULL = full table; n = sample size
    is_sampled        BOOLEAN      NOT NULL DEFAULT FALSE,
    approx_total_rows BIGINT,       -- total rows in table at query time (from COUNT(*))

    -- On-demand results are NEVER tagged with a run_id.
    -- They cannot be compared with batch profiling results in drift analysis.
    -- This is intentional and mirrors industry practice.

    UNIQUE (source_platform, database_schema, target_table, column_name, stat_type)
    -- Unique per column per stat type: upsert on repeat request.
    -- If user clicks "View histogram" twice in one day, second click
    -- checks expires_at and serves cached result if still fresh.
);

CREATE INDEX IF NOT EXISTS idx_ondemand_lookup
    ON profiler_ondemand_stats (source_platform, database_schema, target_table, column_name);

CREATE INDEX IF NOT EXISTS idx_ondemand_expiry
    ON profiler_ondemand_stats (expires_at)
    WHERE expires_at IS NOT NULL;

COMMENT ON TABLE profiler_ondemand_stats IS
    'Stores on-demand column stats fetched when a user requests a histogram, '
    'distribution, or pattern for a column not covered by the scheduled batch run. '
    'Results are cached with a TTL and served from here on repeat requests. '
    'These are NOT tied to a run_id and represent current data, not point-in-time. '
    'Do not use for drift detection or baseline comparison — use profiler_run_* tables instead.';


-- ==============================================================================
-- stat_cost_config: Pass 3 batch limit and on-demand TTL
-- ==============================================================================

INSERT INTO stat_cost_config (config_key, config_value, description) VALUES

('max_pass3_columns_per_run', 100,
 'Maximum columns that receive distributions, patterns, and histograms in a '
 'scheduled batch run. Columns beyond this threshold get basic stats only '
 '(null count, min, max, mean) during the batch run. '
 'Users can fetch distributions/patterns/histograms for additional columns '
 'on-demand via the UI, which queries the source live and caches in '
 'profiler_ondemand_stats. '
 'Governs the Spark Pass-3 sample pull: max_pass3_columns × 1M rows. '
 'At 100 columns × 1M rows × ~20 bytes avg = ~2GB Spark cache. '
 'Increase for clusters with higher memory; decrease for resource-constrained envs.'),

('ondemand_cache_ttl_hours', 24,
 'Hours before an on-demand stat result expires in profiler_ondemand_stats. '
 'Spring Boot checks queried_at + TTL before deciding to re-query the source. '
 'Set lower for fast-changing tables (e.g. 4 hours for event streams). '
 'Set higher or NULL for static reference data (e.g. 168 hours = 7 days). '
 'NULL in profiler_ondemand_stats.expires_at means never expire for that row — '
 'overrides this default on a per-result basis.')

ON CONFLICT (config_key) DO UPDATE SET
    config_value = EXCLUDED.config_value,
    description  = EXCLUDED.description;
