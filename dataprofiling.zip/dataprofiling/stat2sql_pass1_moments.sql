-- ==============================================================================
-- stat2sql: Single-pass raw-moment skewness/kurtosis with high-precision casting
-- ==============================================================================
-- Moves skewness and kurtosis into Pass 1 by using raw moments computed in
-- arbitrary-precision decimal arithmetic. This eliminates the need for Pass-1
-- mean injection (the previous centred-moment approach) and removes Pass 2
-- entirely for platforms where percentiles already run in Pass 1.
--
-- The numerical safety requirement
-- ---------------------------------
-- Single-pass skewness cannot subtract the mean first (mean unknown until scan
-- completes). It must use raw moments:
--   skewness = (E[x³] - 3μE[x²] + 2μ³) / σ³
--   kurtosis = (E[x⁴] - 4μE[x³] + 6μ²E[x²] - 3μ⁴) / σ⁴ - 3
--
-- These formulas subtract large nearly-equal numbers. In FLOAT/DOUBLE this
-- causes catastrophic cancellation for columns with large magnitude values.
-- The fix: cast to arbitrary-precision decimal so the subtraction is exact.
--   Oracle    : CAST(col AS NUMBER)        — arbitrary precision
--   BigQuery  : CAST(col AS BIGNUMERIC)    — 76 digits of precision
--   Postgres  : col::NUMERIC               — arbitrary precision
--   MySQL     : CAST(col AS DECIMAL(65,10))— max DECIMAL precision
--   SingleStore: CAST(col AS DECIMAL(38,10))
--
-- Why not centred moments in one pass?
-- -------------------------------------
-- Centred moments AVG((col-μ)^k) require μ as a constant — impossible in a
-- single pass since μ is computed during the same scan. Raw moments are the
-- only single-pass option, and high-precision decimal makes them safe.
--
-- The aggregates needed (all computed in the same Pass 1 scan):
--   n        = COUNT(col)
--   sum_x    = SUM(col)
--   sum_x2   = SUM(col²)
--   sum_x3   = SUM(col³)
--   sum_x4   = SUM(col⁴)
-- Then skewness and kurtosis are derived in Python from these five sums.
-- This avoids re-deriving μ and σ inside the SQL — they come from sum_x, sum_x2.
--
-- We store the five power sums as separate stat2sql expressions and let the
-- Python layer (result_unpivot) combine them. This keeps the SQL simple and
-- moves the cancellation-sensitive arithmetic into Python where we control
-- precision explicitly with the decimal module.
-- ==============================================================================

-- Power-sum aggregates in high-precision decimal.
-- These run in Pass 1 (pass_group 'A') for all numeric columns when
-- skewness or kurtosis is requested.

INSERT INTO stat2sql (stat, ui_label, applies_to, min_pack,
    oracle, bigquery, mysql, postgres, singlestore, sql, pass_group) VALUES

('sum_x',  NULL, 'numeric', NULL,
 'SUM(CAST(<<col>> AS NUMBER))',
 'SUM(CAST(<<col>> AS BIGNUMERIC))',
 'SUM(CAST(<<col>> AS DECIMAL(65,10)))',
 'SUM(<<col>>::NUMERIC)',
 'SUM(CAST(<<col>> AS DECIMAL(38,10)))',
 'SUM(CAST(<<col>> AS DECIMAL(38,10)))', 'A'),

('sum_x2', NULL, 'numeric', NULL,
 'SUM(CAST(<<col>> AS NUMBER) * CAST(<<col>> AS NUMBER))',
 'SUM(CAST(<<col>> AS BIGNUMERIC) * CAST(<<col>> AS BIGNUMERIC))',
 'SUM(CAST(<<col>> AS DECIMAL(65,10)) * CAST(<<col>> AS DECIMAL(65,10)))',
 'SUM(<<col>>::NUMERIC * <<col>>::NUMERIC)',
 'SUM(CAST(<<col>> AS DECIMAL(38,10)) * CAST(<<col>> AS DECIMAL(38,10)))',
 'SUM(CAST(<<col>> AS DECIMAL(38,10)) * CAST(<<col>> AS DECIMAL(38,10)))', 'A'),

('sum_x3', NULL, 'numeric', NULL,
 'SUM(POWER(CAST(<<col>> AS NUMBER), 3))',
 'SUM(POW(CAST(<<col>> AS BIGNUMERIC), 3))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(65,10)), 3))',
 'SUM(POWER(<<col>>::NUMERIC, 3))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(38,10)), 3))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(38,10)), 3))', 'A'),

('sum_x4', NULL, 'numeric', NULL,
 'SUM(POWER(CAST(<<col>> AS NUMBER), 4))',
 'SUM(POW(CAST(<<col>> AS BIGNUMERIC), 4))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(65,10)), 4))',
 'SUM(POWER(<<col>>::NUMERIC, 4))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(38,10)), 4))',
 'SUM(POWER(CAST(<<col>> AS DECIMAL(38,10)), 4))', 'A')

ON CONFLICT (stat) DO UPDATE SET
    oracle=EXCLUDED.oracle, bigquery=EXCLUDED.bigquery, mysql=EXCLUDED.mysql,
    postgres=EXCLUDED.postgres, singlestore=EXCLUDED.singlestore, sql=EXCLUDED.sql,
    pass_group=EXCLUDED.pass_group;

-- Update skewness and kurtosis: now Pass 1, derived from power sums in Python.
-- The SQL columns become NULL because the computation moves to Python — the
-- power-sum aggregates above are what actually run in the Pass 1 SQL.
-- skewness/kurtosis remain in stat2sql for pack membership and UI labels.

UPDATE stat2sql SET
    oracle=NULL, bigquery=NULL, mysql=NULL, postgres=NULL, singlestore=NULL, sql=NULL,
    pass_group='A',
    min_pack='STANDARD'
WHERE stat IN ('skewness','kurtosis');

-- Mark that skewness/kurtosis require the power-sum aggregates.
-- The orchestrator reads this to know which aggregates to emit in Pass 1.
ALTER TABLE stat2sql ADD COLUMN IF NOT EXISTS derived_from TEXT;
COMMENT ON COLUMN stat2sql.derived_from IS
    'Comma-separated list of stat keys whose Pass-1 aggregate values are required '
    'to compute this stat in Python. e.g. skewness derived_from "sum_x,sum_x2,sum_x3,valid_count". '
    'When set, the orchestrator emits the listed aggregates in Pass-1 SQL and the '
    'result_unpivot layer computes this stat from them using high-precision arithmetic.';

UPDATE stat2sql SET derived_from = 'sum_x,sum_x2,sum_x3,valid_count' WHERE stat = 'skewness';
UPDATE stat2sql SET derived_from = 'sum_x,sum_x2,sum_x3,sum_x4,valid_count' WHERE stat = 'kurtosis';
