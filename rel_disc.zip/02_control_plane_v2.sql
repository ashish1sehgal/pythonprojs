-- ============================================================================
-- RELATIONSHIP DISCOVERY v2 — CONTROL PLANE SCHEMA (Postgres)
-- ============================================================================
-- Consolidated design at 10K-table / 500K-column scale.
--
-- Core principles encoded in this schema:
--   * Scans are TABLE-LOCAL (profiling+sketch ride-along, batched).
--   * Comparison is GLOBAL-OVER-SKETCHES only (LSH over ~150MB of signatures).
--   * Verification is PAIR-LOCAL (containment probes, pushdown BQ SQL).
--   * Composite discovery is NEVER global: it is a per-table-pair phase
--     triggered by settlement of >=2 same-direction unary edges.
--   * Lane routing is RATIO-PRIMARY: cardinality ratio > 1/t_LSH => CONTAINMENT
--     lane; the Mega tier line only pre-decides what never gets sketched.
--   * Confidence is GATED by mathematical existence (containment), MODULATED
--     by bounded semantic meaning (name/vocab now, LLM socket for Phase 2).
--     Semantic signals PROPOSE and PRIORITIZE; they never veto.
-- ============================================================================

-- ----------------------------------------------------------------------------
-- 1. TABLE REGISTRY — every table known to the platform
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS table_registry (
    table_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    source_system       TEXT NOT NULL DEFAULT 'bigquery',
    project_id          TEXT,
    dataset_id          TEXT,
    table_name          TEXT NOT NULL,
    table_fqn           TEXT NOT NULL,              -- project.dataset.table
    row_count           BIGINT,
    size_bytes          BIGINT,
    -- INFORMATION_SCHEMA signals (metadata harvest, Stage 0/1)
    partition_column    TEXT,                       -- PARTITIONED BY column
    clustering_columns  TEXT[],                     -- multi-col => composite hypothesis
    -- vocabulary cluster (column-name token domain, for scoping/affinity)
    vocab_tokens        TEXT[],
    -- change detection
    data_fingerprint    TEXT,
    fingerprint_at      TIMESTAMPTZ,
    is_profiled         BOOLEAN DEFAULT FALSE,
    is_sketched         BOOLEAN DEFAULT FALSE,      -- all sketch batches landed
    onboarded_at        TIMESTAMPTZ DEFAULT now(),
    last_seen_at        TIMESTAMPTZ DEFAULT now(),
    UNIQUE (source_system, table_fqn)
);
CREATE INDEX IF NOT EXISTS idx_reg_dataset ON table_registry(dataset_id);
CREATE INDEX IF NOT EXISTS idx_reg_sketched ON table_registry(is_sketched) WHERE NOT is_sketched;

-- ----------------------------------------------------------------------------
-- 2. COLUMN REGISTRY — the fenced, tiered column universe (Stage 0 output)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS column_registry (
    column_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_id            UUID NOT NULL REFERENCES table_registry(table_id),
    table_fqn           TEXT NOT NULL,
    column_name         TEXT NOT NULL,
    data_type           TEXT NOT NULL,
    -- profile stats (from the single-table profiler; inputs to fence + router)
    distinct_estimate   BIGINT,                     -- HLL, APPROX_COUNT_DISTINCT
    null_fraction       NUMERIC(6,5),
    avg_length          NUMERIC(10,2),              -- for free-text fencing
    -- Stage 0 verdicts
    is_eligible         BOOLEAN NOT NULL DEFAULT FALSE,
    exclusion_reason    TEXT,                       -- 'type_fence'|'null_fence'|'enum_fence'|'freetext_fence'|'constant'
    tier                TEXT,                       -- 'STANDARD' | 'MEGA' | 'EXCLUDED'
    -- key-likelihood boosts from metadata signals
    is_partition_key    BOOLEAN DEFAULT FALSE,
    is_clustering_key   BOOLEAN DEFAULT FALSE,
    name_tokens         TEXT[],                     -- tokenized snake/camel case
    updated_at          TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_fqn, column_name)
);
CREATE INDEX IF NOT EXISTS idx_col_eligible ON column_registry(is_eligible) WHERE is_eligible;
CREATE INDEX IF NOT EXISTS idx_col_tier ON column_registry(tier);
CREATE INDEX IF NOT EXISTS idx_col_table ON column_registry(table_id);

-- ----------------------------------------------------------------------------
-- 3. SKETCH CACHE — k-permutation MinHash arrays (STANDARD tier only)
--    Generated in BigQuery via MIN(FARM_FINGERPRINT(CONCAT(seed, val))),
--    sort-free, riding along with the profiling scan in byte-budgeted batches.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sketch_cache (
    sketch_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    column_id           UUID NOT NULL REFERENCES column_registry(column_id),
    table_fqn           TEXT NOT NULL,
    column_name         TEXT NOT NULL,
    -- FROZEN sketch identity: sketches are comparable IFF these match.
    seed_version        TEXT NOT NULL,              -- e.g. 'v1' -> canonical seed list
    num_perm            INTEGER NOT NULL,           -- e.g. 128
    normalization       TEXT NOT NULL DEFAULT 'cast_string_v1',  -- canonical CAST rule
    sketch_scope        TEXT NOT NULL DEFAULT 'full',            -- 'full'|'last_90d'|...
    signature           BIGINT[] NOT NULL,          -- the K MIN values
    built_against_fingerprint TEXT,
    built_at            TIMESTAMPTZ DEFAULT now(),
    UNIQUE (column_id, seed_version, num_perm, sketch_scope)
);
CREATE INDEX IF NOT EXISTS idx_sketch_col ON sketch_cache(column_id);

-- ----------------------------------------------------------------------------
-- 4. SKETCH BATCHES — byte-budgeted batch FSM (idempotent partial-failure safe)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS sketch_batches (
    batch_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_id            UUID NOT NULL REFERENCES table_registry(table_id),
    table_fqn           TEXT NOT NULL,
    column_ids          UUID[] NOT NULL,
    sql_bytes           INTEGER,                    -- generated SQL size (10MB guard)
    status              TEXT NOT NULL DEFAULT 'QUEUED',
    -- QUEUED -> RUNNING -> DONE | FAILED (retry) | DEAD
    attempt_count       INTEGER DEFAULT 0,
    max_attempts        INTEGER DEFAULT 3,
    last_error          TEXT,
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_sb_status ON sketch_batches(status) WHERE status='QUEUED';

-- ----------------------------------------------------------------------------
-- 5. LSH BAND INDEX — the incremental global comparison structure.
--    Insert-only: new sketches hash into existing bands; only NEW collisions
--    are emitted. The world is never re-banded.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS lsh_bands (
    band_index          INTEGER NOT NULL,           -- 0..bands-1
    band_hash           TEXT NOT NULL,              -- hash of the band's rows
    column_id           UUID NOT NULL REFERENCES column_registry(column_id),
    seed_version        TEXT NOT NULL,
    inserted_at         TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (band_index, band_hash, column_id)
);
CREATE INDEX IF NOT EXISTS idx_lsh_lookup ON lsh_bands(band_index, band_hash);

-- ----------------------------------------------------------------------------
-- 6. WORK QUEUE — pair-level candidates, lane-routed, lifecycle-gated
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS discovery_work_queue (
    work_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    item_type           TEXT NOT NULL DEFAULT 'UNARY_PAIR',
    -- 'UNARY_PAIR' | 'COMPOSITE_PAIR' | 'PROBE_BATCH'
    -- canonical ordering: table_a_fqn < table_b_fqn
    table_a_fqn         TEXT NOT NULL,
    table_b_fqn         TEXT NOT NULL,
    a_columns           TEXT[] NOT NULL,            -- arrays: composite-ready
    b_columns           TEXT[] NOT NULL,
    is_composite        BOOLEAN DEFAULT FALSE,

    -- LANE ROUTING (ratio-primary rule, Stage 3 output)
    discovery_lane      TEXT NOT NULL,              -- 'LSH' | 'CONTAINMENT'
    cardinality_ratio   NUMERIC(12,4),              -- dc_large / dc_small at routing time
    probe_direction     TEXT,                       -- 'a_in_b'|'b_in_a'|'both' (cardinality-gated)

    -- FSM + lifecycle (identical semantics to v1)
    status              TEXT NOT NULL DEFAULT 'QUEUED',
    -- QUEUED -> CLAIMED -> PROBING -> SCORING -> DONE | FAILED | DEAD | SKIPPED
    lifecycle_state     TEXT NOT NULL DEFAULT 'CANDIDATE',
    -- CANDIDATE | CONFIRMED | REJECTED | MONITORING | DEGRADED

    -- priority: audit evidence + name prior + metadata boosts.
    -- NAME PRIOR ORDERS THE QUEUE; IT NEVER VETOES (no name-based exclusion).
    priority_score      NUMERIC(12,4) NOT NULL DEFAULT 0,
    priority_signals    JSONB DEFAULT '{}'::jsonb,
    trigger_source      TEXT,   -- 'audit_bootstrap'|'cold_lsh'|'cold_name'|'mega_enum'
                                 -- |'composite_settlement'|'nomination'|'drift'
    triggered_by        TEXT DEFAULT 'system',

    -- incrementality gates
    a_fingerprint_at_eval TEXT,
    b_fingerprint_at_eval TEXT,

    attempt_count       INTEGER DEFAULT 0,
    max_attempts        INTEGER DEFAULT 3,
    claimed_by_run      UUID,
    claimed_at          TIMESTAMPTZ,
    last_error          TEXT,
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_a_fqn, table_b_fqn, a_columns, b_columns)
);
CREATE INDEX IF NOT EXISTS idx_wq_claim
    ON discovery_work_queue(status, priority_score DESC) WHERE status='QUEUED';
CREATE INDEX IF NOT EXISTS idx_wq_lane ON discovery_work_queue(discovery_lane);
CREATE INDEX IF NOT EXISTS idx_wq_type ON discovery_work_queue(item_type);

-- ----------------------------------------------------------------------------
-- 7. PROBE BATCHES — containment probes grouped by SHARED CHILD TABLE so one
--    scan serves N probes. Batch granularity = retry economics.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS probe_batches (
    batch_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    child_table_fqn     TEXT NOT NULL,              -- the table scanned once
    work_ids            UUID[] NOT NULL,            -- probes riding this scan
    sql_bytes           INTEGER,
    status              TEXT NOT NULL DEFAULT 'QUEUED',
    attempt_count       INTEGER DEFAULT 0,
    max_attempts        INTEGER DEFAULT 3,
    last_error          TEXT,
    created_at          TIMESTAMPTZ DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_pb_status ON probe_batches(status) WHERE status='QUEUED';
CREATE INDEX IF NOT EXISTS idx_pb_child ON probe_batches(child_table_fqn);

-- ----------------------------------------------------------------------------
-- 8. RELATIONSHIP EDGES — output, with the GATED confidence decomposition.
--    Steward sees the BAND + the two-axis decomposition, not a bare float.
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS relationship_edges (
    edge_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    work_id             UUID REFERENCES discovery_work_queue(work_id),
    table_a_fqn         TEXT NOT NULL,
    table_b_fqn         TEXT NOT NULL,
    a_columns           TEXT[] NOT NULL,
    b_columns           TEXT[] NOT NULL,
    is_composite        BOOLEAN DEFAULT FALSE,

    -- AXIS 1: mathematical existence (the gate)
    containment_a_in_b  NUMERIC(6,5),
    containment_b_in_a  NUMERIC(6,5),
    ind_direction       TEXT,                       -- FK arrow
    jaccard_estimate    NUMERIC(6,5),               -- LSH lane only; NULL for containment lane
    cardinality_ratio   NUMERIC(12,4),
    passed_existence_gate BOOLEAN NOT NULL,

    -- AXIS 2: semantic meaning (bounded modulation; renormalizing blend)
    name_similarity     NUMERIC(6,5),
    vocab_agreement     NUMERIC(6,5),
    llm_semantic_score  NUMERIC(6,5),               -- NULL until Phase 2; blend renormalizes
    semantic_blend      NUMERIC(6,5),

    -- combined: base(math) x (1 + alpha*(semantic - 0.5)), gated
    base_confidence     NUMERIC(6,5),
    final_confidence    NUMERIC(6,5),
    confidence_band     TEXT,
    -- 'STRONG_FK' | 'STRUCTURAL_NAME_MISMATCH' | 'COINCIDENTAL_OVERLAP'
    -- | 'SEMANTIC_ONLY_SUSPECT' | 'WEAK'
    finding_class       TEXT,                       -- e.g. 'SCHEMA_DRIFT_SUSPECT' for
                                                    -- audit composites whose components failed

    -- epistemology + provenance
    relationship_source TEXT NOT NULL DEFAULT 'INFERRED',   -- 'DECLARED'|'INFERRED'
    declared_constraint_name TEXT,
    discovery_lane      TEXT,
    evidence            JSONB DEFAULT '{}'::jsonb,  -- audit query counts, lineage refs

    -- steward verdict
    human_verdict       TEXT,                       -- 'confirmed'|'rejected'|'deferred'
    reviewed_by         TEXT,
    reviewed_at         TIMESTAMPTZ,

    discovery_run_id    UUID,
    created_at          TIMESTAMPTZ DEFAULT now(),
    updated_at          TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_a_fqn, table_b_fqn, a_columns, b_columns)
);
CREATE INDEX IF NOT EXISTS idx_edge_band ON relationship_edges(confidence_band);
CREATE INDEX IF NOT EXISTS idx_edge_conf ON relationship_edges(final_confidence DESC);
CREATE INDEX IF NOT EXISTS idx_edge_verdict ON relationship_edges(human_verdict);

-- ----------------------------------------------------------------------------
-- 9. AUDIT SIGNALS — parsed join evidence (unary seeds now; composites HELD
--    for the composite phase, released only when component unary INDs settle)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_signals (
    signal_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_a_fqn         TEXT NOT NULL,
    table_b_fqn         TEXT NOT NULL,
    a_columns           TEXT[] NOT NULL,
    b_columns           TEXT[] NOT NULL,
    is_composite        BOOLEAN NOT NULL,
    query_count         INTEGER NOT NULL,
    sources             TEXT[],                     -- 'explicit_join'|'implicit_where'
    lookback_days       INTEGER,
    -- composite lifecycle: held until unary components settle
    composite_release_state TEXT DEFAULT 'N/A',
    -- 'N/A' (unary) | 'HELD' | 'RELEASED' | 'DRIFT_SUSPECT' (components failed IND)
    harvested_at        TIMESTAMPTZ DEFAULT now(),
    UNIQUE (table_a_fqn, table_b_fqn, a_columns, b_columns)
);
CREATE INDEX IF NOT EXISTS idx_aud_held ON audit_signals(composite_release_state)
    WHERE composite_release_state = 'HELD';

-- ----------------------------------------------------------------------------
-- 10. DISCOVERY RUNS — batch bookkeeping (unchanged semantics from v1)
-- ----------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS discovery_runs (
    run_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_type            TEXT NOT NULL,
    scope_budget        INTEGER NOT NULL,
    pairs_claimed       INTEGER DEFAULT 0,
    pairs_completed     INTEGER DEFAULT 0,
    pairs_failed        INTEGER DEFAULT 0,
    status              TEXT NOT NULL DEFAULT 'PENDING',
    started_at          TIMESTAMPTZ DEFAULT now(),
    finished_at         TIMESTAMPTZ,
    created_by          TEXT
);

-- ----------------------------------------------------------------------------
-- 11. RUNNABLE VIEW — the incrementality rules in one place
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_runnable_work AS
SELECT wq.*
FROM discovery_work_queue wq
LEFT JOIN table_registry ta ON ta.table_fqn = wq.table_a_fqn
LEFT JOIN table_registry tb ON tb.table_fqn = wq.table_b_fqn
WHERE wq.status = 'QUEUED'
  AND wq.attempt_count < wq.max_attempts
  AND (
        wq.lifecycle_state = 'CANDIDATE'
     OR (wq.lifecycle_state IN ('CONFIRMED','MONITORING','REJECTED','DEGRADED')
         AND (ta.data_fingerprint IS DISTINCT FROM wq.a_fingerprint_at_eval
           OR tb.data_fingerprint IS DISTINCT FROM wq.b_fingerprint_at_eval))
      );

-- ----------------------------------------------------------------------------
-- 12. COMPOSITE TRIGGER VIEW — table pairs whose unary edge set qualifies them
--     for the composite phase: >=2 same-direction settled unary edges.
-- ----------------------------------------------------------------------------
CREATE OR REPLACE VIEW v_composite_candidates AS
SELECT
    table_a_fqn, table_b_fqn, ind_direction,
    COUNT(*)                    AS parallel_unary_edges,
    ARRAY_AGG(a_columns[1])     AS a_cols,
    ARRAY_AGG(b_columns[1])     AS b_cols
FROM relationship_edges
WHERE is_composite = FALSE
  AND passed_existence_gate
  AND (final_confidence >= 0.80 OR human_verdict = 'confirmed')
  AND ind_direction IN ('a_in_b','b_in_a')
GROUP BY table_a_fqn, table_b_fqn, ind_direction
HAVING COUNT(*) >= 2;
