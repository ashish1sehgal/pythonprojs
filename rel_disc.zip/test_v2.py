"""
V2 validation: fence + ratio router, SQL generators (byte budgets, frozen
seeds, probe batching), gated confidence model, and the six-stage flow
including composite settlement and the SCHEMA_DRIFT_SUSPECT finding.
"""
import sys, random
sys.path.insert(0, "/home/claude/reldiscovery")
random.seed(7)

print("="*76)
print("SECTION A — STAGE 0: FENCE + TIER + RATIO-PRIMARY LANE ROUTER")
print("="*76)
from discovery.tier_router import (ColumnFacts, fence_column, route_pair,
                                   RouterConfig, name_prior)

cases = [
    ColumnFacts("t","amount","FLOAT64", 500000, 0.01, None, 1_000_000),
    ColumnFacts("t","is_active","BOOL", 2, 0.0, None, 1_000_000),
    ColumnFacts("t","tags","ARRAY<STRING>", None, None, None, 1_000_000),
    ColumnFacts("t","status_flag","STRING", 3, 0.0, 6, 1_000_000),
    ColumnFacts("t","comments","STRING", 900_000, 0.1, 240.0, 1_000_000),
    ColumnFacts("t","customer_id","INT64", 250_000, 0.001, None, 1_000_000),
    ColumnFacts("t","txn_uuid","STRING", 48_000_000, 0.0, 36.0, 50_000_000),
    ColumnFacts("t","mostly_null","STRING", 100, 0.97, 10.0, 1_000_000),
]
for c in cases:
    v = fence_column(c)
    print(f"  {c.column_name:14} {c.data_type:14} -> eligible={v.eligible!s:5} "
          f"tier={v.tier:8} reason={v.reason}")

print("\n  Ratio-primary routing (t_LSH=0.30 => ratio bound ~3.33):")
tests = [
    ("peer dims",        6_000,     5_000,   "STANDARD","STANDARD"),
    ("fact->dim FK",     50_000_000,250_000, "STANDARD","STANDARD"),
    ("mega x mega",      48_000_000,15_000_000,"MEGA","MEGA"),
    ("lookup vs fact",   8,         5_000_000,"STANDARD","STANDARD"),
]
for label, da, db, ta, tb in tests:
    d = route_pair(da, db, ta, tb)
    print(f"  {label:16} dc=({da:>10,},{db:>10,}) -> {d.lane:12} "
          f"ratio={d.cardinality_ratio:>10.1f} dir={d.probe_direction:7} ({d.reason[:48]})")

# the crown-jewel check: perfect FK with ratio 200 must be CONTAINMENT lane
d = route_pair(50_000_000, 250_000, "STANDARD", "STANDARD")
assert d.lane == "CONTAINMENT", "asymmetric FK must route around LSH"
print("\n  ✓ asymmetric fact->dim FK routes to CONTAINMENT (Jaccard trap avoided)")

print("\n" + "="*76)
print("SECTION B — SQL GENERATORS: frozen seeds, byte budget, probe batching")
print("="*76)
from discovery.bq_sqlgen import (pack_sketch_batches, generate_sketch_sql,
                                 pack_probe_batches, ProbeSpec, SEED_VERSIONS)

# byte-budget packer on a wide table
wide_cols = [f"very_long_column_name_number_{i:04d}" for i in range(600)]
batches = pack_sketch_batches("proj.ds.wide_table", wide_cols,
                              byte_budget=2_000_000)
print(f"  600 columns x 128 seeds -> {len(batches)} batches under 2MB budget")
for b in batches[:3]:
    print(f"    batch: {len(b.columns):3d} cols, sql={b.sql_bytes/1e6:.2f} MB")
assert all(b.sql_bytes <= 2_000_000 for b in batches), "byte budget violated"
assert sum(len(b.columns) for b in batches) == 600, "column loss in packing"
print("  ✓ every batch under budget; no column lost")

sample_sql = generate_sketch_sql("proj.ds.t", ["customer_id"])
assert "MIN(FARM_FINGERPRINT(CONCAT('s000'" in sample_sql
assert "ORDER BY" not in sample_sql and "DISTINCT" not in sample_sql
print("  ✓ sketch SQL is MIN-based: no ORDER BY, no DISTINCT (sort-free)")

# probe batching by shared child table
specs = [ProbeSpec(f"w{i}", "proj.ds.fact_sales", [c], f"proj.ds.dim_{c}", [c])
         for i, c in enumerate(["customer_id","product_id","store_id"])]
specs.append(ProbeSpec("w9", "proj.ds.fact_web", ["user_id"],
                       "proj.ds.dim_user", ["user_id"]))
pbatches = pack_probe_batches(specs)
print(f"\n  4 probes over 2 child tables -> {len(pbatches)} batches "
      f"(grouped by shared child scan)")
sql0 = pbatches[0][1]
assert sql0.count("FROM `proj.ds.fact_sales`") == 3   # 3 CTEs, but 1 logical scan pattern
assert "COUNT(DISTINCT" not in sql0, "COUNT(DISTINCT) must never appear"
assert "MOD(ABS(FARM_FINGERPRINT" in sql0, "hash-mod sampling required"
assert "TABLESAMPLE" not in sql0 and "RAND()" not in sql0
print("  ✓ probe SQL: value-domain + hash-mod sample, no COUNT(DISTINCT), "
      "no TABLESAMPLE/RAND")

print("\n" + "="*76)
print("SECTION C — GATED CONFIDENCE MODEL (existence gate + bounded modulation)")
print("="*76)
from discovery.confidence import rate

rows = [
    ("perfect FK, same names",      0.99, 0.02, 200.0, 250_000, 0.95, 0.9),
    ("perfect FK, RENAMED cols",    0.98, 0.01, 200.0, 250_000, 0.05, 0.0),
    ("names match, data doesn't",   0.03, 0.01, 1.2,   500,     0.95, 0.9),
    ("tiny shared code space",      0.99, 0.97, 1.1,   40,      0.10, 0.0),
    ("below gate, low name",        0.40, 0.10, 5.0,   10_000,  0.20, 0.1),
]
print(f"  {'case':28} {'cont':>5} {'sem':>5} {'final':>6}  band")
for label, ab, ba, ratio, dcs, nm, vb in rows:
    r = rate(ab, ba, ratio, dcs, nm, vb, llm_score=None)
    print(f"  {label:28} {r.containment:5.2f} {r.semantic_blend:5.2f} "
          f"{r.final_confidence:6.3f}  {r.band}")

r_named   = rate(0.99, 0.02, 200.0, 250_000, 0.95, 0.9)
r_renamed = rate(0.98, 0.01, 200.0, 250_000, 0.05, 0.0)
r_semonly = rate(0.03, 0.01, 1.2, 500, 0.95, 0.9)
assert r_named.band == "STRONG_FK"
assert r_renamed.band == "STRUCTURAL_NAME_MISMATCH"
assert r_renamed.passed_existence_gate, "renamed FK must pass the gate"
assert r_semonly.band == "SEMANTIC_ONLY_SUSPECT"
assert not r_semonly.passed_existence_gate
assert r_semonly.final_confidence <= 0.30, "semantics must not manufacture confidence"
print("\n  ✓ name match cannot rescue non-existent data relationship")
print("  ✓ renamed FK (high containment, low name) surfaces as its own band")

# LLM-socket degradation invariance: adding llm score must not move bands wildly
r_no_llm  = rate(0.97, 0.05, 50.0, 100_000, 0.8, 0.7, llm_score=None)
r_llm     = rate(0.97, 0.05, 50.0, 100_000, 0.8, 0.7, llm_score=0.85)
print(f"  Phase-1 (no LLM): {r_no_llm.final_confidence:.3f} {r_no_llm.band}")
print(f"  Phase-2 (+LLM)  : {r_llm.final_confidence:.3f} {r_llm.band}")
assert r_no_llm.band == r_llm.band, "LLM arrival must not shift the band"
print("  ✓ renormalizing blend: LLM sharpens, doesn't shift bands")

print("\n" + "="*76)
print("SECTION D — SIX-STAGE FLOW incl. composite settlement + drift finding")
print("="*76)
from discovery.drivers import MockComputeDriver, MockSketchDriver, _FakeColumn
from discovery.work_queue import InMemoryQueueStore
from discovery.pipeline_v2 import PipelineV2, PipelineV2Config

# enterprise: orders/order_lines carry a composite (order_id, fiscal_year);
# plus a lookup (currency) never joined in audit
N_ORD, N_LINE = 4000, 12000
order_ids = list(range(1, N_ORD+1))
fys = [2023, 2024, 2025]
ord_fy = [random.choice(fys) for _ in range(N_ORD)]
li = [random.randrange(N_ORD) for _ in range(N_LINE)]
currs = ["USD","EUR","GBP","JPY","INR","CAD","AUD","CHF","CNY","BRL","MXN"]

tables = {
    "p.s.fact_orders": {
        "order_id": _FakeColumn(order_ids),
        "fiscal_year": _FakeColumn(ord_fy),
        "currency_code": _FakeColumn([random.choice(currs) for _ in range(N_ORD)], "STRING"),
    },
    "p.s.fact_order_lines": {
        "line_id": _FakeColumn(list(range(1, N_LINE+1))),
        "order_id": _FakeColumn([order_ids[i] for i in li]),
        "fiscal_year": _FakeColumn([ord_fy[i] for i in li]),
    },
    "p.r.dim_currency": {
        "currency_code": _FakeColumn(currs, "STRING"),
        "currency_name": _FakeColumn([f"c{i}" for i in range(len(currs))], "STRING"),
    },
}
audit = [
    # composite join used 90x -> composite HELD + unary components seeded
    {"query": """SELECT * FROM `p.s.fact_orders` o
                 JOIN `p.s.fact_order_lines` l
                   ON o.order_id=l.order_id AND o.fiscal_year=l.fiscal_year""",
     "query_count": 90},
]

compute = MockComputeDriver(tables, audit)
sketch  = MockSketchDriver(compute)
store   = InMemoryQueueStore()
pipe    = PipelineV2(store, compute, sketch, PipelineV2Config())

# Stage 0: facts from the mock tables
facts = []
for fqn, cols in tables.items():
    n = max(len(c.values) for c in cols.values())
    for cname, col in cols.items():
        nn = [v for v in col.values if v is not None]
        facts.append(ColumnFacts(fqn, cname, col.dtype,
                                 len(set(nn)), 1-len(nn)/max(n,1), None, n))
s0 = pipe.stage0_fence_universe(facts)
print(f"  S0 fence: {s0['eligible']}/{s0['total']} eligible, tiers={s0['by_tier']}")

s1 = pipe.stage1_bootstrap(audit)
print(f"  S1 bootstrap: unary={s1['unary_seeded']} held_composites={s1['composites_held']}")
assert s1["composites_held"] == 1, "composite join must be HELD, not scored yet"

s3 = pipe.stage3_cold_routing()
print(f"  S3 cold routing: {s3['cold_candidates']} candidates, lanes={s3['lane_split']}")

s4 = pipe.stage4_evaluate(budget=30)
print(f"  S4 evaluate: claimed={s4['claimed']} edges={s4['edges']}")
for e in sorted(s4["results"], key=lambda x: -x.final_confidence):
    pair = f"{e.table_a_fqn.split('.')[-1]}.{e.a_columns[0]}<->{e.table_b_fqn.split('.')[-1]}.{e.b_columns[0]}"
    print(f"    {pair:52} lane={e.discovery_lane:11} conf={e.final_confidence:.2f} {e.confidence_band}")

s6 = pipe.stage6_composites(s4["results"],
                            clustering={"p.s.fact_order_lines": ["order_id","fiscal_year"]})
print(f"  S6 composites: pairs_triggered={s6['pairs_triggered']} "
      f"candidates={s6['composite_candidates']} drift_suspects={s6['drift_suspects']}")
assert s6["composite_candidates"] >= 1, "settlement must trigger composite candidates"

# evaluate the composite candidates
s4b = pipe.stage4_evaluate(budget=30)
comp_edges = [e for e in s4b["results"] if e.is_composite]
print(f"  S4(composites): {len(comp_edges)} composite edge(s) scored:")
for e in comp_edges:
    print(f"    {e.table_a_fqn.split('.')[-1]}{list(e.a_columns)} <-> "
          f"{e.table_b_fqn.split('.')[-1]}{list(e.b_columns)}: "
          f"conf={e.final_confidence:.2f} {e.confidence_band}")
assert any(e.passed_existence_gate for e in comp_edges), \
    "the true composite (order_id,fiscal_year) must validate"

print("\n" + "="*76)
print("ALL V2 SECTIONS PASS — fence, router, sqlgen, confidence, 6-stage flow")
print("="*76)
