"""
bq_sqlgen.py
============
Programmatic BigQuery SQL generation for the two pushdown workloads.
Everything here is deliberately a *generator* (SQL text out), separated from
execution, so it is unit-testable without BigQuery and byte-budget enforcement
is exact (we measure the actual SQL we will send).

1. SKETCH BATCHES — k-permutation MinHash via MIN(FARM_FINGERPRINT(CONCAT(...)))
   * sort-free, DISTINCT-free (MIN over dup values == MIN over distinct set)
   * seeds FROZEN via seed_version -> canonical list; generated, never typed
   * canonical normalization baked into the cast expression
   * NULL semantics: CONCAT with NULL -> NULL, MIN skips NULLs (correct);
     all-NULL column yields NULL mins -> caller records empty sketch
   * byte-budget packer: batches sized by measured SQL bytes, not column count

2. CONTAINMENT PROBE BATCHES — the "Bloom lane" as pure BQ SQL semi-joins
   (no literal Bloom filter: BQ's join engine IS an exact distributed
   semi-join; a probabilistic structure inside it would be strictly worse).
   * probes the DISTINCT VALUE DOMAIN, not rows (IND is a set question;
     row-wise EXISTS weights by frequency and one hot orphan poisons it)
   * deterministic hash-mod sampling (reproducible across runs -> conformance
     monitoring can compare over time); never TABLESAMPLE (block-biased),
     never RAND()
   * batches grouped by SHARED CHILD TABLE: one scan serves N probes
   * no COUNT(DISTINCT) anywhere (the 3.5-hour global sort trap)
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Frozen seeds
# ---------------------------------------------------------------------------
SEED_VERSIONS: dict[str, list[str]] = {
    # NEVER edit an existing version's list — add v2 and re-sketch if the
    # permutation family must change. Sketches across versions are
    # incomparable and the cache enforces the version key.
    "v1": [f"s{i:03d}" for i in range(128)],
}


def canonical_cast(column: str, normalization: str = "cast_string_v1") -> str:
    """The ONE normalization rule, shared by sketches and probes. Two columns
    are comparable only if sketched/probed under the same normalization.
    v1: trim + cast to string; numeric-looking strings are NOT unpadded (keep
    v1 simple; introduce cast_string_v2 if zero-padding mismatches surface)."""
    if normalization == "cast_string_v1":
        return f"TRIM(CAST(`{column}` AS STRING))"
    raise ValueError(f"unknown normalization {normalization}")


# ---------------------------------------------------------------------------
# 1. Sketch batch SQL
# ---------------------------------------------------------------------------
@dataclass
class SketchBatch:
    table_fqn: str
    columns: list[str]
    sql: str
    sql_bytes: int
    seed_version: str
    num_perm: int


def _sketch_exprs(column: str, seeds: list[str], normalization: str) -> list[str]:
    cast = canonical_cast(column, normalization)
    return [
        f"MIN(FARM_FINGERPRINT(CONCAT('{seed}', {cast})))"
        for seed in seeds
    ]


def generate_sketch_sql(table_fqn: str, columns: list[str],
                        seed_version: str = "v1",
                        normalization: str = "cast_string_v1",
                        partition_filter: str | None = None) -> str:
    """One query, one scan, all columns' sketches. Emits one ARRAY per column.
    partition_filter e.g. \"_PARTITIONDATE >= DATE_SUB(CURRENT_DATE(), INTERVAL 90 DAY)\"
    for partition-scoped sketching of huge facts (never TABLESAMPLE)."""
    seeds = SEED_VERSIONS[seed_version]
    selects = []
    for col in columns:
        exprs = ",\n      ".join(_sketch_exprs(col, seeds, normalization))
        selects.append(f"  [\n      {exprs}\n  ] AS sk_{_safe(col)}")
    where = f"\nWHERE {partition_filter}" if partition_filter else ""
    return (f"SELECT\n" + ",\n".join(selects) +
            f"\nFROM `{table_fqn}`{where}")


def _safe(col: str) -> str:
    return "".join(c if c.isalnum() else "_" for c in col)


def pack_sketch_batches(table_fqn: str, columns: list[str],
                        seed_version: str = "v1",
                        normalization: str = "cast_string_v1",
                        partition_filter: str | None = None,
                        byte_budget: int = 8_000_000) -> list[SketchBatch]:
    """
    Byte-budgeted greedy packer. Batch limit computed from MEASURED SQL bytes
    (long column names / STRUCT paths consume more), not a fixed column count.
    8MB default leaves headroom under BQ's 10MB interactive limit.
    """
    seeds = SEED_VERSIONS[seed_version]
    batches: list[SketchBatch] = []
    current: list[str] = []

    def flush():
        if not current:
            return
        sql = generate_sketch_sql(table_fqn, current, seed_version,
                                  normalization, partition_filter)
        batches.append(SketchBatch(table_fqn, list(current), sql,
                                   len(sql.encode()), seed_version, len(seeds)))
        current.clear()

    for col in columns:
        trial = current + [col]
        sql = generate_sketch_sql(table_fqn, trial, seed_version,
                                  normalization, partition_filter)
        if len(sql.encode()) > byte_budget and current:
            flush()
            current.append(col)
        else:
            current.append(col)
    flush()
    return batches


# ---------------------------------------------------------------------------
# 2. Containment probe batch SQL
# ---------------------------------------------------------------------------
@dataclass
class ProbeSpec:
    """One directional containment question: child_col ⊆ parent_col ?
    For composites, columns are lists and the projection CONCAT is used."""
    work_id: str
    child_table_fqn: str
    child_columns: list[str]
    parent_table_fqn: str
    parent_columns: list[str]
    sample_mod: int = 100           # hash-mod denominator: 100 => ~1% of values
    is_composite: bool = False


def _proj(cols: list[str], normalization: str) -> str:
    """Order-independent composite projection (sorted, name-prefixed) or the
    single-column canonical cast."""
    if len(cols) == 1:
        return canonical_cast(cols[0], normalization)
    parts = ", '||', ".join(
        f"'{c}=', {canonical_cast(c, normalization)}" for c in sorted(cols))
    return f"CONCAT({parts})"


def _not_null(cols: list[str]) -> str:
    return " AND ".join(f"`{c}` IS NOT NULL" for c in cols)


def generate_probe_sql(specs: list[ProbeSpec],
                       normalization: str = "cast_string_v1") -> str:
    """
    All specs MUST share the same child_table_fqn — the packer guarantees it.
    Shape: one CTE reading the child table ONCE (only referenced columns, so
    BQ's columnar scan bills only those), a hash-sampled DISTINCT value-domain
    CTE per probe, a full DISTINCT domain CTE per parent, then small
    LEFT-JOIN result sets UNION ALL'ed. No COUNT(DISTINCT) aggregates; the
    DISTINCT-in-CTE dedupe feeding a join is the cheap form, and the sampled
    child set is tiny by construction.
    """
    child = specs[0].child_table_fqn
    assert all(s.child_table_fqn == child for s in specs), \
        "probe batch must share one child table"

    ctes = []
    unions = []
    for i, s in enumerate(specs):
        ck = _proj(s.child_columns, normalization)
        pk = _proj(s.parent_columns, normalization)
        ctes.append(
            f"c{i} AS (\n"
            f"  SELECT DISTINCT {ck} AS k\n"
            f"  FROM `{child}`\n"
            f"  WHERE {_not_null(s.child_columns)}\n"
            f"    AND MOD(ABS(FARM_FINGERPRINT({ck})), {s.sample_mod}) = 0\n"
            f")")
        ctes.append(
            f"p{i} AS (\n"
            f"  SELECT DISTINCT {pk} AS k\n"
            f"  FROM `{s.parent_table_fqn}`\n"
            f"  WHERE {_not_null(s.parent_columns)}\n"
            f")")
        unions.append(
            f"SELECT '{s.work_id}' AS work_id,\n"
            f"       COUNT(*) AS sampled_child_values,\n"
            f"       COUNTIF(p{i}.k IS NOT NULL) AS contained_values,\n"
            f"       SAFE_DIVIDE(COUNTIF(p{i}.k IS NOT NULL), COUNT(*)) AS containment\n"
            f"FROM c{i} LEFT JOIN p{i} USING (k)")

    return "WITH\n" + ",\n".join(ctes) + "\n" + "\nUNION ALL\n".join(unions)


def pack_probe_batches(specs: list[ProbeSpec],
                       normalization: str = "cast_string_v1",
                       byte_budget: int = 8_000_000,
                       max_probes_per_batch: int = 20) -> list[tuple[list[ProbeSpec], str]]:
    """
    Group by shared child table (one scan serves N probes), then byte-budget
    within the group. max_probes_per_batch bounds retry economics: one failed
    branch re-bills the whole batch, so don't make batches enormous.
    Returns [(specs_in_batch, sql), ...].
    """
    from collections import defaultdict
    by_child: dict[str, list[ProbeSpec]] = defaultdict(list)
    for s in specs:
        by_child[s.child_table_fqn].append(s)

    out: list[tuple[list[ProbeSpec], str]] = []
    for child, group in by_child.items():
        current: list[ProbeSpec] = []

        def flush():
            if not current:
                return
            sql = generate_probe_sql(current, normalization)
            out.append((list(current), sql))
            current.clear()

        for s in group:
            trial = current + [s]
            sql = generate_probe_sql(trial, normalization)
            if (len(sql.encode()) > byte_budget or
                    len(trial) > max_probes_per_batch) and current:
                flush()
                current.append(s)
            else:
                current.append(s)
        flush()
    return out


# ---------------------------------------------------------------------------
# 3. Stage-0 / Stage-1 harvest SQL (metadata + audit; no data scans)
# ---------------------------------------------------------------------------
UNIVERSE_SQL = """
-- Stage 0: the column universe with type + storage metadata (no data scan)
SELECT
  c.table_schema, c.table_name, c.column_name, c.data_type,
  t.row_count, t.size_bytes,
  tp.partition_column, tp.clustering_ordinal_position IS NOT NULL AS is_clustering
FROM `region-us`.INFORMATION_SCHEMA.COLUMNS c
LEFT JOIN `region-us`.INFORMATION_SCHEMA.TABLE_STORAGE t
  USING (table_schema, table_name)
LEFT JOIN (
  SELECT table_schema, table_name, column_name AS partition_column,
         clustering_ordinal_position
  FROM `region-us`.INFORMATION_SCHEMA.COLUMNS
  WHERE is_partitioning_column = 'YES' OR clustering_ordinal_position IS NOT NULL
) tp USING (table_schema, table_name)
WHERE c.table_schema NOT IN ('INFORMATION_SCHEMA')
"""

AUDIT_SQL_TEMPLATE = """
-- Stage 1: audit-log join harvest. Org-wide first; per-project fallback.
SELECT query, COUNT(DISTINCT job_id) AS query_count
FROM `region-us`.INFORMATION_SCHEMA.JOBS_BY_ORGANIZATION
WHERE creation_time > TIMESTAMP_SUB(CURRENT_TIMESTAMP(), INTERVAL {lookback} DAY)
  AND job_type = 'QUERY' AND state = 'DONE' AND error_result IS NULL
  AND ARRAY_LENGTH(referenced_tables) BETWEEN 2 AND 10
  AND REGEXP_CONTAINS(LOWER(query), r'\\bjoin\\b|\\bwhere\\b')
GROUP BY query
HAVING query_count >= {min_count}
"""
