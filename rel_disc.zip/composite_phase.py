"""
composite_phase.py
==================
STAGE 6 — Composite relationship discovery. NEVER a global job.

The theorem that makes this tractable:
    If (A.x, A.y) ⊆ (B.u, B.v) holds as a composite IND, then A.x ⊆ B.u and
    A.y ⊆ B.v must EACH hold as unary INDs in the same direction.
Component-wise containment is a NECESSARY condition. Therefore the unary
relationship graph is the candidate index: composite candidates exist ONLY
between table pairs that already have >= 2 parallel same-direction unary
edges. In a 10K-table estate that is hundreds of pairs, not millions.

Trigger: settlement events — a pair's unary edge set reaches >= 2
same-direction edges that are scored above the confidence floor OR
steward-confirmed.

Candidate groupings within a triggered pair, in priority order:
  Tier 1  clustering-key co-membership (a multi-column clustering key is a
          declared composite-key hypothesis)
  Tier 2  audit-log composite joins (HELD in audit_signals until their
          component unary edges settle; released here). If components FAILED
          the unary IND, the held composite is marked DRIFT_SUSPECT and
          surfaced as a finding, not scored.
  Tier 3  unary-edge subsets, smallest-first (k=2 then 3), bounded by a
          per-pair combination budget.

Verification is CONTAINMENT-lane by construction (composite keys are
high-cardinality and parent-child asymmetric — the population Jaccard/LSH
mishandles). Gates before the probe:
  (a) uniqueness gate — parent's projected key must be ~unique (HLL on the
      projection ≈ parent rows), else it's not a key at all
  (b) cardinality gate — child projected distinct <= parent projected distinct
Then the directional probe on the sorted, name-prefixed CONCAT projection.
"""

from __future__ import annotations

import itertools
import logging
from dataclasses import dataclass, field

logger = logging.getLogger(__name__)


@dataclass
class CompositeConfig:
    unary_confidence_floor: float = 0.80   # settled = scored >= this OR confirmed
    min_parallel_edges: int = 2
    max_width: int = 3                     # k=2, k=3; k>=4 is rare and explosive
    per_pair_combination_budget: int = 50  # hard cap on groupings per pair
    uniqueness_floor: float = 0.95         # projected parent key ~unique


@dataclass
class UnaryEdge:
    """Settled unary edge between one table pair (post Stage 4/5)."""
    a_column: str
    b_column: str
    direction: str            # 'a_in_b' | 'b_in_a'
    confidence: float
    confirmed: bool = False


@dataclass
class HeldAuditComposite:
    a_columns: tuple[str, ...]
    b_columns: tuple[str, ...]
    query_count: int


@dataclass
class CompositeCandidate:
    table_a_fqn: str
    table_b_fqn: str
    a_columns: tuple[str, ...]
    b_columns: tuple[str, ...]
    direction: str
    seed_tier: str            # 'clustering_key' | 'audit_composite' | 'unary_subset'
    priority_score: float
    finding_class: str | None = None      # 'SCHEMA_DRIFT_SUSPECT' when audit
                                          # composite's components failed


class CompositePhase:
    """
    Consumer of unary settlement events. Pure candidate generation — emits
    CompositeCandidates for the work queue; verification runs through the
    normal CONTAINMENT lane with the uniqueness/cardinality pre-gates.
    """

    def __init__(self, cfg: CompositeConfig | None = None):
        self.cfg = cfg or CompositeConfig()

    def generate(self,
                 table_a_fqn: str,
                 table_b_fqn: str,
                 settled_edges: list[UnaryEdge],
                 clustering_cols_a: list[str] | None = None,
                 clustering_cols_b: list[str] | None = None,
                 held_audit: list[HeldAuditComposite] | None = None,
                 ) -> list[CompositeCandidate]:
        cfg = self.cfg
        out: list[CompositeCandidate] = []

        # group settled edges by direction; each direction is independent
        by_dir: dict[str, list[UnaryEdge]] = {}
        for e in settled_edges:
            if e.confidence >= cfg.unary_confidence_floor or e.confirmed:
                by_dir.setdefault(e.direction, []).append(e)

        for direction, edges in by_dir.items():
            if len(edges) < cfg.min_parallel_edges:
                continue
            # column-mapping dict for this direction: a_col -> b_col
            mapping = {e.a_column: e.b_column for e in edges}
            emitted_keys: set[tuple] = set()

            # ---- Tier 1: clustering-key co-membership ----
            for cl_cols, side in ((clustering_cols_a or [], "a"),
                                  (clustering_cols_b or [], "b")):
                if len(cl_cols) < 2:
                    continue
                if side == "a":
                    members = [c for c in cl_cols if c in mapping]
                    if len(members) >= 2:
                        a_cols = tuple(sorted(members))
                        b_cols = tuple(mapping[c] for c in a_cols)
                        key = (a_cols, b_cols)
                        if key not in emitted_keys:
                            emitted_keys.add(key)
                            out.append(CompositeCandidate(
                                table_a_fqn, table_b_fqn, a_cols, b_cols,
                                direction, "clustering_key",
                                priority_score=100.0))
                else:
                    inv = {v: k for k, v in mapping.items()}
                    members = [c for c in cl_cols if c in inv]
                    if len(members) >= 2:
                        b_cols = tuple(sorted(members))
                        a_cols = tuple(inv[c] for c in b_cols)
                        key = (a_cols, b_cols)
                        if key not in emitted_keys:
                            emitted_keys.add(key)
                            out.append(CompositeCandidate(
                                table_a_fqn, table_b_fqn, a_cols, b_cols,
                                direction, "clustering_key",
                                priority_score=100.0))

            # ---- Tier 2: held audit composites (release or drift-flag) ----
            for h in (held_audit or []):
                pairs = list(zip(h.a_columns, h.b_columns))
                components_settled = all(
                    mapping.get(a) == b for a, b in pairs)
                a_cols = tuple(sorted(h.a_columns))
                # keep column alignment under the sort
                order = sorted(range(len(h.a_columns)),
                               key=lambda i: h.a_columns[i])
                b_cols = tuple(h.b_columns[i] for i in order)
                key = (a_cols, b_cols)
                if key in emitted_keys:
                    continue
                emitted_keys.add(key)
                if components_settled:
                    out.append(CompositeCandidate(
                        table_a_fqn, table_b_fqn, a_cols, b_cols, direction,
                        "audit_composite",
                        priority_score=80.0 + min(h.query_count, 200) * 0.1))
                else:
                    # audit says this composite join is used, but the unary
                    # data evidence failed => schema drift / dead relationship
                    out.append(CompositeCandidate(
                        table_a_fqn, table_b_fqn, a_cols, b_cols, direction,
                        "audit_composite", priority_score=40.0,
                        finding_class="SCHEMA_DRIFT_SUSPECT"))

            # ---- Tier 3: unary-edge subsets, smallest-first, budgeted ----
            budget = cfg.per_pair_combination_budget - len(out)
            a_cols_settled = sorted(mapping.keys())
            for k in range(2, min(cfg.max_width, len(a_cols_settled)) + 1):
                if budget <= 0:
                    break
                for combo in itertools.combinations(a_cols_settled, k):
                    if budget <= 0:
                        break
                    a_cols = tuple(combo)               # already sorted
                    b_cols = tuple(mapping[c] for c in a_cols)
                    key = (a_cols, b_cols)
                    if key in emitted_keys:
                        continue
                    emitted_keys.add(key)
                    out.append(CompositeCandidate(
                        table_a_fqn, table_b_fqn, a_cols, b_cols, direction,
                        "unary_subset", priority_score=20.0 - k))
                    budget -= 1

        return out
