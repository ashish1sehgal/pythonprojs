"""
pipeline_v2.py
==============
The six-stage orchestrator over the consolidated design.

  Stage 0  Universe & fence      [GLOBAL, metadata-only]     tier_router
  Stage 1  Bootstrap seeding     [GLOBAL, logs/catalogs]     audit parser + metadata
  Stage 2  Profile+sketch        [PER-TABLE, the only scans] bq_sqlgen sketch batches
  Stage 3  LSH banding + routing [GLOBAL over ~150MB]        incremental band index
  Stage 4  Pair evaluation       [PAIR-LOCAL, work queue]    containment probes
  Stage 5  Settlement            [steward + lifecycle]
  Stage 6  Composite phase       [PER-TABLE-PAIR]            composite_phase

Cost shape: dominated by Stage 2 (already paid for profiling); Stage 3 is
megabytes; Stage 4 is a budgeted queue; Stage 6 touches hundreds of pairs.
Nothing is O(N^2) over data.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field

from .tier_router import (ColumnFacts, FenceConfig, RouterConfig,
                          fence_column, route_pair, name_prior,
                          tokenize_column_name)
from .confidence import ConfidenceConfig, rate
from .audit_join_parser import parse_audit_rows
from .composite_phase import (CompositePhase, CompositeConfig, UnaryEdge,
                              HeldAuditComposite)
from .work_queue import QueueStore, WorkItem

logger = logging.getLogger(__name__)


@dataclass
class PipelineV2Config:
    fence: FenceConfig = field(default_factory=FenceConfig)
    router: RouterConfig = field(default_factory=RouterConfig)
    confidence: ConfidenceConfig = field(default_factory=ConfidenceConfig)
    composite: CompositeConfig = field(default_factory=CompositeConfig)
    lookback_days: int = 180
    min_audit_query_count: int = 5
    probe_sample_mod: int = 100          # ~1% of the distinct value domain


@dataclass
class EdgeV2:
    table_a_fqn: str
    table_b_fqn: str
    a_columns: tuple[str, ...]
    b_columns: tuple[str, ...]
    is_composite: bool
    discovery_lane: str
    containment_a_in_b: float
    containment_b_in_a: float
    cardinality_ratio: float
    # confidence decomposition
    passed_existence_gate: bool
    base_confidence: float
    semantic_blend: float
    final_confidence: float
    confidence_band: str
    ind_direction: str
    explanation: str
    finding_class: str | None = None
    work_id: str | None = None


class PipelineV2:
    """
    Framework-agnostic orchestrator. Heavy work delegates to drivers behind
    the same interfaces as v1 (ComputeDriver / SketchDriver); this class owns
    staging, routing, confidence, and the composite trigger.
    """

    def __init__(self, store: QueueStore, compute, sketch,
                 cfg: PipelineV2Config | None = None):
        self.store = store
        self.compute = compute
        self.sketch = sketch
        self.cfg = cfg or PipelineV2Config()
        # Stage-0 outputs held in-process for the session; production reads
        # column_registry instead
        self.column_facts: dict[tuple[str, str], ColumnFacts] = {}
        self.column_tier: dict[tuple[str, str], str] = {}
        # held audit composites (Stage 1 -> Stage 6)
        self.held_composites: dict[tuple[str, str], list[HeldAuditComposite]] = {}
        self._sketch_cache: dict[tuple[str, str], object] = {}

    # ------------------------------------------------------------------ S0
    def stage0_fence_universe(self, facts: list[ColumnFacts]) -> dict:
        eligible = 0
        by_tier = {"STANDARD": 0, "MEGA": 0, "EXCLUDED": 0}
        reasons: dict[str, int] = {}
        for f in facts:
            v = fence_column(f, self.cfg.fence)
            key = (f.table_fqn, f.column_name)
            self.column_facts[key] = f
            self.column_tier[key] = v.tier
            by_tier[v.tier] += 1
            if v.eligible:
                eligible += 1
            else:
                reasons[v.reason] = reasons.get(v.reason, 0) + 1
        return {"total": len(facts), "eligible": eligible,
                "by_tier": by_tier, "exclusion_reasons": reasons}

    # ------------------------------------------------------------------ S1
    def stage1_bootstrap(self, audit_rows: list[dict]) -> dict:
        candidates, stats = parse_audit_rows(audit_rows)
        unary_items: list[WorkItem] = []
        held = 0
        for c in candidates:
            if c.is_composite:
                # HELD for stage 6: released when component unary edges settle
                key = (c.table_a_fqn, c.table_b_fqn)
                self.held_composites.setdefault(key, []).append(
                    HeldAuditComposite(c.a_columns, c.b_columns, c.query_count))
                held += 1
                # ALSO seed the component unary pairs so settlement can occur
                for a_col, b_col in zip(c.a_columns, c.b_columns):
                    unary_items.append(self._make_item(
                        c.table_a_fqn, c.table_b_fqn, (a_col,), (b_col,),
                        trigger="audit_bootstrap",
                        extra_prio=min(c.query_count, 500) * 0.2,
                        signals={"from_composite": True,
                                 "query_count": c.query_count}))
            else:
                unary_items.append(self._make_item(
                    c.table_a_fqn, c.table_b_fqn, c.a_columns, c.b_columns,
                    trigger="audit_bootstrap",
                    extra_prio=min(c.query_count, 500) * 0.4 +
                               (30 if "explicit_join" in c.sources else 0),
                    signals={"query_count": c.query_count,
                             "sources": sorted(c.sources)}))
        inserted = self.store.upsert_candidates(unary_items)
        return {"parse": stats.__dict__, "unary_seeded": len(unary_items),
                "composites_held": held, "newly_queued": inserted}

    def _make_item(self, ta, tb, a_cols, b_cols, trigger, extra_prio=0.0,
                   signals=None) -> WorkItem:
        """Route the pair (ratio-primary), attach the name PRIOR (orders the
        queue, never vetoes), build the WorkItem."""
        dc_a = self._dc(ta, a_cols[0])
        dc_b = self._dc(tb, b_cols[0])
        tier_a = self.column_tier.get((ta, a_cols[0]), "STANDARD")
        tier_b = self.column_tier.get((tb, b_cols[0]), "STANDARD")
        lane = route_pair(dc_a, dc_b, tier_a, tier_b, self.cfg.router)
        nprior = name_prior(a_cols[0], b_cols[0])
        prio = extra_prio + nprior * 15.0 + \
            (10.0 if lane.lane == "CONTAINMENT" else 0.0)
        sig = dict(signals or {})
        sig.update({"lane": lane.lane, "lane_reason": lane.reason,
                    "name_prior": round(nprior, 4),
                    "cardinality_ratio": round(lane.cardinality_ratio, 2),
                    "probe_direction": lane.probe_direction})
        it = WorkItem(table_a_fqn=ta, table_b_fqn=tb,
                      a_columns=tuple(a_cols), b_columns=tuple(b_cols),
                      is_composite=len(a_cols) > 1,
                      priority_score=round(prio, 4),
                      priority_signals=sig, trigger_source=trigger)
        return it

    def _dc(self, table_fqn, col) -> int:
        f = self.column_facts.get((table_fqn, col))
        return f.distinct_estimate if f and f.distinct_estimate else 1

    # ------------------------------------------------------------------ S3
    def stage3_cold_routing(self) -> dict:
        """Cold candidate generation: LSH banding for peer-size pairs; direct
        containment routing for asymmetric/lookup pairs (anchor-star). Uses the
        existing cold seeder for lookup anchors, then routes each candidate by
        the ratio rule instead of assuming LSH."""
        from .cold_lookup_seeder import ColdLookupSeeder, ColdSeedConfig
        seeder = ColdLookupSeeder(self.compute, self.sketch, ColdSeedConfig(
            lsh_min_jaccard=0.05))

        def supplier(table_fqn, column_key):
            ck = (table_fqn, column_key)
            if ck not in self._sketch_cache:
                self._sketch_cache[ck] = self.sketch.build_sketches(
                    table_fqn, [column_key], 128, 500_000)[0]
            return self._sketch_cache[ck]

        raw = seeder.seed(supplier)
        # Re-route each cold candidate with the ratio-primary rule
        routed: list[WorkItem] = []
        for it in raw:
            routed.append(self._make_item(
                it.table_a_fqn, it.table_b_fqn, it.a_columns, it.b_columns,
                trigger="cold_lsh",
                extra_prio=it.priority_score,
                signals=it.priority_signals))
        inserted = self.store.upsert_candidates(routed)
        lanes = {}
        for it in routed:
            lanes[it.priority_signals["lane"]] = lanes.get(
                it.priority_signals["lane"], 0) + 1
        return {"cold_candidates": len(routed), "newly_queued": inserted,
                "lane_split": lanes}

    # ------------------------------------------------------------------ S4
    def stage4_evaluate(self, budget: int) -> dict:
        run_id = str(uuid.uuid4())
        fingerprints = self._fingerprints()
        claimed = self.store.claim_batch(run_id, budget, 3600, fingerprints)
        edges: list[EdgeV2] = []
        for item in claimed:
            try:
                e = self._evaluate(item)
                item.a_fingerprint_at_eval = fingerprints.get(item.table_a_fqn)
                item.b_fingerprint_at_eval = fingerprints.get(item.table_b_fqn)
                if e:
                    edges.append(e)
                    self.store.update_status(item.work_id, "DONE")
                else:
                    self.store.update_status(item.work_id, "SKIPPED")
            except Exception as ex:      # noqa: BLE001
                logger.exception("evaluate failed")
                self.store.update_status(item.work_id, "FAILED", str(ex))
        return {"run_id": run_id, "claimed": len(claimed),
                "edges": len(edges), "results": edges}

    def _evaluate(self, item: WorkItem) -> EdgeV2 | None:
        a_cols, b_cols = list(item.a_columns), list(item.b_columns)
        # containment probe (both lanes end in a probe; LSH lane's jaccard is
        # a proposer, containment is the arbiter)
        ind = self.compute.probe_inclusion(
            item.table_a_fqn, a_cols, item.table_b_fqn, b_cols, 50_000)
        dc_a = self._dc(item.table_a_fqn, a_cols[0])
        dc_b = self._dc(item.table_b_fqn, b_cols[0])
        ratio = max(dc_a, dc_b) / max(1, min(dc_a, dc_b))
        nprior_name = name_prior(a_cols[0], b_cols[0])
        vocab = None
        fa = self.column_facts.get((item.table_a_fqn, a_cols[0]))
        fb = self.column_facts.get((item.table_b_fqn, b_cols[0]))
        if fa and fb:
            from .tier_router import vocab_agreement
            vocab = vocab_agreement(tokenize_column_name(a_cols[0]),
                                    tokenize_column_name(b_cols[0]))

        res = rate(ind.a_in_b, ind.b_in_a, ratio, min(dc_a, dc_b),
                   name_sim=nprior_name, vocab_agree=vocab,
                   llm_score=None,                      # Phase-2 socket, dormant
                   cfg=self.cfg.confidence)

        return EdgeV2(
            table_a_fqn=item.table_a_fqn, table_b_fqn=item.table_b_fqn,
            a_columns=item.a_columns, b_columns=item.b_columns,
            is_composite=item.is_composite,
            discovery_lane=item.priority_signals.get("lane", "CONTAINMENT"),
            containment_a_in_b=ind.a_in_b, containment_b_in_a=ind.b_in_a,
            cardinality_ratio=round(ratio, 2),
            passed_existence_gate=res.passed_existence_gate,
            base_confidence=res.base_confidence,
            semantic_blend=res.semantic_blend,
            final_confidence=res.final_confidence,
            confidence_band=res.band,
            ind_direction=res.direction,
            explanation=res.explanation,
            work_id=item.work_id,
        )

    def _fingerprints(self) -> dict[str, str]:
        fqns = set()
        for it in self.store.all_items():
            fqns.add(it.table_a_fqn); fqns.add(it.table_b_fqn)
        return {f: self.compute.compute_data_fingerprint(f) for f in fqns}

    # ------------------------------------------------------------------ S6
    def stage6_composites(self, settled_edges: list[EdgeV2],
                          clustering: dict[str, list[str]] | None = None) -> dict:
        """Settlement-event consumer: for table pairs with >=2 same-direction
        settled unary edges, generate composite candidates and enqueue them
        as COMPOSITE_PAIR items in the same queue."""
        phase = CompositePhase(self.cfg.composite)
        clustering = clustering or {}

        # group settled edges by table pair
        by_pair: dict[tuple[str, str], list[EdgeV2]] = {}
        for e in settled_edges:
            if e.passed_existence_gate and not e.is_composite and \
                    e.final_confidence >= self.cfg.composite.unary_confidence_floor:
                by_pair.setdefault((e.table_a_fqn, e.table_b_fqn), []).append(e)

        emitted: list[WorkItem] = []
        drift_findings = 0
        for (ta, tb), pair_edges in by_pair.items():
            unary = [UnaryEdge(e.a_columns[0], e.b_columns[0],
                               "a_in_b" if e.ind_direction in ("a_in_b", "bidirectional")
                               else "b_in_a",
                               e.final_confidence) for e in pair_edges]
            cands = phase.generate(
                ta, tb, unary,
                clustering_cols_a=clustering.get(ta),
                clustering_cols_b=clustering.get(tb),
                held_audit=self.held_composites.get((ta, tb)))
            for c in cands:
                if c.finding_class == "SCHEMA_DRIFT_SUSPECT":
                    drift_findings += 1
                it = self._make_item(c.table_a_fqn, c.table_b_fqn,
                                     c.a_columns, c.b_columns,
                                     trigger="composite_settlement",
                                     extra_prio=c.priority_score,
                                     signals={"seed_tier": c.seed_tier,
                                              "finding_class": c.finding_class})
                emitted.append(it)
        inserted = self.store.upsert_candidates(emitted)
        return {"pairs_triggered": len(by_pair),
                "composite_candidates": len(emitted),
                "drift_suspects": drift_findings,
                "newly_queued": inserted}
