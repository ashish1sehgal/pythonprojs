# CLAUDE.md — Relationship Discovery Platform (v2)

> Drop this file at the repo root as `CLAUDE.md` (Claude Code reads it
> automatically), or paste the whole thing as your first message in a Claude
> Code session. It encodes the architecture contract, the invariants that must
> never be violated, and the prioritized backlog.

## What this codebase is

Backend for **incremental, event-driven relationship discovery** (FK/IND
inference) across ~10,000 BigQuery tables / ~500,000 columns, without declared
constraints. Control plane in Postgres, heavy compute pushed down to BigQuery
SQL, Spark reserved for the one genuinely shuffle-shaped job (LSH banding).
Validated end-to-end against in-memory mock drivers that implement real
semantics (real MinHash, real set-containment, real fingerprinting).

## Module map

```
sql/01_control_plane_schema.sql   v1 schema (superseded; keep for reference)
sql/02_control_plane_v2.sql       CURRENT control-plane DDL (Postgres)
discovery/
  tier_router.py        Stage 0: column fence (type/null/enum/freetext),
                        tier assignment, RATIO-PRIMARY lane routing,
                        name-prior helpers (trigram + vocab)
  bq_sqlgen.py          BigQuery SQL generators: MIN/FARM_FINGERPRINT sketch
                        batches (frozen seeds, byte-budget packer) and
                        containment probe batches (hash-mod value-domain
                        sampling, grouped by shared child table)
  confidence.py         Gated confidence model: existence gate -> base math
                        confidence -> bounded semantic modulation; renormalizing
                        semantic blend with DORMANT llm_score socket
  audit_join_parser.py  sqlglot (BigQuery dialect) JOIN...ON + WHERE a.x=b.y
                        extraction -> column-level candidates; composites
                        collapse to one candidate; CTEs dropped (option i)
  composite_phase.py    Stage 6: settlement-triggered composite candidate
                        generation (clustering keys / held audit composites /
                        unary subsets); SCHEMA_DRIFT_SUSPECT finding
  cold_lookup_seeder.py Cold path: lookup-shape detection + LSH anchor-star
  pipeline_v2.py        Six-stage orchestrator (CURRENT)
  pipeline.py           v1 orchestrator (superseded; tests still exercise it)
  work_queue.py         QueueStore: InMemory (validation) + Postgres
                        (FOR UPDATE SKIP LOCKED + lease reclaim)
  drivers.py            ComputeDriver/SketchDriver interfaces; BigQuery/Spark
                        production classes (some bodies NotImplementedError);
                        Mock drivers with REAL semantics
airflow/airflow_dag.py  Thin DAGs: bootstrap (manual) + incremental (weekly)
test_parser.py / test_e2e.py / test_cold.py / test_v2.py   all must pass
```

## ARCHITECTURAL INVARIANTS — never violate these

1. **Ratio-primary lane routing.** For a candidate pair, cardinality ratio
   `dc_large/dc_small > 1/t_LSH` routes to the CONTAINMENT lane. Never send a
   size-asymmetric pair through Jaccard/LSH: for child⊇parent,
   `Jaccard <= dc_parent/dc_child`, so a perfect FK between a 50M fact and a
   250K dim has Jaccard 0.005 — unrecoverable by any banding threshold. The
   MEGA tier line (default 10M) only decides what never gets *sketched*.

2. **No literal Bloom filters inside BigQuery.** The containment lane is pure
   BQ SQL semi-joins: probe the DISTINCT VALUE DOMAIN (never rows — row-wise
   EXISTS weights by frequency), deterministic `MOD(ABS(FARM_FINGERPRINT(k)),N)=0`
   sampling (never TABLESAMPLE — block-biased; never RAND() — non-reproducible,
   breaks conformance comparison over time). Bloom filters remain legitimate
   ONLY for cross-system probes (BQ child vs Oracle/Postgres parent).

3. **No global sorts, ever.** `COUNT(DISTINCT)` and `SELECT DISTINCT ... ORDER BY`
   over large tables are forbidden (empirically: 3.5h vs 10min for
   APPROX_COUNT_DISTINCT on a 300-col table). Sketches are k-permutation
   MinHash via `MIN(FARM_FINGERPRINT(CONCAT(seed, val)))` — monoidal, sort-free.
   `DISTINCT` inside a probe CTE feeding a join is acceptable (cheap dedupe of
   a small sampled set), a COUNT(DISTINCT) aggregate is not.

4. **Sketch identity is frozen.** seed_version -> canonical seed list in
   `bq_sqlgen.SEED_VERSIONS`; NEVER edit an existing version — add v2 and
   re-sketch. Sketches are comparable IFF (seed_version, num_perm,
   normalization, sketch_scope) all match. The cache schema enforces this.

5. **Name similarity NEVER vetoes.** It is a queue-ordering prior, a cold-path
   candidate NOMINATOR (additive), a scoring modulation input, and a
   disambiguator among already-value-confirmed containments. There must be no
   code path where low name similarity excludes a pair carrying value or audit
   evidence. (Renamed FKs — `cust_ref -> customer_key` — are the highest-value
   finds and have near-zero name similarity.)

6. **Confidence is gated, not summed.** `confidence.py` structure: existence
   gate on containment (semantic signals cannot lift a pair over it) -> base
   math confidence -> bounded multiplicative semantic modulation
   `base * (1 + alpha*(sem-0.5))`. The semantic blend RENORMALIZES over
   available components, so the dormant `llm_score` socket (Phase 2) sharpens
   resolution without shifting bands — validated by an explicit invariance
   test in test_v2.py. Do not convert this to a weighted sum.

7. **Composite discovery is never global.** It triggers per-table-pair on
   settlement events (>=2 same-direction settled unary edges), because
   component-wise unary containment is a NECESSARY condition for composite
   containment. Seeds in priority order: clustering keys > held audit
   composites > unary subsets (width <= 3, budgeted). Audit composites whose
   component unary INDs FAILED become SCHEMA_DRIFT_SUSPECT findings, not scores.

8. **Signals propose; value-based confirmation decides.** Audit logs,
   partition/clustering keys, vocab clusters, name affinity — all set priority
   and priors. Only the containment probe creates a confirmed relationship.

9. **The pair is the unit of work; events are the trigger.** No monthly
   all-pairs batch (the scheduled job only DETECTS drift and emits events);
   no per-table on-demand scan (nominations enqueue pairs). Lifecycle FSM:
   CANDIDATE -> full pipeline; CONFIRMED/MONITORING -> skip unless fingerprint
   drift; REJECTED -> blacklisted unless drift; nomination force-reopens.
   Verdicts must NOT re-open settled items (bug fixed in v1 — see
   work_queue.set_lifecycle).

10. **Mock drivers implement real semantics.** Any new driver method gets a
    mock implementation with genuine behavior (not canned returns), so control
    logic stays validatable without cloud access. All four test files must
    pass after every change: `python test_parser.py && python test_e2e.py &&
    python test_cold.py && python test_v2.py`.

## PRIORITIZED BACKLOG (work top-down)

### P0 — Production driver bodies (the NotImplementedError gaps)
- [ ] `BigQueryDriver.probe_inclusion`: generate SQL via
      `bq_sqlgen.generate_probe_sql`/`pack_probe_batches`, execute, parse
      containment fractions. Respect probe_direction from the router
      (only probe feasible directions; both only in the near-equal band).
- [ ] `BigQueryDriver.scan_table_shapes`: read from the profile-results store
      + INFORMATION_SCHEMA (skeleton SQL in file).
- [ ] Sketch ingestion: execute `pack_sketch_batches` output, write BIGINT[]
      signatures to sketch_cache with per-batch idempotency (sketch_batches FSM),
      mark table_registry.is_sketched only when ALL batches land.
- [ ] `PostgresQueueStore`: load a_columns/b_columns arrays in claim_batch
      (currently elided); wire discovery_lane + item_type columns from
      02_control_plane_v2.sql.

### P1 — Incremental LSH band index
- [ ] Implement insert-only banding against the lsh_bands Postgres table:
      new sketches hash into existing bands, emit ONLY new collisions.
      Never re-band the world. (The in-memory lsh_bucket in MockSketchDriver
      documents the banding semantics.)
- [ ] Spark job for the bootstrap-scale initial banding (~150MB of signatures
      fits one executor; MinHashLSH.approxSimilarityJoin or manual banding).

### P2 — Stage 0/1 harvesters
- [ ] Universe harvester: UNIVERSE_SQL -> column_registry with fence verdicts
      (tier_router.fence_column) + partition/clustering flags.
- [ ] Audit harvester: AUDIT_SQL_TEMPLATE with org->project fallback ->
      audit_signals table; unary seeds -> work queue; composites -> HELD.
- [ ] Vocab clustering: tokenize column names per table -> vocab_tokens ->
      cross-table token-overlap scoping (candidates only within/between
      overlapping vocab clusters when no audit evidence exists).

### P3 — Composite verification gates
- [ ] Pre-probe gates for COMPOSITE_PAIR items: uniqueness gate (HLL on the
      parent's CONCAT projection ~= parent rows) and cardinality gate (child
      projected distinct <= parent projected distinct) as pushdown SQL,
      BEFORE the containment probe spends a scan.

### P4 — Phase-2 LLM socket
- [ ] Wire llm_score into confidence.semantic_blend via a provider interface
      (batched, cached on column-metadata fingerprint). Hard gate: only invoke
      for pairs that PASSED the existence gate (LLM refines meaning; it must
      never see — or hallucinate about — pairs with no data evidence).
      The band-invariance test in test_v2.py must keep passing.

### P5 — Operational hardening
- [ ] Lease heartbeat + reclaim in the incremental DAG; dead-letter reporting.
- [ ] Conformance monitoring runs: CONFIRMED edges re-probed on fingerprint
      drift; orphan-rate trend -> DEGRADED lifecycle + alert.
- [ ] Cost telemetry per stage (bytes scanned per probe batch / sketch batch).

## Conventions
- Python 3.11+, type hints, dataclasses; raw psycopg3 (no ORM) for the queue
  (`FOR UPDATE SKIP LOCKED` must stay explicit); sqlglot dialect="bigquery".
- SQL is always GENERATED (bq_sqlgen), never hand-assembled inline — the
  byte-budget guarantee and seed freeze depend on it.
- Every behavioral change lands with a test in the appropriate test_*.py.
- Canonical pair ordering everywhere: table_a_fqn < table_b_fqn, column
  arrays permuted to match; composite columns sorted with alignment preserved.
