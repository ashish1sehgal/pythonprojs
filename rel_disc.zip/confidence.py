"""
confidence.py
=============
The steward-facing Confidence Rating.

Design (locked in architecture review):

  STEP 1  EXISTENCE GATE (mathematical, non-negotiable)
          containment = max(a_in_b, b_in_a). Below the floor, the pair is
          capped at WEAK — no semantic signal can rescue it. Semantic
          similarity is evidence of MEANING, not of EXISTENCE; a weighted sum
          would let a strong name match manufacture confidence for a
          relationship that does not exist in the data.

  STEP 2  BASE MATHEMATICAL CONFIDENCE
          f(containment, direction clarity, cardinality asymmetry). Pure math.

  STEP 3  BOUNDED SEMANTIC MODULATION
          final = base * (1 + alpha * (semantic - 0.5)),  alpha small.
          Strong names nudge UP, poor names nudge DOWN, swing bounded to
          +/- alpha/2. Semantics TUNE a value-grounded number; they never
          CREATE one.

  GRACEFUL DEGRADATION (Phase-1 without LLM):
          semantic = renormalized blend over AVAILABLE components
          (name trigram + vocab now; llm socket dormant). Absent components
          renormalize rather than defaulting to 0, so Phase-2 LLM arrival
          sharpens resolution WITHOUT shifting the band centers — Phase-1
          confirmed edges stay confirmed.

  OUTPUT: a BAND + two-axis decomposition, not a bare float. The two middle
  bands (STRUCTURAL_NAME_MISMATCH, SEMANTIC_ONLY_SUSPECT) are *different
  findings*, not lower-confidence versions of STRONG_FK.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass
class ConfidenceConfig:
    existence_floor: float = 0.80        # containment gate
    alpha: float = 0.20                  # semantic modulation bound (+/- 10%)
    # semantic blend weights (renormalize over available components)
    w_name: float = 0.45
    w_vocab: float = 0.20
    w_llm: float = 0.35                  # dormant until Phase 2
    # banding
    strong_floor: float = 0.85
    semantic_low: float = 0.30           # below this, "name mismatch"
    semantic_high: float = 0.60
    # coincidental-overlap detector: high containment but symmetric sizes and
    # tiny value domains often means shared code space, not FK
    coincidental_ratio_ceiling: float = 1.5
    coincidental_dc_ceiling: int = 1000


@dataclass
class ConfidenceResult:
    passed_existence_gate: bool
    base_confidence: float
    semantic_blend: float
    final_confidence: float
    band: str
    # decomposition for the steward UI
    containment: float
    direction: str
    explanation: str


def semantic_blend(name_sim: float | None,
                   vocab_agree: float | None,
                   llm_score: float | None,
                   cfg: ConfidenceConfig | None = None) -> float:
    """Renormalizing blend: absent components drop out and weights rescale.
    With no LLM: blend = (w_name*name + w_vocab*vocab) / (w_name + w_vocab).
    Returns 0.5 (neutral) if nothing is available — modulation becomes no-op."""
    cfg = cfg or ConfidenceConfig()
    parts = []
    if name_sim is not None:
        parts.append((cfg.w_name, name_sim))
    if vocab_agree is not None:
        parts.append((cfg.w_vocab, vocab_agree))
    if llm_score is not None:
        parts.append((cfg.w_llm, llm_score))
    if not parts:
        return 0.5
    wsum = sum(w for w, _ in parts)
    return sum(w * v for w, v in parts) / wsum


def base_confidence(containment: float,
                    counter_containment: float,
                    cardinality_ratio: float) -> float:
    """
    Pure-math base from the containment evidence.
      * containment is the primary term
      * direction clarity: a clean one-way containment (child in parent, not
        vice versa) is MORE FK-like than symmetric overlap
      * asymmetry corroboration: fact->dimension pairs (high ratio) with high
        containment are the classic FK shape — mild bonus
    """
    direction_clarity = containment - counter_containment    # in [-1, 1]
    clarity_bonus = 0.05 * max(0.0, min(direction_clarity, 1.0))
    asym_bonus = 0.05 if cardinality_ratio >= 3.0 and containment >= 0.90 else 0.0
    return round(min(0.999, containment * 0.90 + clarity_bonus + asym_bonus), 5)


def rate(containment_a_in_b: float,
         containment_b_in_a: float,
         cardinality_ratio: float,
         dc_small: int,
         name_sim: float | None,
         vocab_agree: float | None,
         llm_score: float | None = None,
         cfg: ConfidenceConfig | None = None) -> ConfidenceResult:
    cfg = cfg or ConfidenceConfig()

    containment = max(containment_a_in_b, containment_b_in_a)
    counter = min(containment_a_in_b, containment_b_in_a)
    if containment_a_in_b >= containment_b_in_a:
        direction = "a_in_b"
    else:
        direction = "b_in_a"
    if abs(containment_a_in_b - containment_b_in_a) < 0.02 and containment >= cfg.existence_floor:
        direction = "bidirectional"

    sem = semantic_blend(name_sim, vocab_agree, llm_score, cfg)

    # ---- STEP 1: existence gate ----
    if containment < cfg.existence_floor:
        if sem >= cfg.semantic_high:
            band = "SEMANTIC_ONLY_SUSPECT"      # names match, data doesn't:
            expl = ("High semantic similarity but containment "
                    f"{containment:.2f} below gate — possible schema drift or "
                    "dead relationship. Surfaced for review, not confirmable.")
        else:
            band = "WEAK"
            expl = f"Containment {containment:.2f} below existence gate."
        return ConfidenceResult(False, 0.0, round(sem, 5),
                                round(min(containment, 0.30), 5),
                                band, containment, direction, expl)

    # ---- STEP 2: base (math only) ----
    base = base_confidence(containment, counter, cardinality_ratio)

    # ---- STEP 3: bounded semantic modulation ----
    final = round(min(0.999, base * (1 + cfg.alpha * (sem - 0.5))), 5)

    # ---- banding: a two-axis classification, not a threshold ladder ----
    if sem < cfg.semantic_low:
        if cardinality_ratio <= cfg.coincidental_ratio_ceiling and \
                dc_small <= cfg.coincidental_dc_ceiling:
            band = "COINCIDENTAL_OVERLAP"
            expl = ("Values overlap but sizes are symmetric and the domain is "
                    "tiny — likely a shared code space (e.g., status ints), "
                    "not an FK.")
        else:
            band = "STRUCTURAL_NAME_MISMATCH"
            expl = ("Strong containment with dissimilar names — likely a "
                    "RENAMED foreign key (cross-system / legacy alias). "
                    "High-value find; needs human semantic confirmation.")
    elif final >= cfg.strong_floor:
        band = "STRONG_FK"
        expl = "High containment, clear direction, corroborating names."
    else:
        band = "STRONG_FK" if final >= cfg.strong_floor else "STRUCTURAL_NAME_MISMATCH" \
            if sem < cfg.semantic_low else "WEAK"
        # mid band: containment passed but overall middling
        band = "POSSIBLE_FK"
        expl = "Containment passed the gate; overall confidence moderate."

    return ConfidenceResult(True, base, round(sem, 5), final, band,
                            containment, direction, expl)
