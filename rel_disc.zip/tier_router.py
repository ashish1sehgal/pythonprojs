"""
tier_router.py
==============
STAGE 0 — Universe construction, fencing, and lane routing.

Two distinct responsibilities, both pure functions over metadata/profile stats
(zero data scans):

  1. COLUMN FENCE  — which of the 500K columns are even eligible?
     Type fence:   FLOAT64/BOOL/ARRAY/STRUCT/JSON/GEOGRAPHY/BYTES excluded;
                   long free-text STRING excluded.
     Signal fence: null_frac > 0.9, distinct <= ~10 (flags/enums), constants.

  2. LANE ROUTER — for a candidate PAIR, which discovery mechanism?
     RATIO-PRIMARY RULE (the architecturally decisive one):
         r* = 1 / t_LSH
         ratio = dc_large / dc_small
         ratio <= r*  and both sketchable  -> LSH lane (Jaccard meaningful)
         ratio  > r*  or either unsketched -> CONTAINMENT lane
     The MEGA tier line (dc >= mega_threshold) is secondary: it only
     pre-decides which columns are never sketched, because every pair a Mega
     column joins is either Mega x Mega (tiny, enumerable, containment) or
     asymmetric (containment by the ratio rule anyway).

Rationale for the ratio rule: for a true FK where child ⊇ parent,
Jaccard <= dc_parent / dc_child. A perfect 100% FK between a 50M fact and a
250K dimension has Jaccard 0.005 — no LSH banding threshold can recover it.
Jaccard/LSH is a PEER-matching engine; containment probing is the FK engine.
"""

from __future__ import annotations

from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Config
# ---------------------------------------------------------------------------
@dataclass
class FenceConfig:
    excluded_types: frozenset = frozenset({
        "FLOAT64", "FLOAT", "DOUBLE", "BOOL", "BOOLEAN",
        "ARRAY", "STRUCT", "JSON", "GEOGRAPHY", "BYTES",
        "INTERVAL", "RANGE",
    })
    max_null_fraction: float = 0.90
    min_distinct: int = 11              # <=10 distinct = flag/enum, no signal
    freetext_avg_len: float = 64.0      # STRING longer than this on average
                                        # and not ID-shaped => free text
    mega_threshold: int = 10_000_000    # never sketch above this (secondary line)


@dataclass
class RouterConfig:
    t_lsh: float = 0.30                 # LSH banding threshold
    # r* derived: pairs with ratio beyond this can't clear t_lsh even at
    # perfect containment (Jaccard <= 1/ratio), so LSH would silently miss them
    @property
    def ratio_bound(self) -> float:
        return 1.0 / self.t_lsh


# ---------------------------------------------------------------------------
# Column-level fence + tier
# ---------------------------------------------------------------------------
@dataclass
class ColumnFacts:
    """Everything Stage 0 needs about a column. All from existing metadata /
    profile stats — no scans."""
    table_fqn: str
    column_name: str
    data_type: str
    distinct_estimate: int | None = None
    null_fraction: float | None = None
    avg_length: float | None = None
    total_rows: int | None = None
    is_partition_key: bool = False
    is_clustering_key: bool = False


@dataclass
class FenceVerdict:
    eligible: bool
    tier: str                            # 'STANDARD' | 'MEGA' | 'EXCLUDED'
    reason: str | None = None            # exclusion reason when not eligible


def _looks_id_shaped(col: ColumnFacts) -> bool:
    """Heuristic: high-distinct short strings are ID-like even if 'STRING'."""
    if col.distinct_estimate is None or col.total_rows in (None, 0):
        return False
    return (col.avg_length or 0) <= 40 and \
           col.distinct_estimate / max(col.total_rows, 1) > 0.001


def fence_column(col: ColumnFacts, cfg: FenceConfig | None = None) -> FenceVerdict:
    cfg = cfg or FenceConfig()
    base_type = col.data_type.upper().split("<")[0]   # ARRAY<...> -> ARRAY

    if base_type in cfg.excluded_types:
        return FenceVerdict(False, "EXCLUDED", "type_fence")

    if col.null_fraction is not None and col.null_fraction > cfg.max_null_fraction:
        return FenceVerdict(False, "EXCLUDED", "null_fence")

    dc = col.distinct_estimate
    if dc is not None:
        if dc <= 1:
            return FenceVerdict(False, "EXCLUDED", "constant")
        if dc < cfg.min_distinct:
            return FenceVerdict(False, "EXCLUDED", "enum_fence")

    if base_type == "STRING" and (col.avg_length or 0) > cfg.freetext_avg_len \
            and not _looks_id_shaped(col):
        return FenceVerdict(False, "EXCLUDED", "freetext_fence")

    # eligible; assign tier (the ratio rule at pair time is primary — this
    # line only decides sketchability)
    if dc is not None and dc >= cfg.mega_threshold:
        return FenceVerdict(True, "MEGA", None)
    return FenceVerdict(True, "STANDARD", None)


# ---------------------------------------------------------------------------
# Pair-level lane routing (ratio-primary)
# ---------------------------------------------------------------------------
@dataclass
class LaneDecision:
    lane: str                            # 'LSH' | 'CONTAINMENT'
    cardinality_ratio: float
    probe_direction: str                 # 'a_in_b'|'b_in_a'|'both'
    reason: str


def route_pair(dc_a: int, dc_b: int,
               tier_a: str, tier_b: str,
               rcfg: RouterConfig | None = None,
               hll_rel_error: float = 0.02) -> LaneDecision:
    """
    Ratio-primary lane routing. Also cardinality-gates the probe DIRECTION:
    child ⊆ parent requires dc_child <= dc_parent (within HLL error), so we
    only probe the feasible direction(s) — halves probe volume for the classic
    fact->dimension population.
    """
    rcfg = rcfg or RouterConfig()
    hi, lo = max(dc_a, dc_b), max(1, min(dc_a, dc_b))
    ratio = hi / lo

    # direction gate: containment X⊆Y feasible only if dc_X <= dc_Y*(1+err)
    a_in_b_feasible = dc_a <= dc_b * (1 + hll_rel_error)
    b_in_a_feasible = dc_b <= dc_a * (1 + hll_rel_error)
    if a_in_b_feasible and b_in_a_feasible:
        direction = "both"               # near-equal band: probe both
    elif a_in_b_feasible:
        direction = "a_in_b"
    else:
        direction = "b_in_a"

    if tier_a == "MEGA" or tier_b == "MEGA":
        return LaneDecision("CONTAINMENT", ratio, direction,
                            "mega_tier_never_sketched")
    if ratio > rcfg.ratio_bound:
        return LaneDecision("CONTAINMENT", ratio, direction,
                            f"ratio {ratio:.1f} > bound {rcfg.ratio_bound:.1f}: "
                            f"Jaccard<= {1/ratio:.4f} unrecoverable by LSH")
    return LaneDecision("LSH", ratio, direction, "peer-size pair; Jaccard meaningful")


# ---------------------------------------------------------------------------
# Name affinity (prior + nominator; NEVER a veto)
# ---------------------------------------------------------------------------
def tokenize_column_name(name: str) -> list[str]:
    """snake_case + camelCase tokenization, lowercased, stopword-trimmed."""
    import re
    s = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", name)
    toks = [t.lower() for t in re.split(r"[_\W]+", s) if t]
    stop = {"id", "key", "cd", "num", "no", "dt", "ts", "flg", "ind", "code"}
    core = [t for t in toks if t not in stop]
    return core or toks                  # keep stopwords if that's all there is


def name_trigram_similarity(a: str, b: str) -> float:
    def tg(s: str) -> set[str]:
        s = f"  {s.lower()} "
        return {s[i:i+3] for i in range(len(s) - 2)}
    ta, tb = tg(a), tg(b)
    if not ta or not tb:
        return 0.0
    return len(ta & tb) / len(ta | tb)


def vocab_agreement(tokens_a: list[str], tokens_b: list[str]) -> float:
    sa, sb = set(tokens_a), set(tokens_b)
    if not sa or not sb:
        return 0.0
    return len(sa & sb) / len(sa | sb)


def name_prior(col_a: str, col_b: str) -> float:
    """Priority contribution ONLY. This value orders the queue; it is never
    consulted to exclude a pair (no-veto guard is structural: nothing in the
    candidate generators drops a pair for low name_prior)."""
    return 0.6 * name_trigram_similarity(col_a, col_b) + \
           0.4 * vocab_agreement(tokenize_column_name(col_a),
                                 tokenize_column_name(col_b))
