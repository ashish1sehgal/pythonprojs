"""
stat_registry.py — SQL template registry backed by stat2sql table.
Loads once per job; all render() calls are dict lookups + str.replace.
"""
import re, logging, psycopg2
from typing import Dict, Optional
log = logging.getLogger("stat_registry")
_PH = re.compile(r"<<(\w+)>>")

class UnknownStatError(KeyError): pass
class MissingPlaceholderError(ValueError): pass

class StatTemplateRegistry:
    PLATFORM_COLUMNS = ("oracle","bigquery","mysql","postgres","singlestore","sql")

    def __init__(self, pg_creds: dict, platform: str):
        if platform not in self.PLATFORM_COLUMNS:
            raise ValueError(f"Unknown platform '{platform}'")
        self.platform = platform
        self._templates: Dict[str, str] = {}
        self._ui_map:    Dict[str, tuple] = {}
        self._stat_meta: Dict[str, dict] = {}
        self._load(pg_creds)

    def _load(self, pg_creds: dict):
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as cur:
                cur.execute(f"SELECT stat, COALESCE({self.platform}, sql), cost_tier, cost_weight, pass_group FROM stat2sql")
                for stat, tmpl, tier, weight, grp in cur.fetchall():
                    if tmpl: self._templates[stat] = tmpl
                    self._stat_meta[stat] = {"cost_tier": tier or 0, "cost_weight": float(weight or 1), "pass_group": grp or "A"}
                cur.execute("SELECT ui_label, stat_key, applies_to FROM stat_ui_map")
                for label, key, appl in cur.fetchall():
                    self._ui_map[label] = (key, appl)
        finally:
            conn.close()
        log.info("StatTemplateRegistry: %d templates, %d UI labels, platform=%s", len(self._templates), len(self._ui_map), self.platform)

    def render(self, stat: str, **params) -> Optional[str]:
        if stat not in self._templates and stat not in self._stat_meta:
            raise UnknownStatError(f"stat '{stat}' not in stat2sql")
        tmpl = self._templates.get(stat)
        if tmpl is None: return None  # platform NULL — stat unsupported
        result = tmpl
        for k, v in params.items():
            result = result.replace(f"<<{k}>>", str(v))
        remaining = _PH.findall(result)
        if remaining:
            raise MissingPlaceholderError(f"stat '{stat}' has unresolved placeholders {remaining}")
        return result

    def render_or_none(self, stat: str, **params) -> Optional[str]:
        try: return self.render(stat, **params)
        except (UnknownStatError, MissingPlaceholderError): return None

    def resolve_ui_label(self, label: str) -> Optional[tuple]:
        return self._ui_map.get(label)

    def get_meta(self, stat: str) -> dict:
        return self._stat_meta.get(stat, {"cost_tier":0,"cost_weight":1,"pass_group":"A"})

    def is_supported(self, stat: str) -> bool:
        return stat in self._templates
