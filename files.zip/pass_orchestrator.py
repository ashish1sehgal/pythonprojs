"""
pass_orchestrator.py — 4-Pass Profiling Engine (Main Entry Point)

Pass 1: Full population scan — null count, min, max, mean, approx distinct
         DB-native pushdown via stat2sql. Batched in chunks of 50 columns.
         Results gate all subsequent passes via ColumnClassifier.

Pass 2: Sampled distributional stats — skewness, kurtosis, percentiles
         DB-native pushdown over sampled subquery (deterministic hash or block).
         Same sampling clause shared across ALL batches → identical rows.
         Skewness/kurtosis use centred-moment formula with Pass-1 mean injected.
         BigQuery: APPROX_QUANTILES(col,100) for all percentiles in one call.
         Oracle: PERCENTILE_CONT calls share internal sort.
         Gated: numeric only, not CONSTANT/ALL_NULL/PRIMARY_KEY.

Pass 3: Categorical semantics — top-N frequency + regex pattern distribution
         DB-native GROUP BY pushdown per eligible column.
         Gated: string columns with approx_distinct < categorical_threshold.
         Also runs histograms using Pass-1 min/max (or baseline boundaries).

Pass 4: Python driver math — Shapiro-Wilk (scipy) + PSI (compare to baseline)
         Zero Spark tasks, zero JDBC. Runs on driver node.
         SW uses 2000-row sub-sample fetched as part of Pass-2 JDBC call.
         PSI uses Pass-3 histogram vs baseline histogram from Postgres.
"""

import logging, math
import psycopg2, psycopg2.pool
from concurrent.futures import ThreadPoolExecutor, as_completed
from typing import Any, Dict, List, Optional, Set

from pyspark.sql import SparkSession

from stat_registry import StatTemplateRegistry
from column_classifier import ColumnClassifier, ColumnProfile, is_numeric, is_string
from sampling_manager import SamplingManager
from sql_generator import (generate_pass1_sql, generate_distribution_sql,
                            generate_pattern_sql, generate_histogram_sql,
                            parse_histogram_result, generate_shapiro_sample_sql)
from pass2_sql_generator import generate_pass2_sql, unpack_pass2_results
from psi_calculator import BaselineHistogramLoader, PSICalculator, ShapiroWilkRunner
from result_unpivot import (build_column_metric_rows, write_metrics_batch,
                             write_distributions, write_patterns,
                             write_histograms, write_gating)

log = logging.getLogger("pass_orchestrator")

# ── Spark session ──────────────────────────────────────────────────────────────

def build_spark(run_id: str) -> SparkSession:
    return (SparkSession.builder.appName(f"Profiler_{run_id}")
            .config("spark.executor.memory","4g")
            .config("spark.executor.memoryOverhead","1g")
            .config("spark.driver.memory","2g")
            .config("spark.driver.maxResultSize","512m")
            .config("spark.sql.shuffle.partitions","8")
            .config("spark.task.maxFailures","4")
            .config("spark.network.timeout","300s")
            .config("spark.executor.heartbeatInterval","60s")
            .getOrCreate())

# ── JDBC helper ────────────────────────────────────────────────────────────────

def jdbc_read(spark, url, sql, alias, registry, props, fetch_size=100):
    subq = registry.render("subquery_alias", sql=sql, alias=alias)
    return spark.read.jdbc(url=url, table=subq, properties={**props,"fetchsize":str(fetch_size)})

# ── Pass 1 ─────────────────────────────────────────────────────────────────────

def run_pass1(spark, source_table, config_columns, registry, jdbc_url, jdbc_props,
              batch_size=50) -> Dict[str,Any]:
    merged = {}
    active = [c for c in config_columns if c.get("is_active",True)]
    batches = [active[i:i+batch_size] for i in range(0,len(active),batch_size)]
    log.info("Pass 1: %d columns → %d batches", len(active), len(batches))
    for idx, batch in enumerate(batches):
        sql = generate_pass1_sql(source_table, batch, registry)
        try:
            row = jdbc_read(spark, jdbc_url, sql, f"p1_b{idx}", registry, jdbc_props, 1).first()
            if row: merged.update(row.asDict())
        except Exception as e:
            log.error("Pass 1 batch %d failed: %s", idx+1, e); raise
    log.info("Pass 1 complete: total_rows=%s", merged.get("total_table_rows"))
    return merged

# ── Pass 2 ─────────────────────────────────────────────────────────────────────

def run_pass2(spark, source_table, profiles, pass1_results, total_rows,
              registry, jdbc_url, jdbc_props, sampling_clause, batch_size=10,
              max_workers=4) -> Dict[str,Any]:
    eligible = [p for p in profiles.values() if p.run_pass2]
    if not eligible:
        log.info("Pass 2: no eligible columns"); return {}
    # For small tables run Pass-2 on full table (sampling overhead not worthwhile)
    use_sampling = total_rows > 1_000_000 and sampling_clause.bucket_count > 1
    log.info("Pass 2: %d columns | sampling=%s | strategy=%s",
             len(eligible), use_sampling, sampling_clause.strategy if use_sampling else "FULL_TABLE")

    pass2_cols = [{"column_name":p.column_name,"data_type":p.data_type,
                   "_resolved_stat_keys":None} for p in eligible]
    batches = [pass2_cols[i:i+batch_size] for i in range(0,len(pass2_cols),batch_size)]

    flat: Dict[str,Any] = {}

    def _run_batch(idx, batch):
        sql, bq_arr = generate_pass2_sql(source_table, batch, pass1_results, registry)
        if not sql: return {}
        if use_sampling: sql = sampling_clause.inject_into_sql(sql, source_table)
        raw = jdbc_read(spark, jdbc_url, sql, f"p2_b{idx}", registry, jdbc_props, 1).first()
        if not raw: return {}
        log.info("Pass 2 batch %d/%d: %d sample rows", idx+1, len(batches), raw.asDict().get("sample_rows",0))
        per_col = unpack_pass2_results(raw.asDict(), batch, registry.platform, bq_arr)
        result = {}
        for c_name, col_m in per_col.items():
            for k, v in col_m.items(): result[f"{c_name}__{k}"] = v
        return result

    with ThreadPoolExecutor(max_workers=max_workers) as pool:
        futs = {pool.submit(_run_batch, i, b): i for i, b in enumerate(batches)}
        for f in as_completed(futs):
            try: flat.update(f.result())
            except Exception as e: log.error("Pass 2 batch %d failed: %s", futs[f]+1, e)

    # Shapiro-Wilk micro-sample: 2000 rows via separate JDBC (same sampling clause)
    sw_cols = [p.column_name for p in eligible if p.run_pass4_sw]
    if sw_cols:
        sw_sql = generate_shapiro_sample_sql(source_table, sw_cols, registry, 2000)
        if use_sampling: sw_sql = sampling_clause.inject_into_sql(sw_sql, source_table)
        try:
            sw_subq = registry.render("subquery_alias", sql=sw_sql, alias="sw_samp")
            pdf = spark.read.jdbc(url=jdbc_url, table=sw_subq,
                                  properties={**jdbc_props,"fetchsize":"2000"}).toPandas()
            flat["__sw_arrays"] = {c: pdf[c].dropna().values for c in sw_cols if c in pdf.columns}
        except Exception as e:
            log.error("SW sample fetch failed: %s", e); flat["__sw_arrays"] = {}
    log.info("Pass 2 complete: %d columns", len(eligible))
    return flat

# ── Pass 3 ─────────────────────────────────────────────────────────────────────

def run_pass3(spark, source_table, profiles, registry, jdbc_url, jdbc_props,
              dist_cap=50000, hist_buckets=20, baseline_hists=None,
              max_workers=4) -> Dict[str,Dict]:
    dist_results = {}; pat_results = {}; hist_results = {}
    p3_eligible  = [p for p in profiles.values() if p.run_pass3]
    hist_eligible = [p for p in profiles.values()
                     if is_numeric(p.data_type) and p.min_val is not None and p.max_val is not None
                     and str(p.min_val) != str(p.max_val) and p.cardinality_class not in ("ALL_NULL","CONSTANT")]
    log.info("Pass 3: %d dist/pattern cols | %d histogram cols", len(p3_eligible), len(hist_eligible))

    # Distributions and patterns
    for p in p3_eligible:
        c = p.column_name
        if p.approx_distinct <= dist_cap:
            try:
                rows = jdbc_read(spark, jdbc_url, generate_distribution_sql(source_table,c,registry),
                                 f"dist_{c}", registry, jdbc_props).collect()
                dist_results[c] = [{"val":r["val"],"freq":r["freq"],"pct":float(r["pct"])} for r in rows]
            except Exception as e: log.error("Distribution failed %s: %s", c, e)
            try:
                rows = jdbc_read(spark, jdbc_url, generate_pattern_sql(source_table,c,registry),
                                 f"pat_{c}", registry, jdbc_props).collect()
                pat_results[c] = [{"pattern_mask":r["pattern_mask"],"freq":r["freq"],"pct":float(r["pct"])} for r in rows]
            except Exception as e: log.error("Pattern failed %s: %s", c, e)
        else:
            log.info("Skipping dist/pattern for %s: distinct=%d > cap=%d", c, p.approx_distinct, dist_cap)

    # Histograms with PSI baseline alignment
    for p in hist_eligible:
        c = p.column_name
        base_hist = (baseline_hists or {}).get(c)
        if base_hist:
            h_min, h_max = BaselineHistogramLoader.min_max_for(base_hist)
            aligned = True
        else:
            h_min, h_max = float(p.min_val), float(p.max_val); aligned = False
        hist_sql, strategy = generate_histogram_sql(source_table, c, h_min, h_max, registry, hist_buckets)
        if not hist_sql: continue
        try:
            rows = jdbc_read(spark, jdbc_url, hist_sql, f"hist_{c}", registry, jdbc_props).collect()
            buckets = parse_histogram_result(rows, strategy, h_min, h_max, hist_buckets, p.valid_count)
            for b in buckets: b["baseline_aligned"] = aligned
            hist_results[c] = buckets
        except Exception as e: log.error("Histogram failed %s: %s", c, e)

    log.info("Pass 3 complete: dist=%d pat=%d hist=%d", len(dist_results), len(pat_results), len(hist_results))
    return {"distributions":dist_results,"patterns":pat_results,"histograms":hist_results}

# ── Pass 4 ─────────────────────────────────────────────────────────────────────

def run_pass4(profiles, pass2_flat, baseline_hists, hist_results, baseline_run_id) -> Dict[str,Dict]:
    sw_arrays = pass2_flat.get("__sw_arrays", {})
    sw_results = ShapiroWilkRunner.run(sw_arrays, profiles)
    psi_results = {}
    if baseline_run_id:
        for p in profiles.values():
            if not p.run_pass4_psi: continue
            c = p.column_name
            r = PSICalculator.compute(hist_results.get(c,[]), (baseline_hists or {}).get(c,[]),
                                      baseline_run_id, c)
            if r: psi_results[c] = r
    log.info("Pass 4 complete: SW=%d PSI=%d", len(sw_results), len(psi_results))
    # Merge into flat dict per column
    merged = {}
    for c, sw in sw_results.items():
        merged.setdefault(c,{}).update({"shapiro_wilk":sw.statistic,"p_value":sw.p_value,"sw_sample_size":sw.sample_size})
    for c, psi in psi_results.items():
        merged.setdefault(c,{}).update({"psi_score":psi.psi_score,"psi_severity":psi.psi_severity,"baseline_run_id":psi.baseline_run_id})
    return merged

# ── Main entry point ───────────────────────────────────────────────────────────

def execute_profiling_job(
    run_id:          str,
    source_table:    str,
    config_columns:  List[Dict],
    global_ci_level: str,
    jdbc_source_url: str,
    jdbc_props:      dict,
    pg_creds:        dict,
    platform:        str,
    config:          dict,         # profiler_configs row (has sampling_mode, pk_cols, baseline_run_id)
    gcs_bucket:      Optional[str] = None,
    pubsub_topic:    Optional[str] = None,
    team_id:         Optional[str] = None,
    max_workers:     int = 4,
) -> str:
    """
    Orchestrates the complete 4-pass profiling run.
    Returns the GCS manifest URI if federated output is configured, else "local".
    """
    spark    = build_spark(run_id)
    pg_pool  = psycopg2.pool.ThreadedConnectionPool(2, max_workers+2, **pg_creds)
    registry = StatTemplateRegistry(pg_creds, platform=platform)
    baseline_run_id = config.get("baseline_run_id")

    try:
        # Pre-load baseline histograms (before Pass 1 — needed for histogram bin alignment)
        baseline_hists = {}
        baseline_cols: Set[str] = set()
        if baseline_run_id:
            baseline_hists = BaselineHistogramLoader.load(pg_creds, baseline_run_id)
            baseline_cols  = set(baseline_hists.keys())

        # Build sampling clause ONCE — all Pass-2 batches use the same clause
        mgr = SamplingManager(pg_creds, registry, config)
        sampling_clause = mgr.resolve(0, source_table, None)  # total_rows=0 → resolved after Pass 1

        # ── PASS 1 ──────────────────────────────────────────────────────────────
        log.info("=== PASS 1: Full Population Scan ===")
        pass1_flat  = run_pass1(spark, source_table, config_columns, registry, jdbc_source_url, jdbc_props)
        total_rows  = int(pass1_flat.get("total_table_rows", 0))

        # Update sampling clause with actual row count
        sampling_clause = mgr.resolve(total_rows, source_table, None)

        # Classify columns from Pass-1 results
        classifier = ColumnClassifier(pg_creds, baseline_columns=baseline_cols)
        profiles   = classifier.classify_all(config_columns, pass1_flat, total_rows)

        # ── PASS 2 ──────────────────────────────────────────────────────────────
        log.info("=== PASS 2: Sampled Distributional Stats ===")
        pass2_flat = run_pass2(spark, source_table, profiles, pass1_flat, total_rows,
                               registry, jdbc_source_url, jdbc_props, sampling_clause,
                               max_workers=max_workers)

        # ── PASS 3 ──────────────────────────────────────────────────────────────
        log.info("=== PASS 3: Categorical Semantics + Histograms ===")
        pass3 = run_pass3(spark, source_table, profiles, registry, jdbc_source_url, jdbc_props,
                          baseline_hists=baseline_hists, max_workers=max_workers)

        # ── PASS 4 ──────────────────────────────────────────────────────────────
        log.info("=== PASS 4: Driver Math (SW + PSI) ===")
        pass4_flat = run_pass4(profiles, pass2_flat, baseline_hists,
                               pass3["histograms"], baseline_run_id)

        # ── Unpivot + Enrich ─────────────────────────────────────────────────────
        log.info("Unpivoting and enriching results...")
        metric_rows = build_column_metric_rows(
            pass1_flat, pass2_flat, pass4_flat,
            config_columns, profiles, global_ci_level,
        )

        # ── Write results ────────────────────────────────────────────────────────
        if gcs_bucket and pubsub_topic:
            # FEDERATED MODE: write to GCS → notify PubSub → Dataflow → BQ + Postgres
            from gcs_output_writer import GCSOutputWriter
            writer = GCSOutputWriter(
                gcs_bucket=gcs_bucket, pubsub_topic=pubsub_topic,
                run_id=run_id, source_platform=platform,
                source_schema=config.get("database_schema",""),
                target_table=config.get("target_table",""),
                team_id=team_id or "unknown",
                config_id=config.get("config_id",0),
            )
            manifest_uri = writer.write_all(
                metric_rows=metric_rows,
                dist_results=pass3["distributions"],
                hist_results=pass3["histograms"],
                pat_results=pass3["patterns"],
                profiles=profiles,
            )
            log.info("Federated output written: %s", manifest_uri)
            return manifest_uri
        else:
            # LOCAL MODE: write directly to Postgres
            conn = pg_pool.getconn()
            try:
                write_metrics_batch(conn, run_id, metric_rows)
                write_distributions(conn, run_id, pass3["distributions"])
                write_patterns(conn, run_id, pass3["patterns"])
                write_histograms(conn, run_id, pass3["histograms"])
                write_gating(conn, run_id, profiles)
            finally: pg_pool.putconn(conn)
            log.info("Run %s complete (local mode).", run_id)
            return "local"

    finally:
        pg_pool.closeall(); spark.stop()
