"""
dataflow_pipeline.py — Apache Beam pipeline (runs on Dataflow).
Triggered by PubSub notification from GCS output writer.
Reads NDJSON files from GCS → writes to BigQuery + Postgres.

Key design choices:
  - Storage Write API for BQ (exactly-once, no streaming buffer delay)
  - Batched upsert to Postgres via JDBC inside Dataflow VPC
  - Dead-letter routing for any malformed or failed records
  - Manifest-first reading ensures all data files are complete before read
  - Streaming pipeline (continuous subscription) not batch (per-message trigger)
"""
import json, logging
from typing import Dict, List
import apache_beam as beam
from apache_beam.io import ReadFromPubSub, WriteToBigQuery
from apache_beam.io.gcp.bigquery import BigQueryDisposition
from apache_beam.io.gcp.gcsio import GcsIO
from apache_beam.options.pipeline_options import PipelineOptions, StandardOptions

log = logging.getLogger("dataflow_pipeline")

BQ_SCHEMAS = {
    "metrics": {"fields":[
        {"name":"run_id","type":"STRING","mode":"REQUIRED"},
        {"name":"team_id","type":"STRING","mode":"NULLABLE"},
        {"name":"source_platform","type":"STRING","mode":"NULLABLE"},
        {"name":"source_schema","type":"STRING","mode":"NULLABLE"},
        {"name":"target_table","type":"STRING","mode":"NULLABLE"},
        {"name":"column_name","type":"STRING","mode":"REQUIRED"},
        {"name":"inferred_type","type":"STRING","mode":"NULLABLE"},
        {"name":"cardinality_class","type":"STRING","mode":"NULLABLE"},
        {"name":"passes_executed","type":"STRING","mode":"NULLABLE"},
        {"name":"empty_count","type":"INT64","mode":"NULLABLE"},
        {"name":"distinct_count","type":"INT64","mode":"NULLABLE"},
        {"name":"exact_distinct","type":"INT64","mode":"NULLABLE"},
        {"name":"valid_count","type":"INT64","mode":"NULLABLE"},
        {"name":"zero_count","type":"INT64","mode":"NULLABLE"},
        {"name":"positive_count","type":"INT64","mode":"NULLABLE"},
        {"name":"negative_count","type":"INT64","mode":"NULLABLE"},
        {"name":"min_length","type":"INT64","mode":"NULLABLE"},
        {"name":"max_length","type":"INT64","mode":"NULLABLE"},
        {"name":"min_val","type":"STRING","mode":"NULLABLE"},
        {"name":"max_val","type":"STRING","mode":"NULLABLE"},
        {"name":"mean_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"median_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"stddev_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"skewness","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"kurtosis","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"q1_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"q3_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"p90_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"p95_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"p99_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"iqr_val","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"outlier_lower","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"outlier_upper","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"shapiro_wilk","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"p_value","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"psi_score","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"psi_severity","type":"STRING","mode":"NULLABLE"},
        {"name":"ingested_at","type":"TIMESTAMP","mode":"REQUIRED"},
    ]},
    "distributions":{"fields":[
        {"name":"run_id","type":"STRING","mode":"REQUIRED"},
        {"name":"column_name","type":"STRING","mode":"REQUIRED"},
        {"name":"value_string","type":"STRING","mode":"NULLABLE"},
        {"name":"frequency_count","type":"INT64","mode":"NULLABLE"},
        {"name":"percentage","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"ingested_at","type":"TIMESTAMP","mode":"REQUIRED"},
    ]},
    "histograms":{"fields":[
        {"name":"run_id","type":"STRING","mode":"REQUIRED"},
        {"name":"column_name","type":"STRING","mode":"REQUIRED"},
        {"name":"bucket_index","type":"INT64","mode":"NULLABLE"},
        {"name":"bucket_lower","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"bucket_upper","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"bucket_label","type":"STRING","mode":"NULLABLE"},
        {"name":"frequency_count","type":"INT64","mode":"NULLABLE"},
        {"name":"percentage","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"baseline_aligned","type":"BOOL","mode":"NULLABLE"},
        {"name":"ingested_at","type":"TIMESTAMP","mode":"REQUIRED"},
    ]},
    "patterns":{"fields":[
        {"name":"run_id","type":"STRING","mode":"REQUIRED"},
        {"name":"column_name","type":"STRING","mode":"REQUIRED"},
        {"name":"pattern_mask","type":"STRING","mode":"NULLABLE"},
        {"name":"frequency_count","type":"INT64","mode":"NULLABLE"},
        {"name":"percentage","type":"FLOAT64","mode":"NULLABLE"},
        {"name":"ingested_at","type":"TIMESTAMP","mode":"REQUIRED"},
    ]},
}

class ParsePubSubMessage(beam.DoFn):
    def process(self, msg: bytes):
        try:
            p = json.loads(msg.decode())
            yield {"run_id":p["run_id"],"team_id":p.get("team_id"),"manifest_uri":p["manifest_uri"]}
        except Exception as e:
            yield beam.pvalue.TaggedOutput("dead_letter",{"source":"pubsub_parse","raw":msg.decode(errors="replace"),"error":str(e)})

class ReadManifestAndExpand(beam.DoFn):
    def process(self, desc: Dict):
        gcs = GcsIO()
        try:
            with gcs.open(desc["manifest_uri"],"r") as f: manifest = json.load(f)
        except Exception as e:
            yield beam.pvalue.TaggedOutput("dead_letter",{"source":"manifest_read","run_id":desc["run_id"],"error":str(e)}); return
        if manifest.get("schema_version") != "1.0":
            yield beam.pvalue.TaggedOutput("dead_letter",{"source":"manifest_version","run_id":desc["run_id"],"error":"Unsupported version"}); return
        for fname, finfo in manifest.get("files",{}).items():
            yield {"run_id":desc["run_id"],"team_id":desc.get("team_id"),
                   "file_name":fname,"gcs_path":finfo["path"],"manifest":manifest}

class ReadNDJSON(beam.DoFn):
    def process(self, task: Dict):
        from datetime import datetime, timezone
        gcs = GcsIO(); run_id = task["run_id"]; fname = task["file_name"]
        ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        try:
            with gcs.open(task["gcs_path"],"r") as f:
                for i, line in enumerate(f, 1):
                    line = line.strip()
                    if not line: continue
                    try:
                        r = json.loads(line); r["ingested_at"] = ts; yield (fname, r)
                    except Exception as e:
                        yield beam.pvalue.TaggedOutput("dead_letter",{"source":"ndjson","run_id":run_id,"file":fname,"line":i,"error":str(e)})
        except Exception as e:
            yield beam.pvalue.TaggedOutput("dead_letter",{"source":"gcs_read","run_id":run_id,"path":task["gcs_path"],"error":str(e)})

class RouteByFile(beam.DoFn):
    FILES = {"metrics","distributions","histograms","patterns","gating"}
    def process(self, el):
        fname, rec = el
        if fname in self.FILES: yield beam.pvalue.TaggedOutput(fname, rec)
        else: yield beam.pvalue.TaggedOutput("dead_letter",{"source":"route","file":fname})

class WriteToPostgres(beam.DoFn):
    def __init__(self, pg_conn_str, table_name, batch_size=500):
        self.pg_conn_str=pg_conn_str; self.table=table_name; self.batch_size=batch_size
        self._conn=None; self._batch=[]
    def setup(self):
        import psycopg2; self._conn=psycopg2.connect(self.pg_conn_str)
    def teardown(self):
        if self._batch: self._flush()
        if self._conn: self._conn.close()
    def process(self, r):
        self._batch.append(r)
        if len(self._batch)>=self.batch_size: self._flush()
    def finish_bundle(self):
        if self._batch: self._flush()
    def _flush(self):
        if not self._batch or not self._conn: return
        cols = list(self._batch[0].keys())
        ph = ",".join(["%s"]*len(cols)); cl = ",".join(cols)
        conflict = {"profiler_run_metrics":"(run_id,column_name)",
                    "profiler_run_distributions":"(run_id,column_name,value_string)",
                    "profiler_run_histograms":"(run_id,column_name,bucket_index)",
                    "profiler_run_patterns":"(run_id,column_name,pattern_mask)",
                    "profiler_run_column_gating":"(run_id,column_name)"}.get(self.table,"(run_id,column_name)")
        upd = ",".join(f"{c}=EXCLUDED.{c}" for c in cols if c not in ("run_id","column_name"))
        sql = f"INSERT INTO {self.table} ({cl}) VALUES ({ph}) ON CONFLICT {conflict} DO UPDATE SET {upd}"
        with self._conn.cursor() as cur:
            cur.executemany(sql,[tuple(r.get(c) for c in cols) for r in self._batch])
        self._conn.commit(); self._batch=[]

def run_pipeline(project_id, bq_dataset, pubsub_subscription, pg_conn_str, dead_letter_topic, pipeline_args=None):
    opts = PipelineOptions(pipeline_args); opts.view_as(StandardOptions).streaming = True
    with beam.Pipeline(options=opts) as p:
        msgs = p | "ReadPubSub" >> ReadFromPubSub(subscription=pubsub_subscription)
        parsed, pdl = msgs | "Parse" >> beam.ParDo(ParsePubSubMessage()).with_outputs("dead_letter", main="ok")
        tasks, mdl  = parsed | "Manifests" >> beam.ParDo(ReadManifestAndExpand()).with_outputs("dead_letter", main="ok")
        records, ndl = tasks | "ReadNDJSON" >> beam.ParDo(ReadNDJSON()).with_outputs("dead_letter", main="ok")
        routed = records | "Route" >> beam.ParDo(RouteByFile()).with_outputs("metrics","distributions","histograms","patterns","gating","dead_letter")
        PG_TABLES = {"metrics":"profiler_run_metrics","distributions":"profiler_run_distributions",
                     "histograms":"profiler_run_histograms","patterns":"profiler_run_patterns","gating":"profiler_run_column_gating"}
        for fname in ("metrics","distributions","histograms","patterns"):
            schema = BQ_SCHEMAS[fname]
            routed[fname] | f"BQ_{fname}" >> WriteToBigQuery(
                table=f"{project_id}:{bq_dataset}.profiler_{fname}",
                schema=schema, write_disposition=BigQueryDisposition.WRITE_APPEND,
                create_disposition=BigQueryDisposition.CREATE_IF_NEEDED,
                method=WriteToBigQuery.Method.STORAGE_WRITE_API, triggering_frequency=60)
        for fname, pg_table in PG_TABLES.items():
            routed[fname] | f"PG_{fname}" >> beam.ParDo(WriteToPostgres(pg_conn_str, pg_table))
        ((pdl, mdl, ndl, routed["dead_letter"]) | "FlattenDL" >> beam.Flatten()
         | "SerializeDL" >> beam.Map(lambda r: json.dumps(r).encode())
         | "PublishDL"   >> beam.io.WriteToPubSub(topic=dead_letter_topic))

if __name__ == "__main__":
    import argparse, sys
    ap = argparse.ArgumentParser()
    ap.add_argument("--project_id",required=True); ap.add_argument("--bq_dataset",default="profiler_results")
    ap.add_argument("--pubsub_subscription",required=True); ap.add_argument("--pg_connection_string",required=True)
    ap.add_argument("--dead_letter_topic",required=True)
    known, rest = ap.parse_known_args(sys.argv[1:])
    run_pipeline(known.project_id,known.bq_dataset,known.pubsub_subscription,known.pg_connection_string,known.dead_letter_topic,rest)
