"""
sql_generator.py — Builds Pass-1 and Pass-3 SQL using stat2sql registry.
All SQL expressions come from the registry; zero hardcoded dialect strings.
"""
import math, logging
from typing import Any, Dict, FrozenSet, List, Optional, Set, Tuple
from scipy.stats import chi2 as scipy_chi2
from stat_registry import StatTemplateRegistry

log = logging.getLogger("sql_generator")

FORBIDDEN_IN_PASS2: FrozenSet[str] = frozenset({
    "distinct_count","exact_distinct_count","empty_count",
    "min_val","max_val","total_rows","valid_count",
})

_NUMERIC = ("NUMBER","INT","FLOAT","DECIMAL","NUMERIC","DOUBLE","REAL","BIGINT")
_STRING  = ("VARCHAR","STRING","CHAR","TEXT","NVARCHAR","CLOB")
def is_numeric(t): return any(m in t.upper() for m in _NUMERIC)
def is_string(t):  return any(m in t.upper() for m in _STRING)

def compute_stddev_ci(stddev: float, valid_n: int, ci_level: str) -> Tuple[Optional[float], Optional[float]]:
    if valid_n is None or valid_n < 3 or stddev is None: return None, None
    alpha = 1.0 - float(ci_level) / 100.0
    df = valid_n - 1
    return (stddev * math.sqrt(df / scipy_chi2.ppf(1 - alpha/2, df)),
            stddev * math.sqrt(df / scipy_chi2.ppf(alpha/2, df)))

def _resolve_ui_stats(col: Dict, registry: StatTemplateRegistry) -> Set[str]:
    """Expands stat_pack → stat_keys, applies deselected_stats mask."""
    pack       = col.get("stat_pack", "BASIC")
    deselected = set(col.get("deselected_stats") or [])
    effective  = set(col.get("_effective_stat_keys") or [])
    if effective: return effective - deselected
    # Fallback: resolve via ui_map from selected_stats (legacy support)
    keys = set()
    for label in col.get("selected_stats") or []:
        resolved = registry.resolve_ui_label(label)
        if resolved: keys.add(resolved[0])
    return keys - deselected

# ── Pass 1: Full population aggregation ───────────────────────────────────────

PASS1_ALWAYS = ["empty_count","distinct_count","min_val","max_val","mean_val","valid_count"]
BOX_PLOT_EXPANSION = {"p25","median_val","p75"}

def generate_pass1_sql(table_name: str, batch_cols: List[Dict],
                        registry: StatTemplateRegistry,
                        oracle_alias_limit: int = 900) -> str:
    """Single-pass aggregation for all BASIC stats + whatever the pack needs in Pass A."""
    clauses = []
    for col in batch_cols:
        c = col["column_name"]; t = col["data_type"]
        stat_keys = _resolve_ui_stats(col, registry)
        # Always include BASIC stats
        for s in PASS1_ALWAYS:
            expr = registry.render_or_none(s, col=c)
            if expr: clauses.append(f"{expr} AS {c}__{s}")
        # Numeric pack extras in Pass A
        if is_numeric(t):
            for s in ("stddev_val","zero_count","positive_count","negative_count",
                      "exact_distinct_count","median_val"):
                if s in stat_keys:
                    expr = registry.render_or_none(s, col=c)
                    if expr: clauses.append(f"{expr} AS {c}__{s}")
        # String lengths
        if is_string(t):
            for s in ("min_length","max_length"):
                expr = registry.render_or_none(s, col=c)
                if expr: clauses.append(f"{expr} AS {c}__{s}")
    clauses.append(f"{registry.render('total_rows')} AS total_table_rows")
    return "SELECT\n  " + ",\n  ".join(clauses) + f"\nFROM {table_name}"


# ── Pass 3: Distribution and pattern GROUP BY queries ─────────────────────────

DISTRIBUTION_TOP_N = 10

def generate_distribution_sql(table_name: str, column_name: str,
                               registry: StatTemplateRegistry, top_n: int = DISTRIBUTION_TOP_N) -> str:
    """Top-N value frequency distribution, fully pushed to source DB."""
    val_expr = registry.render("cast_to_string", col=column_name)
    top_n_clause = registry.render("top_n_clause", n=top_n)
    if registry.platform == "oracle":
        inner = (f"SELECT {val_expr} AS val, COUNT(*) AS freq, SUM(COUNT(*)) OVER () AS total_freq\n"
                 f"FROM {table_name} WHERE {column_name} IS NOT NULL GROUP BY {val_expr} ORDER BY freq DESC")
        return (f"SELECT val, freq, ROUND(freq*100/total_freq,2) AS pct\n"
                f"FROM {registry.render('subquery_alias', sql=inner, alias='dist_inner')}\n{top_n_clause}")
    else:
        return (f"SELECT {val_expr} AS val, COUNT(*) AS freq,\n"
                f"       ROUND(COUNT(*)*100.0/SUM(COUNT(*)) OVER(),2) AS pct\n"
                f"FROM {table_name} WHERE {column_name} IS NOT NULL\n"
                f"GROUP BY val ORDER BY freq DESC\n{top_n_clause}")

def generate_pattern_sql(table_name: str, column_name: str,
                         registry: StatTemplateRegistry, top_n: int = DISTRIBUTION_TOP_N) -> str:
    """Regex pattern mask + GROUP BY, fully pushed to source DB."""
    masked = registry.render("pattern_mask", col=column_name)
    top_n_clause = registry.render("top_n_clause", n=top_n)
    if registry.platform == "oracle":
        inner = (f"SELECT {masked} AS pattern_mask, COUNT(*) AS freq, SUM(COUNT(*)) OVER () AS total_freq\n"
                 f"FROM {table_name} WHERE {column_name} IS NOT NULL GROUP BY {masked} ORDER BY freq DESC")
        return (f"SELECT pattern_mask, freq, ROUND(freq*100/total_freq,2) AS pct\n"
                f"FROM {registry.render('subquery_alias', sql=inner, alias='pat_inner')}\n{top_n_clause}")
    else:
        return (f"SELECT {masked} AS pattern_mask, COUNT(*) AS freq,\n"
                f"       ROUND(COUNT(*)*100.0/SUM(COUNT(*)) OVER(),2) AS pct\n"
                f"FROM {table_name} WHERE {column_name} IS NOT NULL\n"
                f"GROUP BY 1 ORDER BY freq DESC\n{top_n_clause}")

def generate_histogram_sql(table_name: str, column_name: str,
                            min_val: float, max_val: float,
                            registry: StatTemplateRegistry, n_buckets: int = 20) -> Tuple[Optional[str], str]:
    if min_val is None or max_val is None or min_val == max_val:
        return None, "skip"
    if registry.platform == "bigquery":
        sql = (f"SELECT APPROX_QUANTILES({column_name},{n_buckets}) AS quantile_array\n"
               f"FROM {table_name} WHERE {column_name} IS NOT NULL")
        return sql, "approx_quantiles"
    expr = registry.render_or_none("histogram", col=column_name, min=min_val, max=max_val, n_buckets=n_buckets)
    if not expr: return None, "skip"
    top_n = registry.render("top_n_clause", n=n_buckets+2)
    subq = f"SELECT {expr} AS bucket, COUNT(*) AS freq FROM {table_name} WHERE {column_name} IS NOT NULL GROUP BY bucket ORDER BY bucket"
    return subq, "width_bucket"

def parse_histogram_result(rows, strategy, min_val, max_val, n_buckets, total_count):
    if not rows or strategy == "skip": return []
    bw = (float(max_val) - float(min_val)) / n_buckets
    total = float(total_count) or 1.0
    if strategy == "approx_quantiles":
        arr = rows[0]["quantile_array"] or []
        return [{"bucket_index":i+1,"bucket_lower":float(arr[i]),"bucket_upper":float(arr[i+1]),
                 "bucket_label":f"{arr[i]:.4g}–{arr[i+1]:.4g}",
                 "frequency_count":round(total/max(len(arr)-1,1)),
                 "percentage":round(100.0/max(len(arr)-1,1),2),"baseline_aligned":False}
                for i in range(len(arr)-1)]
    freq_by_bucket = {r["bucket"]: r["freq"] for r in rows if r.get("bucket") and 1 <= r["bucket"] <= n_buckets}
    return [{"bucket_index":b,"bucket_lower":float(min_val)+(b-1)*bw,"bucket_upper":float(min_val)+b*bw,
             "bucket_label":f"{float(min_val)+(b-1)*bw:.4g}–{float(min_val)+b*bw:.4g}",
             "frequency_count":freq_by_bucket.get(b,0),
             "percentage":round(freq_by_bucket.get(b,0)/total*100,2),"baseline_aligned":False}
            for b in range(1,n_buckets+1)]

def generate_shapiro_sample_sql(table_name: str, sw_columns: List[str],
                                 registry: StatTemplateRegistry, sample_size: int = 2000) -> str:
    col_list   = ", ".join(sw_columns)
    non_null   = " OR ".join(f"{c} IS NOT NULL" for c in sw_columns)
    rand_order = registry.render("random_order")
    top_n      = registry.render("top_n_clause", n=sample_size)
    inner      = f"SELECT {col_list} FROM {table_name} WHERE {non_null}"
    inner_ref  = registry.render("subquery_alias", sql=inner, alias="sw_src")
    return f"SELECT {col_list} FROM {inner_ref} ORDER BY {rand_order} {top_n}"
