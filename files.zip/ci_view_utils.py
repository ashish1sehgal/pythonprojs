"""
ci_view_utils.py — Populates chi2_critical_values lookup table.
Run once at deployment. Safe to re-run (ON CONFLICT DO NOTHING).
The CI view uses this table to compute StdDev CI bounds without Python.
"""
import logging
from typing import List
import psycopg2
from scipy.stats import chi2 as scipy_chi2

log = logging.getLogger("ci_view_utils")
ALPHA_HALVES = [0.005, 0.025, 0.050]  # for 99%, 95%, 90% CI
DF_RANGES = [(1,101,1),(101,1001,5),(1001,10001,50),(10001,100001,500),(100001,500001,5000)]

def populate_chi2_table(pg_creds: dict, batch_size: int = 500):
    conn = psycopg2.connect(**pg_creds); rows = []; total = 0
    try:
        for df_min, df_max, step in DF_RANGES:
            for df in range(df_min, df_max, step):
                for a in ALPHA_HALVES:
                    rows.append((df, a, float(scipy_chi2.ppf(a, df)), float(scipy_chi2.ppf(1-a, df))))
                if len(rows) >= batch_size:
                    _insert(conn, rows); total += len(rows); rows = []
        if rows: _insert(conn, rows); total += len(rows)
        conn.commit()
    finally: conn.close()
    log.info("chi2_critical_values: %d rows inserted", total)

def _insert(conn, rows: List):
    with conn.cursor() as cur:
        cur.executemany("INSERT INTO chi2_critical_values (df_bucket,alpha_half,chi2_lower,chi2_upper) VALUES (%s,%s,%s,%s) ON CONFLICT DO NOTHING", rows)

if __name__ == "__main__":
    import json, sys
    pg_creds = json.loads(sys.argv[1]) if len(sys.argv) > 1 else {}
    populate_chi2_table(pg_creds)
    print("chi2 table populated.")
