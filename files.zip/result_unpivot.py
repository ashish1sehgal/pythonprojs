"""
result_unpivot.py — Converts wide JDBC result rows into per-column metric dicts.

Why Python unpivot, not DB UNPIVOT:
  After aggregation, the JDBC result is ONE row (~400 key-value pairs for
  a 50-column batch). Unpivoting 400 values into 50 per-column dicts is
  microseconds of dict iteration on the driver node — no DB round-trip,
  no dialect complexity. DB UNPIVOT syntax differs across all 5 platforms.

The double-underscore '__' is the alias delimiter convention throughout.
Longest-suffix-match handles column names that contain '__' themselves.
"""
import logging, math
from typing import Any, Dict, FrozenSet, Iterator, List, Optional, Set, Tuple
import psycopg2
from sql_generator import compute_stddev_ci

log = logging.getLogger("result_unpivot")

ALL_STAT_SUFFIXES: FrozenSet[str] = frozenset({
    "empty_count","distinct_count","exact_distinct_count","valid_count",
    "zero_count","positive_count","negative_count",
    "min_val","max_val","mean_val","median_val","stddev_val",
    "min_length","max_length",
    "skewness","kurtosis",
    "p25","p75","p90","p95","p99","iqr_val","outlier_lower","outlier_upper",
    "shapiro_wilk","p_value","sw_sample_size",
    "psi_score","psi_severity",
    "sample_nonnull",
})
BATCH_LEVEL = frozenset({"total_table_rows","sample_rows"})
DIAGNOSTIC_ONLY = frozenset({"sample_nonnull"})

def _parse_alias(alias: str, col_set: Set[str]) -> Tuple[Optional[str],Optional[str]]:
    for suf in sorted(ALL_STAT_SUFFIXES, key=len, reverse=True):
        sep = f"__{suf}"
        if alias.endswith(sep):
            col = alias[:-len(sep)]
            if col in col_set: return col, suf
    return None, None

def unpivot_pass_results(flat: Dict[str,Any], col_names: List[str]) -> Dict[str,Dict[str,Any]]:
    col_set = set(col_names)
    result  = {c: {} for c in col_names}
    for key, val in flat.items():
        if key in BATCH_LEVEL or key.startswith("__"): continue
        col, suf = _parse_alias(key, col_set)
        if col and suf: result[col][suf] = val
    return result

def enrich_column_metrics(m: Dict[str,Any], col_config: Dict, profile,
                           global_ci_level: str, passes: List[str]) -> Dict[str,Any]:
    m = dict(m)
    ci_level = str(int(col_config.get("override_confidence_level") or global_ci_level))
    # StdDev CI — chi-squared; uses population valid_count from profile, NOT sample_nonnull
    stddev  = m.get("stddev_val")
    valid_n = profile.valid_count if profile else None
    if stddev is not None and valid_n and valid_n >= 3:
        lo, hi = compute_stddev_ci(stddev, valid_n, ci_level)
        m["stddev_ci_lower"] = lo; m["stddev_ci_upper"] = hi
    # Box plot whiskers (if not already set by pass2 unpivot)
    q1 = m.get("p25"); q3 = m.get("p75")
    if q1 is not None and q3 is not None and "iqr_val" not in m:
        iqr = float(q3) - float(q1)
        m["iqr_val"] = iqr; m["outlier_lower"] = float(q1)-1.5*iqr; m["outlier_upper"] = float(q3)+1.5*iqr
    # TEXT cast for min/max polymorphism
    for k in ("min_val","max_val"):
        if m.get(k) is not None: m[k] = str(m[k])
    # Audit
    m["passes_executed"] = ",".join(passes)
    if profile: m["cardinality_class"] = profile.cardinality_class
    # Strip diagnostic-only keys
    for k in DIAGNOSTIC_ONLY: m.pop(k, None)
    return m

def build_column_metric_rows(pass1_flat, pass2_flat, pass4_results,
                               column_configs, profiles, global_ci_level) -> Dict[str,Dict[str,Any]]:
    col_names   = [c["column_name"] for c in column_configs if c.get("is_active",True)]
    col_cfg_map = {c["column_name"]: c for c in column_configs}
    p1 = unpivot_pass_results(pass1_flat, col_names)
    p2 = unpivot_pass_results(pass2_flat, col_names) if pass2_flat else {}
    final = {}
    for c_name in col_names:
        profile = profiles.get(c_name)
        merged = {}; merged.update(p1.get(c_name,{})); merged.update(p2.get(c_name,{}))
        p4 = pass4_results.get(c_name, {})
        merged.update(p4)
        passes = ["1"]
        if profile and profile.run_pass2 and p2.get(c_name): passes.append("2")
        if profile and profile.run_pass3:                      passes.append("3")
        if p4:                                                 passes.append("4")
        final[c_name] = enrich_column_metrics(merged, col_cfg_map.get(c_name,{}),
                                               profile, global_ci_level, passes)
    return final

# ── Postgres batch writer ──────────────────────────────────────────────────────

_METRICS_COLS = [
    "run_id","column_name","inferred_type","cardinality_class","passes_executed",
    "empty_count","distinct_count","exact_distinct","valid_count",
    "zero_count","positive_count","negative_count","min_length","max_length",
    "min_val","max_val","mean_val","median_val","stddev_val",
    "skewness","kurtosis","q1_val","q3_val","p90_val","p95_val","p99_val",
    "iqr_val","outlier_lower","outlier_upper",
    "shapiro_wilk","p_value","sw_sample_size","psi_score","psi_severity","baseline_run_id",
]
_KEY_REMAP = {"p25":"q1_val","p75":"q3_val","p90":"p90_val","p95":"p95_val","p99":"p99_val",
              "exact_distinct_count":"exact_distinct"}

def _nan_to_none(v):
    if isinstance(v, float) and math.isnan(v): return None
    return v

def write_metrics_batch(conn, run_id: str, metric_rows: Dict[str,Dict[str,Any]]):
    if not metric_rows: return
    rows = []
    for col_name, m in metric_rows.items():
        def g(key):
            mapped = _KEY_REMAP.get(key, key)
            return _nan_to_none(m.get(mapped) if mapped != key else m.get(key))
        rows.append(tuple([run_id, col_name] + [g(c) for c in _METRICS_COLS[2:]]))
    ph = ", ".join(["%s"]*len(_METRICS_COLS))
    update = ", ".join(f"{c}=EXCLUDED.{c}" for c in _METRICS_COLS if c not in ("run_id","column_name"))
    sql = f"INSERT INTO profiler_run_metrics ({', '.join(_METRICS_COLS)}) VALUES ({ph}) ON CONFLICT (run_id,column_name) DO UPDATE SET {update}"
    with conn.cursor() as cur: cur.executemany(sql, rows)
    conn.commit()
    log.info("Wrote %d metric rows", len(rows))

def write_distributions(conn, run_id: str, dist: Dict[str,List[Dict]]):
    if not dist: return
    rows = [(run_id, col, r["val"], r["freq"], r["pct"]) for col, rows in dist.items() for r in rows]
    with conn.cursor() as cur:
        cur.executemany("INSERT INTO profiler_run_distributions (run_id,column_name,value_string,frequency_count,percentage) VALUES (%s,%s,%s,%s,%s)", rows)
    conn.commit()

def write_patterns(conn, run_id: str, pat: Dict[str,List[Dict]]):
    if not pat: return
    rows = [(run_id, col, r["pattern_mask"], r["freq"], r["pct"]) for col, rows in pat.items() for r in rows]
    with conn.cursor() as cur:
        cur.executemany("INSERT INTO profiler_run_patterns (run_id,column_name,pattern_mask,frequency_count,percentage) VALUES (%s,%s,%s,%s,%s)", rows)
    conn.commit()

def write_histograms(conn, run_id: str, hists: Dict[str,List[Dict]]):
    if not hists: return
    rows = [(run_id, col, b["bucket_index"], b["bucket_lower"], b["bucket_upper"],
             b["bucket_label"], b["frequency_count"], b["percentage"], b.get("baseline_aligned",False))
            for col, buckets in hists.items() for b in buckets]
    with conn.cursor() as cur:
        cur.executemany("INSERT INTO profiler_run_histograms (run_id,column_name,bucket_index,bucket_lower,bucket_upper,bucket_label,frequency_count,percentage,baseline_aligned) VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s)", rows)
    conn.commit()

def write_gating(conn, run_id: str, profiles: Dict):
    if not profiles: return
    rows = [(run_id, col, p.total_rows, p.approx_distinct, p.null_count, p.cardinality_class,
             p.run_pass2, p.pass2_skip_reason, p.run_pass3, p.pass3_skip_reason,
             p.run_pass4_sw, p.run_pass4_psi, p.pass4_psi_skip_reason)
            for col, p in profiles.items()]
    with conn.cursor() as cur:
        cur.executemany("""INSERT INTO profiler_run_column_gating
            (run_id,column_name,total_rows,approx_distinct,null_count,cardinality_class,
             pass2_eligible,pass2_skip_reason,pass3_eligible,pass3_skip_reason,
             pass4_sw_eligible,pass4_psi_eligible,pass4_psi_skip_reason)
            VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
            ON CONFLICT (run_id,column_name) DO UPDATE SET cardinality_class=EXCLUDED.cardinality_class""", rows)
    conn.commit()
