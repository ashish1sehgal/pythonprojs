"""
config_validator.py — Validates profiler_config_columns at config-save time.
Called by Spring Boot before persisting config. Errors block the save.
Three layers: (1) pack membership, (2) cardinality restrictions, (3) pack count limits.
"""
import logging
from dataclasses import dataclass, field
from typing import Dict, List, Set, Tuple
import psycopg2

log = logging.getLogger("config_validator")
BOOLEAN_TYPES = frozenset({"BOOLEAN","BOOL","BIT","TINYINT(1)","BIT(1)"})

@dataclass
class ColResult:
    column_name: str; stat_pack: str
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    effective_stats: List[str] = field(default_factory=list)
    @property
    def is_valid(self): return not self.errors

@dataclass
class ValidationResult:
    is_valid: bool; column_results: Dict[str,ColResult]
    global_errors: List[str] = field(default_factory=list)
    global_warnings: List[str] = field(default_factory=list)
    pack_counts: Dict[str,int] = field(default_factory=dict)

class ConfigValidator:
    def __init__(self, pg_creds: dict):
        self._packs: Dict[str,Set[str]] = {}
        self._restrictions: Dict[str,List[Dict]] = {}
        self._limits: Dict[str,int] = {}
        self._load(pg_creds)

    def _load(self, pg_creds):
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT pack_name,stat_key FROM stat_pack_contents")
                for p,s in cur.fetchall(): self._packs.setdefault(p,set()).add(s)
                cur.execute("SELECT cardinality_class,stat_key,restriction_type,reason_template FROM stat_cardinality_restrictions")
                for cls,stat,rtype,reason in cur.fetchall():
                    self._restrictions.setdefault(cls,[]).append({"stat_key":stat,"type":rtype,"reason":reason})
                cur.execute("SELECT config_key,config_value FROM stat_cost_config WHERE config_key LIKE 'max_%' OR config_key LIKE 'warn_%'")
                self._limits = {k:int(v) for k,v in cur.fetchall()}
        finally: conn.close()

    def validate(self, config_columns: List[Dict]) -> ValidationResult:
        active = [c for c in config_columns if c.get("is_active",True)]
        col_results = {}; pack_counts: Dict[str,int] = {}
        for col in active:
            r = self._validate_col(col); col_results[col["column_name"]] = r
            pack_counts[col.get("stat_pack","BASIC")] = pack_counts.get(col.get("stat_pack","BASIC"),0)+1
        gerr, gwarn = self._check_limits(pack_counts)
        return ValidationResult(all(r.is_valid for r in col_results.values()) and not gerr,
                                col_results, gerr, gwarn, pack_counts)

    def _validate_col(self, col) -> ColResult:
        c_name = col["column_name"]; c_type = col.get("data_type","").upper()
        pack = col.get("stat_pack","BASIC"); desel = set(col.get("deselected_stats") or [])
        eff_cls = col.get("runtime_cardinality_class") or col.get("schema_cardinality_class") or "PRE_UNKNOWN"
        r = ColResult(c_name, pack)
        pack_stats = self._packs.get(pack, set())
        invalid_desel = desel - pack_stats
        if invalid_desel: r.errors.append(f"Stats {sorted(invalid_desel)} not in '{pack}' pack — cannot deselect")
        if c_type in BOOLEAN_TYPES:
            for s in {"p25","median_val","p75","p90","p95","p99","box_plot","histogram","skewness","kurtosis"} & pack_stats:
                r.warnings.append(f"'{s}' has no meaning for BOOLEAN column; add to deselected_stats")
        for restr in self._restrictions.get(eff_cls, []):
            stat_key = restr["stat_key"]
            if stat_key not in pack_stats or stat_key in desel: continue
            if restr["type"] == "BLOCK": r.errors.append(f"'{stat_key}' blocked: {restr['reason']}")
            else: r.warnings.append(f"'{stat_key}' warning: {restr['reason']}")
        r.effective_stats = sorted(s for s in pack_stats if s not in desel
                                    and not any(x["stat_key"]==s and x["type"]=="BLOCK"
                                                for x in self._restrictions.get(eff_cls,[])))
        return r

    def _check_limits(self, counts) -> Tuple[List[str],List[str]]:
        errs=[]; warns=[]
        adv=counts.get("ADVANCED",0); std=counts.get("STANDARD",0)
        max_adv=self._limits.get("max_advanced_columns_per_run",25); max_std=self._limits.get("max_standard_columns_per_run",200)
        warn_adv=self._limits.get("warn_advanced_columns",10); warn_std=self._limits.get("warn_standard_columns",100)
        if adv > max_adv: errs.append(f"{adv} ADVANCED columns exceeds limit {max_adv}. Downgrade {adv-max_adv} to STANDARD/BASIC.")
        elif adv > warn_adv: warns.append(f"{adv} ADVANCED columns (warning threshold {warn_adv})")
        if std > max_std: errs.append(f"{std} STANDARD columns exceeds limit {max_std} (Oracle SELECT alias ceiling).")
        elif std > warn_std: warns.append(f"{std} STANDARD columns (warning threshold {warn_std})")
        return errs, warns

    def update_runtime_cardinality(self, pg_creds, config_id, run_id):
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as cur:
                cur.execute("""UPDATE profiler_config_columns pcc
                    SET runtime_cardinality_class=m.cardinality_class,
                        percentile_restricted=(m.cardinality_class IN ('PRIMARY_KEY','HIGH_CARDINALITY'))
                    FROM profiler_run_metrics m
                    WHERE m.run_id=%s AND m.column_name=pcc.column_name AND pcc.config_id=%s
                    AND m.cardinality_class IS NOT NULL""", (run_id, config_id))
                n = cur.rowcount
            conn.commit(); log.info("Updated runtime cardinality for %d columns", n)
        finally: conn.close()
