-- ==============================================================================
-- 02_stat2sql_seed.sql — Complete stat2sql + governance seed data
-- ==============================================================================

-- ==============================================================================
-- 1. STAT2SQL — All expressions with platform overrides
-- ==============================================================================

INSERT INTO stat2sql (stat, oracle, bigquery, mysql, postgres, singlestore, sql, cost_tier, cost_weight, pass_group) VALUES

-- ── Pass A: Full population aggregates ────────────────────────────────────────
('empty_count',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'COUNTIF(<<col>> IS NULL)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 'SUM(CASE WHEN <<col>> IS NULL THEN 1 ELSE 0 END)',
 0, 1, 'A'),

('distinct_count',
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'APPROX_COUNT_DISTINCT(<<col>>)',
 'COUNT(DISTINCT <<col>>)',
 0, 2, 'A'),

('exact_distinct_count',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 'COUNT(DISTINCT <<col>>)',
 1, 8, 'A'),

('valid_count',  NULL,NULL,NULL,NULL,NULL, 'COUNT(<<col>>)',            0, 1, 'A'),
('total_rows',   NULL,NULL,NULL,NULL,NULL, 'COUNT(*)',                  0, 0, 'A'),
('min_val',      NULL,NULL,NULL,NULL,NULL, 'MIN(<<col>>)',              0, 1, 'A'),
('max_val',      NULL,NULL,NULL,NULL,NULL, 'MAX(<<col>>)',              0, 1, 'A'),
('mean_val',     NULL,NULL,NULL,NULL,NULL, 'AVG(<<col>>)',              0, 1, 'A'),
('stddev_val',   NULL,NULL,NULL,NULL,NULL, 'STDDEV(<<col>>)',           0, 2, 'A'),
('zero_count',   NULL,NULL,NULL,NULL,NULL, 'SUM(CASE WHEN <<col>> = 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),
('positive_count',NULL,NULL,NULL,NULL,NULL,'SUM(CASE WHEN <<col>> > 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),
('negative_count',NULL,NULL,NULL,NULL,NULL,'SUM(CASE WHEN <<col>> < 0 THEN 1 ELSE 0 END)', 0, 1, 'A'),
('min_length',   NULL,NULL,NULL,NULL,NULL, 'MIN(LENGTH(<<col>>))',      0, 1, 'A'),
('max_length',   NULL,NULL,NULL,NULL,NULL, 'MAX(LENGTH(<<col>>))',      0, 1, 'A'),

-- Median — Pass A (approximate on BQ, exact on Oracle/Postgres)
('median_val',
 'PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY <<col>>)',
 'CAST(APPROX_QUANTILES(<<col>>, 100)[OFFSET(50)] AS STRING)',
 NULL,
 'PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY <<col>>)',
 1, 4, 'A'),

-- ── Pass B: Sampled distributional stats ──────────────────────────────────────
-- Skewness: Oracle uses native; others use numerically stable centred formula.
-- <<mean>> is injected as a SQL literal from Pass 1 results before query build.
-- Centred formula: AVG((col-μ)^3) / AVG((col-μ)^2)^1.5
-- This avoids catastrophic cancellation of the raw moment formula for large values.
('skewness',
 'SKEWNESS_POP(<<col>>)',
 'SAFE_DIVIDE(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,3)),POW(NULLIF(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,2)),0),1.5))',
 'AVG(POW(<<col>>-<<mean>>,3))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),1.5),0)',
 'AVG(POWER(<<col>>::NUMERIC-<<mean>>,3))/NULLIF(POWER(AVG(POWER(<<col>>::NUMERIC-<<mean>>,2)),1.5),0)',
 'AVG(POW(<<col>>-<<mean>>,3))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),1.5),0)',
 'AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,3))/NULLIF(POWER(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,2)),1.5),0)',
 1, 3, 'B'),

-- Kurtosis: excess (Fisher def, normal=0). Oracle native; others centred formula.
-- Formula: AVG((col-μ)^4)/AVG((col-μ)^2)^2 - 3
('kurtosis',
 'KURTOSIS_POP(<<col>>)',
 'SAFE_DIVIDE(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,4)),POW(NULLIF(AVG(POW(CAST(<<col>> AS FLOAT64)-<<mean>>,2)),0),2))-3',
 '(AVG(POW(<<col>>-<<mean>>,4))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),2),0))-3',
 '(AVG(POWER(<<col>>::NUMERIC-<<mean>>,4))/NULLIF(POWER(AVG(POWER(<<col>>::NUMERIC-<<mean>>,2)),2),0))-3',
 '(AVG(POW(<<col>>-<<mean>>,4))/NULLIF(POW(AVG(POW(<<col>>-<<mean>>,2)),2),0))-3',
 '(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,4))/NULLIF(POWER(AVG(POWER(CAST(<<col>> AS DECIMAL(38,10))-<<mean>>,2)),2),0))-3',
 1, 3, 'B'),

-- Percentiles: Oracle shares sort across PERCENTILE_CONT calls on same column.
-- BigQuery uses APPROX_QUANTILES (handled specially in generator — one call per col).
('p25',
 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 NULL,
 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.25) WITHIN GROUP (ORDER BY <<col>>)',
 2, 10, 'B'),

('p75',
 'PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 NULL,
 'PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.75) WITHIN GROUP (ORDER BY <<col>>)',
 2, 10, 'B'),

('p90',
 'PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 NULL,
 'PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.90) WITHIN GROUP (ORDER BY <<col>>)',
 2, 12, 'B'),

('p95',
 'PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 NULL,
 'PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY <<col>>)',
 2, 12, 'B'),

('p99',
 'PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 NULL,
 'PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
 NULL,
 'PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY <<col>>)',
 2, 15, 'B'),

('box_plot', NULL,NULL,NULL,NULL,NULL,NULL, 2, 25, 'B'),
-- box_plot is a meta-stat; generator expands to p25+median+p75. No SQL expression.

('histogram',
 'WIDTH_BUCKET(CAST(<<col>> AS FLOAT),CAST(<<min>> AS FLOAT),CAST(<<max>> AS FLOAT),<<n_buckets>>)',
 NULL,
 NULL,
 'WIDTH_BUCKET(<<col>>::FLOAT,<<min>>::FLOAT,<<max>>::FLOAT,<<n_buckets>>)',
 NULL,
 'WIDTH_BUCKET(CAST(<<col>> AS FLOAT),CAST(<<min>> AS FLOAT),CAST(<<max>> AS FLOAT),<<n_buckets>>)',
 3, 20, 'C'),

-- ── Pass C: Group-by expressions (string/categorical stats) ───────────────────
('cast_to_string',
 'TO_CHAR(<<col>>)',
 'CAST(<<col>> AS STRING)',
 'CAST(<<col>> AS CHAR)',
 '<<col>>::TEXT',
 'CAST(<<col>> AS CHAR)',
 'CAST(<<col>> AS VARCHAR)',
 0, 1, 'C'),

-- Pattern mask: collapses [A-Za-z]→A, [0-9]→N, preserves separators
('pattern_mask',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,r''[A-Za-z]'',''A''),r''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 'REGEXP_REPLACE(REGEXP_REPLACE(<<col>>,''[A-Za-z]'',''A''),''[0-9]'',''N'')',
 0, 2, 'C'),

('dist_total_freq', NULL,NULL,NULL,NULL,NULL, 'SUM(COUNT(*)) OVER ()', 0, 0, 'C'),

-- ── Structural / sampling helpers ─────────────────────────────────────────────
-- Deterministic hash sampling WHERE clause.
-- bucket_count = ROUND(100/pct). Same row always → same hash.
-- Guarantees identical sample rows across all batches in a run.
('deterministic_sample_where',
 'ORA_HASH(<<pk_col>>,<<bucket_count>>)=0',
 'MOD(ABS(FARM_FINGERPRINT(CAST(<<pk_col>> AS STRING))),<<bucket_count>>)=0',
 'MOD(CRC32(<<pk_col>>),<<bucket_count>>)=0',
 'MOD(ABS(hashtext(<<pk_col>>::TEXT)),<<bucket_count>>)=0',
 'MOD(CRC32(<<pk_col>>),<<bucket_count>>)=0',
 'MOD(ABS(CAST(HASH(<<pk_col>>) AS BIGINT)),<<bucket_count>>)=0',
 0, 0, 'B'),

-- Block-level sampling (opt-in for >50B row tables).
-- Different batches may see slightly different rows — valid for univariate stats.
('block_sample_from',
 '<<table>> SAMPLE BLOCK(<<pct>>)',
 '<<table>> TABLESAMPLE SYSTEM (<<pct>> PERCENT)',
 NULL,
 '<<table>> TABLESAMPLE SYSTEM (<<pct>>)',
 NULL,
 NULL,
 0, 0, 'B'),

-- Subquery alias: Oracle forbids AS keyword in FROM clause table aliases
('subquery_alias',
 '(<<sql>>) <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 '(<<sql>>) AS <<alias>>',
 0, 0, 'A'),

-- Row limiting
('top_n_clause',
 'FETCH FIRST <<n>> ROWS ONLY',
 'LIMIT <<n>>',
 'LIMIT <<n>>',
 'LIMIT <<n>>',
 'LIMIT <<n>>',
 'LIMIT <<n>>',
 0, 0, 'A'),

-- Random ordering for SW micro-sample
('random_order',
 'DBMS_RANDOM.VALUE',
 'RAND()',
 'RAND()',
 'RANDOM()',
 'RAND()',
 'RANDOM()',
 0, 0, 'A'),

-- Regex match predicate
('regexp_match',
 'REGEXP_LIKE(<<col>>,''<<pattern>>'')',
 'REGEXP_CONTAINS(<<col>>,r''<<pattern>>'')',
 '<<col>> REGEXP ''<<pattern>>''',
 '<<col>> ~ ''<<pattern>>''',
 '<<col>> REGEXP ''<<pattern>>''',
 'REGEXP_LIKE(<<col>>,''<<pattern>>'')',
 0, 0, 'A'),

-- Date validation count: how many rows parse as a valid date with the given format
('date_valid_count',
 'SUM(VALIDATE_CONVERSION(<<col>> AS DATE,''<<date_fmt>>''))',
 'COUNTIF(SAFE.PARSE_DATE(''<<date_fmt>>'',<<col>>) IS NOT NULL)',
 'SUM(CASE WHEN STR_TO_DATE(<<col>>,''<<date_fmt>>'') IS NOT NULL THEN 1 ELSE 0 END)',
 NULL,
 NULL,
 NULL,
 0, 0, 'A');


-- ==============================================================================
-- 2. STAT UI MAP
-- ==============================================================================

INSERT INTO stat_ui_map (ui_label, stat_key, applies_to) VALUES
('Empty Count',          'empty_count',          'all'),
('Distinct Count',       'distinct_count',        'all'),
('Exact Distinct Count', 'exact_distinct_count',  'all'),
('Zero Count',           'zero_count',            'numeric'),
('Positive Count',       'positive_count',        'numeric'),
('Negative Count',       'negative_count',        'numeric'),
('Min',                  'min_val',               'numeric'),
('Max',                  'max_val',               'numeric'),
('Mean',                 'mean_val',              'numeric'),
('Std Dev',              'stddev_val',            'numeric'),
('Median',               'median_val',            'numeric'),
('Skewness',             'skewness',              'numeric'),
('Kurtosis',             'kurtosis',              'numeric'),
('P25',                  'p25',                   'numeric'),
('P75',                  'p75',                   'numeric'),
('P90',                  'p90',                   'numeric'),
('P95',                  'p95',                   'numeric'),
('P99',                  'p99',                   'numeric'),
('Box Plot',             'box_plot',              'numeric'),
('Histogram',            'histogram',             'numeric'),
('Min Length',           'min_length',            'string'),
('Max Length',           'max_length',            'string'),
('Distribution',         'cast_to_string',        'all'),
('Pattern Distribution', 'pattern_mask',          'string'),
('Shapiro-Wilk',         'shapiro_wilk',          'numeric');


-- ==============================================================================
-- 3. STAT PACKS
-- ==============================================================================

INSERT INTO stat_packs (pack_name, display_name, description, cost_class, pass_groups, sort_order) VALUES
('BASIC',    'Basic Profile',
 'Null count, min, max, approx distinct, mean. Full-table scan only. Always fast regardless of table size.',
 'LOW', ARRAY['A'], 1),
('STANDARD', 'Standard Profile',
 'Adds stddev, percentiles, skewness, kurtosis, value distribution. Uses sampling on tables > 1M rows.',
 'MEDIUM', ARRAY['A','B'], 2),
('ADVANCED', 'Advanced Profile',
 'Adds histograms, exact distinct, P99, regex patterns, PSI drift. Gated by max_advanced_columns limit.',
 'HIGH', ARRAY['A','B','C'], 3);

-- BASIC pack contents
INSERT INTO stat_pack_contents (pack_name, stat_key) VALUES
('BASIC','empty_count'),
('BASIC','distinct_count'),
('BASIC','min_val'),
('BASIC','max_val'),
('BASIC','mean_val'),
('BASIC','min_length'),
('BASIC','max_length');

-- STANDARD = BASIC + distributional
INSERT INTO stat_pack_contents (pack_name, stat_key)
    SELECT 'STANDARD', stat_key FROM stat_pack_contents WHERE pack_name = 'BASIC';
INSERT INTO stat_pack_contents (pack_name, stat_key) VALUES
('STANDARD','stddev_val'),
('STANDARD','zero_count'),
('STANDARD','positive_count'),
('STANDARD','negative_count'),
('STANDARD','median_val'),
('STANDARD','skewness'),
('STANDARD','kurtosis'),
('STANDARD','p25'),
('STANDARD','p75'),
('STANDARD','p95'),
('STANDARD','cast_to_string');

-- ADVANCED = STANDARD + heavy stats
INSERT INTO stat_pack_contents (pack_name, stat_key)
    SELECT 'ADVANCED', stat_key FROM stat_pack_contents WHERE pack_name = 'STANDARD';
INSERT INTO stat_pack_contents (pack_name, stat_key) VALUES
('ADVANCED','exact_distinct_count'),
('ADVANCED','p90'),
('ADVANCED','p99'),
('ADVANCED','box_plot'),
('ADVANCED','histogram'),
('ADVANCED','pattern_mask'),
('ADVANCED','shapiro_wilk');


-- ==============================================================================
-- 4. CARDINALITY RESTRICTIONS
-- ==============================================================================

INSERT INTO stat_cardinality_restrictions (cardinality_class, stat_key, restriction_type, reason_template) VALUES
-- PRE_PK / PRIMARY_KEY: block all distributional stats
('PRE_PK','p25',             'BLOCK','Primary key — percentiles are meaningless for unique identifiers'),
('PRE_PK','median_val',      'BLOCK','Primary key — median has no business meaning for a unique ID'),
('PRE_PK','p75',             'BLOCK','Primary key — percentiles are meaningless for unique identifiers'),
('PRE_PK','p90',             'BLOCK','Primary key — percentiles are meaningless for unique identifiers'),
('PRE_PK','p95',             'BLOCK','Primary key — percentiles are meaningless for unique identifiers'),
('PRE_PK','p99',             'BLOCK','Primary key — percentiles are meaningless for unique identifiers'),
('PRE_PK','box_plot',        'BLOCK','Primary key — box plots are meaningless for unique identifiers'),
('PRE_PK','histogram',       'BLOCK','Primary key — use min/max instead'),
('PRE_PK','cast_to_string',  'BLOCK','Primary key — value distribution is trivially flat (all unique)'),
('PRE_PK','pattern_mask',    'BLOCK','Primary key — pattern distribution is trivially flat'),
('PRE_PK','skewness',        'WARN', 'Primary key — skewness reflects ID generation pattern, not data'),
('PRE_PK','kurtosis',        'WARN', 'Primary key — kurtosis reflects ID generation pattern, not data'),
('PRE_PK','exact_distinct_count','WARN','Primary key — distinct count equals row count; use COUNT(*) instead'),
('PRE_UNIQUE','p25',         'BLOCK','Unique column — top-N distribution is trivially flat'),
('PRE_UNIQUE','median_val',  'BLOCK','Unique column — median rarely meaningful for unique values'),
('PRE_UNIQUE','p75',         'BLOCK','Unique column — percentiles rarely meaningful for unique values'),
('PRE_UNIQUE','cast_to_string','BLOCK','Unique column — top-10 frequency is trivially flat'),
('PRE_UNIQUE','pattern_mask','WARN', 'Unique column — pattern distribution may still be useful for format validation'),
('PRIMARY_KEY','p25',        'BLOCK','Profiled as PRIMARY_KEY cardinality (>95%% distinct) — percentiles meaningless'),
('PRIMARY_KEY','median_val', 'BLOCK','Profiled as PRIMARY_KEY cardinality — median meaningless'),
('PRIMARY_KEY','p75',        'BLOCK','Profiled as PRIMARY_KEY cardinality — percentiles meaningless'),
('PRIMARY_KEY','p90',        'BLOCK','Profiled as PRIMARY_KEY cardinality — percentiles meaningless'),
('PRIMARY_KEY','p95',        'BLOCK','Profiled as PRIMARY_KEY cardinality — percentiles meaningless'),
('PRIMARY_KEY','p99',        'BLOCK','Profiled as PRIMARY_KEY cardinality — percentiles meaningless'),
('PRIMARY_KEY','box_plot',   'BLOCK','Profiled as PRIMARY_KEY cardinality'),
('PRIMARY_KEY','histogram',  'BLOCK','Profiled as PRIMARY_KEY cardinality — use min/max instead'),
('PRIMARY_KEY','cast_to_string','BLOCK','Profiled as PRIMARY_KEY — distribution is trivially flat'),
('PRIMARY_KEY','pattern_mask','BLOCK','Profiled as PRIMARY_KEY — pattern distribution is trivially flat'),
('HIGH_CARDINALITY','cast_to_string','BLOCK','High cardinality (>10%% distinct) — top-N frequency is not meaningful'),
('HIGH_CARDINALITY','pattern_mask','WARN','High cardinality — pattern GROUP BY may be slow'),
('HIGH_CARDINALITY','exact_distinct_count','WARN','High cardinality — exact COUNT(DISTINCT) will be expensive');


-- ==============================================================================
-- 5. COST CONFIG
-- ==============================================================================

INSERT INTO stat_cost_config (config_key, config_value, description) VALUES
('max_advanced_columns_per_run',  25,  'Hard cap on ADVANCED pack columns per run'),
('max_standard_columns_per_run',  200, 'Hard cap on STANDARD pack columns (Oracle SELECT alias limit)'),
('warn_advanced_columns',         10,  'Soft warning threshold for ADVANCED columns'),
('warn_standard_columns',         100, 'Soft warning threshold for STANDARD columns'),
('batch_size_pass1',              50,  'Columns per Pass-1 JDBC batch'),
('batch_size_pass2',              10,  'Columns per Pass-2 sampled batch (smaller: percentiles heavier)'),
('histogram_default_buckets',     20,  'Default WIDTH_BUCKET count for histograms'),
('target_sample_rows',            1000000, 'Target sample size for Pass 2'),
('min_sample_rows',               50000,   'Min sample below which a warning is issued'),
('oracle_max_aliases_per_select', 900, 'Safety ceiling below Oracle 1000-expression limit'),
('distribution_cardinality_cap',  50000,'Skip distribution query if distinct_count exceeds this'),
('categorical_threshold',         1000, 'distinct < this → eligible for Pass 3 distribution'),
('primary_key_ratio',             0.95, 'distinct/total > this → PRIMARY_KEY class'),
('high_cardinality_ratio',        0.10, 'distinct/total > this → HIGH_CARDINALITY class');


-- ==============================================================================
-- 6. TYPE INFERENCE RULES
-- ==============================================================================

INSERT INTO inferred_type_rules
    (priority, structural_pattern, semantic_type, requires_date_val,
     oracle_date_fmt, bq_date_fmt, mysql_date_fmt, python_date_fmt,
     pattern_regex, description)
VALUES
(1,  'NN-NN-NNNN','DD-MM-YYYY',TRUE,'DD-MM-YYYY','%d-%m-%Y','%d-%m-%Y','%d-%m-%Y','^[0-9]{2}-[0-9]{2}-[0-9]{4}$','DMY dash-delimited'),
(2,  'NN-NN-NNNN','MM-DD-YYYY',TRUE,'MM-DD-YYYY','%m-%d-%Y','%m-%d-%Y','%m-%d-%Y','^[0-9]{2}-[0-9]{2}-[0-9]{4}$','MDY dash-delimited'),
(3,  'NNNN-NN-NN','YYYY-MM-DD',TRUE,'YYYY-MM-DD','%Y-%m-%d','%Y-%m-%d','%Y-%m-%d','^[0-9]{4}-[0-9]{2}-[0-9]{2}$','ISO 8601'),
(4,  'NN/NN/NNNN','DD/MM/YYYY',TRUE,'DD/MM/YYYY','%d/%m/%Y','%d/%m/%Y','%d/%m/%Y','^[0-9]{2}/[0-9]{2}/[0-9]{4}$','European slash'),
(5,  'NN/NN/NNNN','MM/DD/YYYY',TRUE,'MM/DD/YYYY','%m/%d/%Y','%m/%d/%Y','%m/%d/%Y','^[0-9]{2}/[0-9]{2}/[0-9]{4}$','US slash'),
(6,  'NNNN/NN/NN','YYYY/MM/DD',TRUE,'YYYY/MM/DD','%Y/%m/%d','%Y/%m/%d','%Y/%m/%d','^[0-9]{4}/[0-9]{2}/[0-9]{2}$','ISO slash'),
(7,  'NN.NN.NNNN','DD.MM.YYYY',TRUE,'DD.MM.YYYY','%d.%m.%Y','%d.%m.%Y','%d.%m.%Y','^[0-9]{2}\.[0-9]{2}\.[0-9]{4}$','German dot'),
(8,  'NNNN-NN-NN NN:NN:NN','YYYY-MM-DD HH:MI:SS',TRUE,'YYYY-MM-DD HH24:MI:SS','%Y-%m-%d %H:%M:%S','%Y-%m-%d %H:%i:%s','%Y-%m-%d %H:%M:%S','^[0-9]{4}-[0-9]{2}-[0-9]{2} [0-9]{2}:[0-9]{2}:[0-9]{2}$','ISO datetime'),
(20, 'REGEX:^N+$',            'INTEGER',     FALSE,NULL,NULL,NULL,NULL,NULL,'All digits'),
(21, 'REGEX:^N+\.N+$',        'DECIMAL',     FALSE,NULL,NULL,NULL,NULL,NULL,'Decimal dot'),
(22, 'REGEX:^N+,N+$',         'DECIMAL',     FALSE,NULL,NULL,NULL,NULL,NULL,'Decimal comma'),
(23, 'REGEX:^A+$',            'ALPHA',       FALSE,NULL,NULL,NULL,NULL,NULL,'All alpha'),
(24, 'REGEX:^[AN]+$',         'ALPHANUMERIC',FALSE,NULL,NULL,NULL,NULL,NULL,'Alphanumeric'),
(25, 'REGEX:^[AN]{8}-[AN]{4}-[AN]{4}-[AN]{4}-[AN]{12}$','UUID',FALSE,NULL,NULL,NULL,NULL,'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$','UUID/GUID'),
(26, 'REGEX:.*@.*',           'EMAIL',       FALSE,NULL,NULL,NULL,NULL,'^[^@\s]+@[^@\s]+\.[^@\s]+$','Email'),
(27, 'REGEX:^[N\-\+\(\) ]+$','PHONE',        FALSE,NULL,NULL,NULL,NULL,'^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$','Phone');
