-- ==============================================================================
-- 03_bq_schema.sql — BigQuery Analytics Layer
-- ==============================================================================
-- Run in your central GCP project.
-- Tables are partitioned by ingested_at and clustered for efficient analytics.

CREATE SCHEMA IF NOT EXISTS `{project}.profiler_results`
OPTIONS (location = 'US');

CREATE TABLE IF NOT EXISTS `{project}.profiler_results.profiler_metrics` (
    run_id             STRING    NOT NULL,
    team_id            STRING,
    source_platform    STRING,
    source_schema      STRING,
    target_table       STRING,
    column_name        STRING    NOT NULL,
    inferred_type      STRING,
    cardinality_class  STRING,
    passes_executed    STRING,
    empty_count        INT64,
    distinct_count     INT64,
    exact_distinct     INT64,
    valid_count        INT64,
    zero_count         INT64,
    positive_count     INT64,
    negative_count     INT64,
    min_length         INT64,
    max_length         INT64,
    min_val            STRING,
    max_val            STRING,
    mean_val           FLOAT64,
    median_val         FLOAT64,
    stddev_val         FLOAT64,
    skewness           FLOAT64,
    kurtosis           FLOAT64,
    q1_val             FLOAT64,
    q3_val             FLOAT64,
    p90_val            FLOAT64,
    p95_val            FLOAT64,
    p99_val            FLOAT64,
    iqr_val            FLOAT64,
    outlier_lower      FLOAT64,
    outlier_upper      FLOAT64,
    shapiro_wilk       FLOAT64,
    p_value            FLOAT64,
    sw_sample_size     INT64,
    psi_score          FLOAT64,
    psi_severity       STRING,
    baseline_run_id    STRING,
    ingested_at        TIMESTAMP NOT NULL
)
PARTITION BY DATE(ingested_at)
CLUSTER BY source_platform, target_table, column_name;

CREATE TABLE IF NOT EXISTS `{project}.profiler_results.profiler_distributions` (
    run_id          STRING    NOT NULL,
    column_name     STRING    NOT NULL,
    value_string    STRING,
    frequency_count INT64,
    percentage      FLOAT64,
    ingested_at     TIMESTAMP NOT NULL
)
PARTITION BY DATE(ingested_at)
CLUSTER BY run_id, column_name;

CREATE TABLE IF NOT EXISTS `{project}.profiler_results.profiler_histograms` (
    run_id           STRING    NOT NULL,
    column_name      STRING    NOT NULL,
    bucket_index     INT64,
    bucket_lower     FLOAT64,
    bucket_upper     FLOAT64,
    bucket_label     STRING,
    frequency_count  INT64,
    percentage       FLOAT64,
    baseline_aligned BOOL,
    ingested_at      TIMESTAMP NOT NULL
)
PARTITION BY DATE(ingested_at)
CLUSTER BY run_id, column_name;

CREATE TABLE IF NOT EXISTS `{project}.profiler_results.profiler_patterns` (
    run_id          STRING    NOT NULL,
    column_name     STRING    NOT NULL,
    pattern_mask    STRING,
    frequency_count INT64,
    percentage      FLOAT64,
    ingested_at     TIMESTAMP NOT NULL
)
PARTITION BY DATE(ingested_at)
CLUSTER BY run_id, column_name;

CREATE TABLE IF NOT EXISTS `{project}.profiler_results.profiler_gating` (
    run_id                STRING    NOT NULL,
    column_name           STRING    NOT NULL,
    total_rows            INT64,
    approx_distinct       INT64,
    null_count            INT64,
    cardinality_class     STRING,
    pass2_eligible        BOOL,
    pass2_skip_reason     STRING,
    pass3_eligible        BOOL,
    pass3_skip_reason     STRING,
    pass4_sw_eligible     BOOL,
    pass4_psi_eligible    BOOL,
    pass4_psi_skip_reason STRING,
    ingested_at           TIMESTAMP NOT NULL
)
PARTITION BY DATE(ingested_at)
CLUSTER BY run_id;
