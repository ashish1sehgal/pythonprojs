"""
psi_calculator.py — PSI (Population Stability Index) and Shapiro-Wilk.
Both run in Python on the driver — no Spark tasks, no JDBC.

PSI protocol:
  Baseline histogram bucket boundaries are loaded BEFORE Pass-1 runs.
  Pass-3 histogram queries use the baseline's min/max for WIDTH_BUCKET,
  guaranteeing identical bin boundaries for valid PSI comparison.
  PSI = Σ (actual% - expected%) × ln(actual% / expected%)
  Thresholds: <0.10 STABLE | 0.10-0.25 MODERATE | >0.25 UNSTABLE

Shapiro-Wilk:
  Runs on a 2000-row sub-sample pulled from the Pass-2 sample.
  scipy.stats.shapiro is valid for n=8..5000.
"""
import math, logging
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import psycopg2
from scipy import stats as scipy_stats

log = logging.getLogger("psi_calculator")

PSI_STABLE    = 0.10
PSI_MODERATE  = 0.25
PSI_EPSILON   = 1e-6
SW_MIN        = 8
SW_MAX_SAMPLE = 2000

@dataclass
class PSIResult:
    column_name: str; psi_score: float; psi_severity: str
    baseline_run_id: str; n_bins: int; note: Optional[str] = None

@dataclass
class ShapiroResult:
    column_name: str; statistic: float; p_value: float
    sample_size: int; is_normal: bool

class BaselineHistogramLoader:
    @staticmethod
    def load(pg_creds: dict, baseline_run_id: str) -> Dict[str, List[Dict]]:
        if not baseline_run_id: return {}
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as cur:
                cur.execute("""SELECT column_name,bucket_index,bucket_lower,bucket_upper,frequency_count
                               FROM profiler_run_histograms WHERE run_id=%s ORDER BY column_name,bucket_index""",
                            (baseline_run_id,))
                result = {}
                for col, idx, lo, hi, freq in cur.fetchall():
                    result.setdefault(col,[]).append({"bucket_index":idx,"bucket_lower":float(lo) if lo else None,
                                                     "bucket_upper":float(hi) if hi else None,"frequency_count":int(freq)})
        finally: conn.close()
        log.info("Loaded baseline histograms for %d columns from %s", len(result), baseline_run_id)
        return result

    @staticmethod
    def min_max_for(hist: List[Dict]) -> Tuple[Optional[float],Optional[float]]:
        if not hist: return None, None
        return hist[0]["bucket_lower"], hist[-1]["bucket_upper"]

class PSICalculator:
    @staticmethod
    def compute(curr: List[Dict], base: List[Dict], baseline_run_id: str, col_name: str) -> Optional[PSIResult]:
        if not curr or not base: return None
        if len(curr) != len(base):
            return PSIResult(col_name, float("nan"), "INVALID", baseline_run_id, 0,
                             f"Bucket count mismatch: current={len(curr)}, baseline={len(base)}")
        curr_f = [b["frequency_count"] for b in curr]
        base_f = [b["frequency_count"] for b in base]
        n_c = sum(curr_f) or 1; n_b = sum(base_f) or 1
        psi = sum((max(c/n_c, PSI_EPSILON) - max(e/n_b, PSI_EPSILON)) *
                  math.log(max(c/n_c, PSI_EPSILON) / max(e/n_b, PSI_EPSILON))
                  for c, e in zip(curr_f, base_f))
        severity = "STABLE" if psi < PSI_STABLE else ("MODERATE" if psi < PSI_MODERATE else "UNSTABLE")
        return PSIResult(col_name, psi, severity, baseline_run_id, len(curr_f))

class ShapiroWilkRunner:
    @staticmethod
    def run(sample_arrays: Dict[str, Any], profiles: Dict) -> Dict[str, ShapiroResult]:
        results = {}
        for col_name, arr in sample_arrays.items():
            p = profiles.get(col_name)
            if not p or not p.run_pass4_sw: continue
            if len(arr) < SW_MIN: continue
            if len(arr) > SW_MAX_SAMPLE:
                import numpy as np
                arr = np.random.default_rng(42).choice(arr, SW_MAX_SAMPLE, replace=False)
            try:
                stat, pval = scipy_stats.shapiro(arr)
                results[col_name] = ShapiroResult(col_name, float(stat), float(pval), len(arr), pval > 0.05)
            except Exception as e:
                log.error("Shapiro-Wilk failed for %s: %s", col_name, e)
        log.info("SW complete: %d tested, %d normal", len(results), sum(1 for r in results.values() if r.is_normal))
        return results
