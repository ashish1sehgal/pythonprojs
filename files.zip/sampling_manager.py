"""
sampling_manager.py — Builds a single SamplingClause shared across ALL Pass-2 batches.
Deterministic hash sampling guarantees identical rows in all batches.
"""
import json, logging, math
from dataclasses import dataclass
from typing import List, Optional, Tuple
import psycopg2
from stat_registry import StatTemplateRegistry

log = logging.getLogger("sampling_manager")

@dataclass
class SamplingClause:
    where_clause:     Optional[str]
    from_suffix:      Optional[str]
    strategy:         str
    is_deterministic: bool
    estimated_rows:   int
    bucket_count:     int
    warning:          str = ""

    def inject_into_sql(self, sql: str, table_name: str) -> str:
        if self.from_suffix:
            return sql.replace(f"FROM {table_name}", f"FROM {table_name} {self.from_suffix}", 1)
        if self.where_clause:
            return sql + ("\nAND   " if "WHERE" in sql.upper() else "\nWHERE ") + self.where_clause
        return sql

class SamplingManager:
    def __init__(self, pg_creds: dict, registry: StatTemplateRegistry, config: dict):
        self.registry = registry
        self.config   = config
        cfg = self._load_cfg(pg_creds)
        self.TARGET = int(cfg.get("target_sample_rows", 1_000_000))
        self.MIN    = int(cfg.get("min_sample_rows",       50_000))

    def _load_cfg(self, pg_creds):
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as c:
                c.execute("SELECT config_key,config_value FROM stat_cost_config"); return dict(c.fetchall())
        finally: conn.close()

    def resolve(self, total_rows: int, source_table: str, source_conn=None) -> SamplingClause:
        mode    = self.config.get("sampling_mode", "DETERMINISTIC")
        pct     = min(100.0, self.TARGET / max(total_rows, 1) * 100)
        bucket_count = max(1, round(100.0 / pct)) if pct < 100 else 1
        est_rows = round(total_rows / bucket_count)
        if est_rows < self.MIN and total_rows > self.MIN:
            bucket_count = max(1, math.floor(total_rows / self.MIN))
            est_rows = round(total_rows / bucket_count)
        if mode == "BLOCK":
            return self._block_clause(source_table, pct, est_rows, bucket_count)
        pk_cols = json.loads(self.config["pk_cols"]) if self.config.get("pk_cols") else []
        pk_expr, is_det = self._resolve_pk(pk_cols, source_table, source_conn)
        return self._deterministic_clause(pk_expr, bucket_count, est_rows, is_det)

    def _deterministic_clause(self, pk_expr, bucket_count, est_rows, is_det):
        where_expr = self.registry.render_or_none("deterministic_sample_where",
                                                   pk_col=pk_expr, bucket_count=bucket_count)
        if not where_expr:
            log.warning("No deterministic_sample_where for platform %s — full table", self.registry.platform)
            return SamplingClause(None, None, "FULL_TABLE", True, est_rows, 1, "No sampling available")
        warn = "" if is_det else "ROW_NUMBER() fallback — not reproducible across runs. Set pk_cols in config."
        log.info("Sampling: DETERMINISTIC | pk=%s | bucket=%d | est_rows≈%d | det=%s", pk_expr, bucket_count, est_rows, is_det)
        return SamplingClause(where_expr, None, "DETERMINISTIC", is_det, est_rows, bucket_count, warn)

    def _block_clause(self, table, pct, est_rows, bucket_count):
        sfx = self.registry.render_or_none("block_sample_from", table=table, pct=round(pct,6))
        if not sfx:
            log.warning("No block sampling for %s — falling back to DETERMINISTIC", self.registry.platform)
            return self._deterministic_clause(self._rownum_fallback(), bucket_count, est_rows, False)
        suffix_only = sfx.replace(f"{table} ", "", 1)
        warn = "BLOCK sampling: different batches may see slightly different rows (valid for univariate stats)"
        log.info("Sampling: BLOCK | pct=%.4f%% | est_rows≈%d", pct, est_rows)
        return SamplingClause(None, suffix_only, "BLOCK", False, est_rows, bucket_count, warn)

    def _resolve_pk(self, pk_cols: List[str], source_table: str, source_conn) -> Tuple[str, bool]:
        if pk_cols:
            return self._build_concat(pk_cols), True
        if source_conn:
            detected = self._detect_pk(source_table, source_conn)
            if detected: return self._build_concat(detected), True
        return self._rownum_fallback(), False

    def _build_concat(self, cols: List[str]) -> str:
        if len(cols) == 1: return cols[0]
        p = self.registry.platform
        if p == "oracle":  return " || '|' || ".join(cols)
        if p == "postgres": return " || '|' || ".join(f"{c}::TEXT" for c in cols)
        return "CONCAT(" + ",'|',".join(cols) + ")"

    def _detect_pk(self, table: str, conn) -> List[str]:
        parts = table.split("."); t = parts[-1]; schema = parts[0] if len(parts) > 1 else None
        try:
            with conn.cursor() as cur:
                if self.registry.platform == "oracle":
                    cur.execute("SELECT col.column_name FROM all_constraints con JOIN all_cons_columns col ON con.constraint_name=col.constraint_name AND con.owner=col.owner WHERE con.constraint_type='P' AND con.table_name=UPPER(%s) ORDER BY col.position", (t,))
                else:
                    sql = "SELECT kcu.column_name FROM information_schema.table_constraints tc JOIN information_schema.key_column_usage kcu ON tc.constraint_name=kcu.constraint_name AND tc.table_schema=kcu.table_schema AND tc.table_name=kcu.table_name WHERE tc.constraint_type='PRIMARY KEY' AND tc.table_name=%s"
                    params = [t]
                    if schema: sql += " AND tc.table_schema=%s"; params.append(schema)
                    sql += " ORDER BY kcu.ordinal_position"
                    cur.execute(sql, params)
                return [r[0] for r in cur.fetchall()]
        except Exception as e:
            log.debug("PK detection failed: %s", e); return []

    def _rownum_fallback(self) -> str:
        return "ROW_NUMBER() OVER (ORDER BY NULL)" if self.registry.platform in ("oracle","postgres","bigquery") else "ROW_NUMBER() OVER ()"
