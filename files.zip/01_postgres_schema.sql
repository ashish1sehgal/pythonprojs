-- ==============================================================================
-- 01_postgres_schema.sql
-- Enterprise Data Profiler — Complete Postgres Schema
-- ==============================================================================

-- ==============================================================================
-- GOVERNANCE & CONFIGURATION
-- ==============================================================================

CREATE TABLE IF NOT EXISTS profiler_table_registry (
    source_platform   VARCHAR(50)  NOT NULL,
    database_schema   VARCHAR(255) NOT NULL,
    target_table      VARCHAR(255) NOT NULL,
    current_version   INT          NOT NULL DEFAULT 1,
    first_profiled_at TIMESTAMPTZ  DEFAULT NOW(),
    last_updated_at   TIMESTAMPTZ  DEFAULT NOW(),
    PRIMARY KEY (source_platform, database_schema, target_table)
);

CREATE TABLE IF NOT EXISTS profiler_configs (
    config_id         SERIAL PRIMARY KEY,
    source_platform   VARCHAR(50),
    database_schema   VARCHAR(255),
    target_table      VARCHAR(255),
    version_number    INT          NOT NULL,
    version_comment   TEXT,
    sampling_mode     VARCHAR(20)  NOT NULL DEFAULT 'DETERMINISTIC',
    -- DETERMINISTIC: hash WHERE clause — same rows all batches
    -- BLOCK: TABLESAMPLE — faster on >50B rows, slightly different rows per batch
    pk_cols           JSONB,
    -- JSON array of PK column names for deterministic hash sampling
    -- e.g. ["ORDER_ID"] or ["TENANT_ID","ORDER_ID"]
    sampling_value    NUMERIC,
    cron_schedule     VARCHAR(100),
    confidence_level  NUMERIC(5,2) DEFAULT 95.00,
    baseline_run_id   UUID,        -- run to compare PSI against
    author            VARCHAR(255),
    created_at        TIMESTAMPTZ  DEFAULT NOW(),
    FOREIGN KEY (source_platform, database_schema, target_table)
        REFERENCES profiler_table_registry(source_platform, database_schema, target_table)
        ON DELETE CASCADE,
    UNIQUE (source_platform, database_schema, target_table, version_number),
    CHECK (sampling_mode IN ('DETERMINISTIC','BLOCK'))
);

CREATE TABLE IF NOT EXISTS profiler_config_columns (
    column_config_id          SERIAL PRIMARY KEY,
    config_id                 INT REFERENCES profiler_configs(config_id) ON DELETE CASCADE,
    column_name               VARCHAR(255) NOT NULL,
    data_type                 VARCHAR(100) NOT NULL,
    is_active                 BOOLEAN      DEFAULT TRUE,
    stat_pack                 VARCHAR(20)  NOT NULL DEFAULT 'BASIC',
    -- BASIC | STANDARD | ADVANCED
    deselected_stats          TEXT[],
    -- Stat keys the user explicitly removed from the pack (deselection mask)
    -- NULL/empty = use all stats in pack
    override_confidence_level NUMERIC(5,2) NULL,
    derivation_formula        TEXT,
    schema_cardinality_class  VARCHAR(30),
    -- PRE_PK | PRE_UNIQUE | PRE_HIGH | PRE_LOW | PRE_INDEXED | PRE_UNKNOWN
    schema_classified_at      TIMESTAMPTZ,
    runtime_cardinality_class VARCHAR(30),
    -- Set from profiler_run_metrics after first run; takes precedence over schema
    percentile_restricted     BOOLEAN      NOT NULL DEFAULT FALSE,
    restriction_reason        TEXT,
    cost_score_contribution   NUMERIC      DEFAULT 0,
    UNIQUE (config_id, column_name),
    CHECK (stat_pack IN ('BASIC','STANDARD','ADVANCED'))
);

-- ==============================================================================
-- STAT GOVERNANCE TABLES
-- ==============================================================================

CREATE TABLE IF NOT EXISTS stat2sql (
    stat         TEXT PRIMARY KEY,
    oracle       TEXT,
    bigquery     TEXT,
    mysql        TEXT,
    postgres     TEXT,
    singlestore  TEXT,
    sql          TEXT,          -- ANSI fallback
    cost_tier    INT  NOT NULL DEFAULT 0,
    cost_weight  NUMERIC NOT NULL DEFAULT 1,
    pass_group   CHAR(1) NOT NULL DEFAULT 'A'
    -- A=Pass1 full scan, B=Pass2 sampled, C=Pass3 group-by
);

CREATE TABLE IF NOT EXISTS stat_ui_map (
    ui_label   TEXT PRIMARY KEY,
    stat_key   TEXT NOT NULL REFERENCES stat2sql(stat),
    applies_to TEXT NOT NULL   -- 'numeric' | 'string' | 'all'
);

CREATE TABLE IF NOT EXISTS stat_packs (
    pack_name    VARCHAR(20) PRIMARY KEY,
    display_name TEXT NOT NULL,
    description  TEXT NOT NULL,
    cost_class   VARCHAR(10) NOT NULL,
    pass_groups  TEXT[] NOT NULL,
    sort_order   INT  NOT NULL
);

CREATE TABLE IF NOT EXISTS stat_pack_contents (
    pack_name  VARCHAR(20) NOT NULL REFERENCES stat_packs(pack_name) ON DELETE CASCADE,
    stat_key   TEXT        NOT NULL REFERENCES stat2sql(stat),
    PRIMARY KEY (pack_name, stat_key)
);

CREATE TABLE IF NOT EXISTS stat_cardinality_restrictions (
    cardinality_class VARCHAR(30) NOT NULL,
    stat_key          TEXT        NOT NULL REFERENCES stat2sql(stat),
    restriction_type  VARCHAR(10) NOT NULL,  -- BLOCK | WARN
    reason_template   TEXT        NOT NULL,
    PRIMARY KEY (cardinality_class, stat_key)
);

CREATE TABLE IF NOT EXISTS stat_cost_config (
    config_key   TEXT PRIMARY KEY,
    config_value NUMERIC NOT NULL,
    description  TEXT
);

-- ==============================================================================
-- TYPE INFERENCE
-- ==============================================================================

CREATE TABLE IF NOT EXISTS inferred_type_rules (
    rule_id            SERIAL PRIMARY KEY,
    priority           INT  NOT NULL,
    structural_pattern TEXT NOT NULL,
    semantic_type      TEXT NOT NULL,
    requires_date_val  BOOLEAN NOT NULL DEFAULT FALSE,
    oracle_date_fmt    TEXT,
    bq_date_fmt        TEXT,
    mysql_date_fmt     TEXT,
    python_date_fmt    TEXT,
    pattern_regex      TEXT,
    description        TEXT
);

CREATE INDEX IF NOT EXISTS idx_type_rules_pattern
    ON inferred_type_rules (structural_pattern, priority);

-- ==============================================================================
-- JOB EXECUTION & BATCH ORCHESTRATION
-- ==============================================================================

CREATE TABLE IF NOT EXISTS profiler_runs (
    run_id         UUID        PRIMARY KEY,
    config_id      INT         REFERENCES profiler_configs(config_id),
    team_id        VARCHAR(100),
    execution_mode VARCHAR(50),   -- MANUAL | SCHEDULED
    status         VARCHAR(50) NOT NULL,
    -- PENDING | RUNNING | PARTIAL | COMPLETED | FAILED | INGESTED
    data_health_score NUMERIC(5,2),
    gcs_output_prefix TEXT,       -- gs://bucket/runs/{run_id}
    started_at     TIMESTAMPTZ DEFAULT NOW(),
    completed_at   TIMESTAMPTZ,
    ingested_at    TIMESTAMPTZ   -- when Dataflow finished writing
);

CREATE TABLE IF NOT EXISTS profiler_run_batches (
    batch_id      SERIAL PRIMARY KEY,
    run_id        UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    batch_number  INT    NOT NULL,
    pass_number   INT    NOT NULL DEFAULT 1,
    status        VARCHAR(50) NOT NULL,
    error_message TEXT,
    retry_count   INT    DEFAULT 0,
    started_at    TIMESTAMPTZ,
    completed_at  TIMESTAMPTZ,
    UNIQUE (run_id, batch_number, pass_number)
);

CREATE TABLE IF NOT EXISTS profiler_run_column_tasks (
    run_id           UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name      VARCHAR(255) NOT NULL,
    batch_id         INT    REFERENCES profiler_run_batches(batch_id) ON DELETE CASCADE,
    execution_status VARCHAR(50) NOT NULL,
    error_message    TEXT,
    PRIMARY KEY (run_id, column_name)
);

-- ==============================================================================
-- PROFILING RESULTS
-- ==============================================================================

CREATE TABLE IF NOT EXISTS profiler_run_metrics (
    metric_id          SERIAL PRIMARY KEY,
    run_id             UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name        VARCHAR(255) NOT NULL,
    inferred_type      VARCHAR(50),
    cardinality_class  VARCHAR(30),
    passes_executed    VARCHAR(20),

    -- DATA QUALITY (Pass 1 — full population)
    empty_count        BIGINT,
    distinct_count     BIGINT,      -- approx (HLL)
    exact_distinct     BIGINT,      -- ADVANCED pack only
    valid_count        BIGINT,      -- COUNT(col) non-null; used for CI view
    zero_count         BIGINT,
    positive_count     BIGINT,
    negative_count     BIGINT,

    -- STRING METRICS (Pass 1)
    min_length         INT,
    max_length         INT,

    -- CENTRAL TENDENCY (Pass 1 — full pop; median from Pass 2 sample)
    min_val            TEXT,        -- TEXT for polymorphism
    max_val            TEXT,
    mean_val           NUMERIC,
    median_val         NUMERIC,
    stddev_val         NUMERIC,

    -- DISTRIBUTIONAL (Pass 2 — DB-native on sample)
    skewness           NUMERIC(10,4),
    kurtosis           NUMERIC(10,4),
    q1_val             NUMERIC,     -- P25
    q3_val             NUMERIC,     -- P75
    p90_val            NUMERIC,
    p95_val            NUMERIC,
    p99_val            NUMERIC,
    iqr_val            NUMERIC,     -- q3 - q1 (Python post-query)
    outlier_lower      NUMERIC,     -- q1 - 1.5*iqr
    outlier_upper      NUMERIC,     -- q3 + 1.5*iqr

    -- NORMALITY (Pass 4 — scipy on 2000-row sub-sample from Pass 2 sample)
    shapiro_wilk       NUMERIC(10,4),
    p_value            NUMERIC(10,4),
    sw_sample_size     INT,

    -- DRIFT (Pass 4 — PSI vs baseline)
    psi_score          NUMERIC(10,6),
    psi_severity       VARCHAR(20),  -- STABLE | MODERATE | UNSTABLE
    baseline_run_id    UUID REFERENCES profiler_runs(run_id),

    UNIQUE (run_id, column_name)
);

CREATE TABLE IF NOT EXISTS profiler_run_column_gating (
    gating_id             SERIAL PRIMARY KEY,
    run_id                UUID NOT NULL REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name           TEXT NOT NULL,
    total_rows            BIGINT,
    approx_distinct       BIGINT,
    null_count            BIGINT,
    cardinality_class     VARCHAR(30),
    pass2_eligible        BOOLEAN NOT NULL DEFAULT FALSE,
    pass2_skip_reason     TEXT,
    pass3_eligible        BOOLEAN NOT NULL DEFAULT FALSE,
    pass3_skip_reason     TEXT,
    pass4_sw_eligible     BOOLEAN NOT NULL DEFAULT FALSE,
    pass4_psi_eligible    BOOLEAN NOT NULL DEFAULT FALSE,
    pass4_psi_skip_reason TEXT,
    recorded_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE (run_id, column_name)
);

CREATE TABLE IF NOT EXISTS profiler_run_distributions (
    dist_id         SERIAL PRIMARY KEY,
    run_id          UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name     VARCHAR(255) NOT NULL,
    value_string    TEXT,
    frequency_count BIGINT NOT NULL,
    percentage      NUMERIC(6,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS profiler_run_patterns (
    pattern_id      SERIAL PRIMARY KEY,
    run_id          UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name     VARCHAR(255) NOT NULL,
    pattern_mask    VARCHAR(500) NOT NULL,
    frequency_count BIGINT NOT NULL,
    percentage      NUMERIC(6,2) NOT NULL
);

CREATE TABLE IF NOT EXISTS profiler_run_histograms (
    hist_id         SERIAL PRIMARY KEY,
    run_id          UUID   REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    column_name     TEXT   NOT NULL,
    bucket_index    INT    NOT NULL,
    bucket_lower    NUMERIC,
    bucket_upper    NUMERIC,
    bucket_label    TEXT,
    frequency_count BIGINT NOT NULL,
    percentage      NUMERIC(6,2),
    baseline_aligned BOOLEAN NOT NULL DEFAULT FALSE,
    UNIQUE (run_id, column_name, bucket_index)
);

CREATE TABLE IF NOT EXISTS ai_relationship_suggestions (
    suggestion_id      SERIAL PRIMARY KEY,
    run_id             UUID REFERENCES profiler_runs(run_id) ON DELETE CASCADE,
    child_table        VARCHAR(255) NOT NULL,
    child_column       VARCHAR(255) NOT NULL,
    parent_table       VARCHAR(255) NOT NULL,
    parent_column      VARCHAR(255) NOT NULL,
    overlap_percentage NUMERIC(5,2) NOT NULL,
    match_reasons      TEXT,
    status             VARCHAR(20)  DEFAULT 'PENDING',
    UNIQUE (run_id, child_table, child_column, parent_table, parent_column)
);

-- ==============================================================================
-- CHI-SQUARED LOOKUP FOR STDDEV CI VIEW
-- ==============================================================================

CREATE TABLE IF NOT EXISTS chi2_critical_values (
    df_bucket   BIGINT  NOT NULL,
    alpha_half  NUMERIC NOT NULL,
    chi2_lower  NUMERIC NOT NULL,   -- chi2.ppf(alpha/2, df)
    chi2_upper  NUMERIC NOT NULL,   -- chi2.ppf(1-alpha/2, df)
    PRIMARY KEY (df_bucket, alpha_half)
);

CREATE INDEX IF NOT EXISTS idx_chi2_df_alpha
    ON chi2_critical_values (df_bucket, alpha_half);

-- ==============================================================================
-- INDEXES
-- ==============================================================================

CREATE INDEX IF NOT EXISTS idx_runs_lookup         ON profiler_runs(config_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_metrics_trends      ON profiler_run_metrics(column_name, run_id);
CREATE INDEX IF NOT EXISTS idx_run_dists           ON profiler_run_distributions(run_id, column_name);
CREATE INDEX IF NOT EXISTS idx_run_patterns        ON profiler_run_patterns(run_id, column_name);
CREATE INDEX IF NOT EXISTS idx_histograms_lookup   ON profiler_run_histograms(run_id, column_name);
CREATE INDEX IF NOT EXISTS idx_gating_run          ON profiler_run_column_gating(run_id);
CREATE INDEX IF NOT EXISTS idx_config_cols_pack    ON profiler_config_columns(config_id, stat_pack);

-- ==============================================================================
-- CI VIEW
-- ==============================================================================

CREATE OR REPLACE FUNCTION nearest_chi2_bucket(df BIGINT)
RETURNS BIGINT LANGUAGE sql IMMUTABLE PARALLEL SAFE AS $$
    SELECT df_bucket FROM chi2_critical_values
    ORDER BY ABS(df_bucket - df) LIMIT 1
$$;

CREATE OR REPLACE VIEW profiler_run_metrics_with_ci AS
WITH ctx AS (
    SELECT m.run_id, m.column_name, m.valid_count, m.mean_val, m.stddev_val,
        COALESCE(pcc.override_confidence_level, pc.confidence_level, 95)::NUMERIC AS cl
    FROM   profiler_run_metrics m
    JOIN   profiler_runs    pr  ON pr.run_id    = m.run_id
    JOIN   profiler_configs pc  ON pc.config_id = pr.config_id
    LEFT JOIN profiler_config_columns pcc
           ON pcc.config_id = pr.config_id AND pcc.column_name = m.column_name
),
z AS (
    SELECT *, CASE cl WHEN 90 THEN 1.645 WHEN 95 THEN 1.960 WHEN 99 THEN 2.576 ELSE 1.960 END AS z_score,
              CASE cl WHEN 90 THEN 0.050 WHEN 95 THEN 0.025 WHEN 99 THEN 0.005 ELSE 0.025 END AS alpha_half
    FROM ctx
)
SELECT m.*,
    CASE WHEN z.valid_count > 0 AND z.mean_val IS NOT NULL AND z.stddev_val IS NOT NULL
         THEN z.mean_val - z.z_score * z.stddev_val / SQRT(z.valid_count::NUMERIC) END AS mean_ci_lower,
    CASE WHEN z.valid_count > 0 AND z.mean_val IS NOT NULL AND z.stddev_val IS NOT NULL
         THEN z.mean_val + z.z_score * z.stddev_val / SQRT(z.valid_count::NUMERIC) END AS mean_ci_upper,
    CASE WHEN z.valid_count >= 3 AND z.stddev_val IS NOT NULL AND c.chi2_upper > 0
         THEN z.stddev_val * SQRT((z.valid_count-1)::NUMERIC / c.chi2_upper) END AS stddev_ci_lower,
    CASE WHEN z.valid_count >= 3 AND z.stddev_val IS NOT NULL AND c.chi2_lower > 0
         THEN z.stddev_val * SQRT((z.valid_count-1)::NUMERIC / c.chi2_lower) END AS stddev_ci_upper,
    z.cl AS confidence_level_used, z.z_score, z.alpha_half
FROM profiler_run_metrics m
JOIN z ON z.run_id = m.run_id AND z.column_name = m.column_name
LEFT JOIN chi2_critical_values c
    ON c.df_bucket = nearest_chi2_bucket(GREATEST(z.valid_count - 1, 1))
    AND c.alpha_half = z.alpha_half;

-- ==============================================================================
-- EFFECTIVE STATS VIEW
-- ==============================================================================

CREATE OR REPLACE VIEW effective_column_stats AS
SELECT
    pcc.column_config_id, pcc.config_id, pcc.column_name, pcc.data_type,
    pcc.stat_pack, pcc.is_active, pcc.deselected_stats,
    COALESCE(pcc.runtime_cardinality_class, pcc.schema_cardinality_class, 'PRE_UNKNOWN') AS effective_cardinality_class,
    ARRAY_AGG(DISTINCT spc.stat_key ORDER BY spc.stat_key)
        FILTER (WHERE spc.stat_key IS NOT NULL) AS pack_stat_keys,
    ARRAY_AGG(DISTINCT spc.stat_key ORDER BY spc.stat_key)
        FILTER (WHERE spc.stat_key IS NOT NULL
            AND NOT (spc.stat_key = ANY(COALESCE(pcc.deselected_stats, ARRAY[]::TEXT[])))
            AND NOT EXISTS (
                SELECT 1 FROM stat_cardinality_restrictions r
                WHERE r.cardinality_class = COALESCE(pcc.runtime_cardinality_class, pcc.schema_cardinality_class, 'PRE_UNKNOWN')
                AND r.stat_key = spc.stat_key AND r.restriction_type = 'BLOCK'
            )) AS effective_stat_keys
FROM profiler_config_columns pcc
JOIN stat_pack_contents spc ON spc.pack_name = pcc.stat_pack
WHERE pcc.is_active = TRUE
GROUP BY pcc.column_config_id, pcc.config_id, pcc.column_name, pcc.data_type,
         pcc.stat_pack, pcc.is_active, pcc.deselected_stats,
         pcc.schema_cardinality_class, pcc.runtime_cardinality_class;

-- ==============================================================================
-- COST ESTIMATE VIEW
-- ==============================================================================

CREATE OR REPLACE VIEW cost_estimate_per_config AS
SELECT
    pcc.config_id,
    COUNT(*) FILTER (WHERE pcc.stat_pack = 'BASIC'    AND pcc.is_active) AS basic_count,
    COUNT(*) FILTER (WHERE pcc.stat_pack = 'STANDARD' AND pcc.is_active) AS standard_count,
    COUNT(*) FILTER (WHERE pcc.stat_pack = 'ADVANCED' AND pcc.is_active) AS advanced_count,
    COUNT(*) FILTER (WHERE pcc.is_active)                                 AS active_columns,
    ROUND(100.0 * COUNT(*) FILTER (WHERE pcc.stat_pack='ADVANCED' AND pcc.is_active)
          / NULLIF((SELECT config_value FROM stat_cost_config WHERE config_key='max_advanced_columns_per_run'),0),1) AS advanced_pct,
    ROUND(100.0 * COUNT(*) FILTER (WHERE pcc.stat_pack='STANDARD' AND pcc.is_active)
          / NULLIF((SELECT config_value FROM stat_cost_config WHERE config_key='max_standard_columns_per_run'),0),1) AS standard_pct
FROM profiler_config_columns pcc
GROUP BY pcc.config_id;
