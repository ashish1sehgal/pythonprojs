"""
pass2_sql_generator.py — Generates Pass-2 sampled aggregation SQL.
Uses centred-moment formula for skewness/kurtosis (numerically stable).
Mean from Pass 1 is injected as a literal to avoid catastrophic cancellation.
BigQuery uses APPROX_QUANTILES (one call per column) for all percentiles.
"""
import logging
from typing import Any, Dict, List, Optional, Tuple
from stat_registry import StatTemplateRegistry

log = logging.getLogger("pass2_sql_generator")

PASS2_STAT_KEYS = ["skewness","kurtosis","p25","median_val","p75","p90","p95","p99"]
PERCENTILE_KEYS = frozenset(["p25","median_val","p75","p90","p95","p99"])
MEAN_DEPENDENT  = frozenset(["skewness","kurtosis"])
BQ_QUANTILE_IDX = {"p25":25,"median_val":50,"p75":75,"p90":90,"p95":95,"p99":99}

from sql_generator import is_numeric, FORBIDDEN_IN_PASS2

def generate_pass2_sql(table_name: str, batch_cols: List[Dict],
                        pass1_results: Dict[str,Any],
                        registry: StatTemplateRegistry) -> Tuple[str, Dict[str,str]]:
    """
    Returns (sql, bq_array_cols) where bq_array_cols = {col_name: alias}
    for columns using BigQuery APPROX_QUANTILES (needs post-query unpacking).
    Sampling clause injected externally via SamplingClause.inject_into_sql().
    """
    clauses = []; bq_array_cols = {}
    for col in batch_cols:
        c_name  = col["column_name"]
        stat_keys = set(col.get("_resolved_stat_keys") or PASS2_STAT_KEYS)
        if not is_numeric(col.get("data_type","")): continue
        forbidden = stat_keys & FORBIDDEN_IN_PASS2
        if forbidden:
            raise ValueError(f"Column '{c_name}' has forbidden Pass-2 stats {forbidden}")

        mean_val = pass1_results.get(f"{c_name}__mean_val")
        mean_lit = f"{float(mean_val):.15g}" if mean_val is not None else None

        # Skewness
        if "skewness" in stat_keys:
            if mean_lit is None:
                log.debug("Skipping skewness for %s — no Pass-1 mean", c_name)
            else:
                expr = registry.render_or_none("skewness", col=c_name, mean=mean_lit)
                if expr: clauses.append(f"{expr} AS {c_name}__skewness")

        # Kurtosis
        if "kurtosis" in stat_keys:
            if mean_lit is None:
                log.debug("Skipping kurtosis for %s — no Pass-1 mean", c_name)
            else:
                expr = registry.render_or_none("kurtosis", col=c_name, mean=mean_lit)
                if expr: clauses.append(f"{expr} AS {c_name}__kurtosis")

        # Percentiles
        pct_keys = stat_keys & PERCENTILE_KEYS
        if pct_keys:
            if registry.platform == "bigquery":
                # One APPROX_QUANTILES(col,100) call covers ALL percentile requests.
                # Oracle optimizer shares one sort across multiple PERCENTILE_CONT calls.
                alias = f"{c_name}__quantile_array"
                clauses.append(f"APPROX_QUANTILES({c_name},100) AS {alias}")
                bq_array_cols[c_name] = alias
            else:
                for key in sorted(pct_keys):
                    expr = registry.render_or_none(key, col=c_name)
                    if expr: clauses.append(f"{expr} AS {c_name}__{key}")

        # Diagnostic: non-null count in sample (NOT used for CI denominator)
        clauses.append(f"COUNT({c_name}) AS {c_name}__sample_nonnull")

    if not clauses: return "", {}
    clauses.append("COUNT(*) AS sample_rows")
    return "SELECT\n  " + ",\n  ".join(clauses) + f"\nFROM {table_name}", bq_array_cols

def unpack_pass2_results(raw: Dict[str,Any], batch_cols: List[Dict],
                          platform: str, bq_array_cols: Dict[str,str]) -> Dict[str,Dict[str,Any]]:
    results = {}
    for col in batch_cols:
        c = col["column_name"]; m = {}
        for key in ("skewness","kurtosis"):
            alias = f"{c}__{key}"
            if alias in raw: m[key] = raw[alias]
        if platform == "bigquery" and c in bq_array_cols:
            arr = raw.get(bq_array_cols[c]) or []
            for key, idx in BQ_QUANTILE_IDX.items():
                if idx < len(arr): m[key] = arr[idx]
        else:
            for key in PERCENTILE_KEYS:
                alias = f"{c}__{key}"
                if alias in raw: m[key] = raw[alias]
        m["sample_nonnull"] = raw.get(f"{c}__sample_nonnull")
        # Box plot whiskers (O(1) Python arithmetic — no DB call)
        q1 = m.get("p25"); q3 = m.get("p75")
        if q1 is not None and q3 is not None:
            iqr = float(q3) - float(q1)
            m["iqr_val"] = iqr
            m["outlier_lower"] = float(q1) - 1.5 * iqr
            m["outlier_upper"] = float(q3) + 1.5 * iqr
        if m: results[c] = m
    return results
