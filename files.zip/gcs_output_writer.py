"""
gcs_output_writer.py — Writes profiling results to GCS + publishes PubSub.
No Postgres or BigQuery connectivity. Pure GCS + PubSub.
Manifest is written LAST to guarantee atomicity: Dataflow never starts
reading until all data files are confirmed written.
"""
import json, logging, math
from datetime import datetime, timezone
from typing import Any, Dict, Iterator, List
from google.cloud import pubsub_v1, storage

log = logging.getLogger("gcs_output_writer")

def _blob_path(run_id: str, fname: str) -> str: return f"runs/{run_id}/{fname}"
def _ndjson(record: Dict[str,Any]) -> str:
    def clean(v):
        if v is None: return None
        if isinstance(v, float) and math.isnan(v): return None
        if isinstance(v, datetime): return v.isoformat()
        return v
    return json.dumps({k: clean(v) for k,v in record.items()}, ensure_ascii=False)

def _write_ndjson(bucket_name, blob_path, records, client) -> int:
    n = 0
    with client.bucket(bucket_name).blob(blob_path).open("wt", encoding="utf-8") as f:
        for r in records: f.write(_ndjson(r)+"\n"); n+=1
    log.info("Wrote %d rows → gs://%s/%s", n, bucket_name, blob_path)
    return n

class GCSOutputWriter:
    def __init__(self, gcs_bucket, pubsub_topic, run_id, source_platform,
                 source_schema, target_table, team_id, config_id):
        self.bucket=gcs_bucket; self.topic=pubsub_topic; self.run_id=run_id
        self.platform=source_platform; self.schema=source_schema; self.table=target_table
        self.team_id=team_id; self.config_id=config_id
        self._gcs=storage.Client(); self._pub=pubsub_v1.PublisherClient()

    def write_all(self, metric_rows, dist_results, hist_results, pat_results, profiles) -> str:
        started = datetime.now(timezone.utc).isoformat(); counts = {}
        r = self.run_id; p = self.platform; s = self.schema; t = self.table

        counts["metrics"] = _write_ndjson(self.bucket, _blob_path(r,"metrics.ndjson"),
            ({"run_id":r,"source_platform":p,"source_schema":s,"target_table":t,"column_name":col,**m}
             for col,m in metric_rows.items()), self._gcs)

        counts["distributions"] = _write_ndjson(self.bucket, _blob_path(r,"distributions.ndjson"),
            ({"run_id":r,"column_name":col,"value_string":row["val"],"frequency_count":row["freq"],"percentage":row["pct"]}
             for col,rows in dist_results.items() for row in rows), self._gcs)

        counts["histograms"] = _write_ndjson(self.bucket, _blob_path(r,"histograms.ndjson"),
            ({"run_id":r,"column_name":col,**b} for col,buckets in hist_results.items() for b in buckets), self._gcs)

        counts["patterns"] = _write_ndjson(self.bucket, _blob_path(r,"patterns.ndjson"),
            ({"run_id":r,"column_name":col,"pattern_mask":row["pattern_mask"],"frequency_count":row["freq"],"percentage":row["pct"]}
             for col,rows in pat_results.items() for row in rows), self._gcs)

        counts["gating"] = _write_ndjson(self.bucket, _blob_path(r,"gating.ndjson"),
            ({"run_id":r,"column_name":col,"total_rows":p2.total_rows,"approx_distinct":p2.approx_distinct,
              "null_count":p2.null_count,"cardinality_class":p2.cardinality_class,
              "pass2_eligible":p2.run_pass2,"pass2_skip_reason":p2.pass2_skip_reason,
              "pass3_eligible":p2.run_pass3,"pass3_skip_reason":p2.pass3_skip_reason,
              "pass4_sw_eligible":p2.run_pass4_sw,"pass4_psi_eligible":p2.run_pass4_psi}
             for col,p2 in profiles.items()), self._gcs)

        # Manifest written LAST — triggers Dataflow
        manifest = {"schema_version":"1.0","run_id":r,"team_id":self.team_id,
                    "config_id":self.config_id,"source_platform":self.platform,
                    "source_schema":self.schema,"target_table":self.table,
                    "started_at":started,"completed_at":datetime.now(timezone.utc).isoformat(),
                    "gcs_prefix":f"gs://{self.bucket}/runs/{r}",
                    "files":{n:{"path":f"gs://{self.bucket}/{_blob_path(r,n+'.ndjson')}","row_count":c}
                             for n,c in counts.items()}}
        mpath = _blob_path(r,"manifest.json")
        self._gcs.bucket(self.bucket).blob(mpath).upload_from_string(
            json.dumps(manifest,indent=2), content_type="application/json")
        manifest_uri = f"gs://{self.bucket}/{mpath}"
        log.info("Manifest written: %s", manifest_uri)

        # PubSub notification — <1KB, path reference only
        msg = {"run_id":r,"team_id":self.team_id,"manifest_uri":manifest_uri,
               "source_platform":self.platform,"table_fqn":f"{self.schema}.{self.table}",
               "column_count":counts.get("metrics",0),"published_at":datetime.now(timezone.utc).isoformat()}
        mid = self._pub.publish(self.topic, json.dumps(msg).encode(),
                                run_id=r, team_id=self.team_id).result(timeout=30)
        log.info("PubSub published: message_id=%s | %d bytes", mid, len(json.dumps(msg)))
        return manifest_uri
