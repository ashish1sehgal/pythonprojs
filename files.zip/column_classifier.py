"""
column_classifier.py — Classifies columns from Pass-1 results.
Determines which subsequent passes run for each column.
"""
import logging, psycopg2
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Set

log = logging.getLogger("column_classifier")

_NUMERIC = ("NUMBER","INT","FLOAT","DECIMAL","NUMERIC","DOUBLE","REAL","BIGINT")
_STRING  = ("VARCHAR","STRING","CHAR","TEXT","NVARCHAR","CLOB")
_BOOLEAN = ("BOOLEAN","BOOL","BIT","TINYINT(1)","BIT(1)")

def is_numeric(t): return any(m in t.upper() for m in _NUMERIC)
def is_string(t):  return any(m in t.upper() for m in _STRING)
def is_boolean(t): return any(m in t.upper() for m in _BOOLEAN)

class C:
    ALL_NULL     = "ALL_NULL"
    CONSTANT     = "CONSTANT"
    BINARY       = "BINARY"
    LOW          = "LOW_CARDINALITY"
    CATEGORICAL  = "CATEGORICAL"
    MEDIUM       = "MEDIUM_CARDINALITY"
    HIGH         = "HIGH_CARDINALITY"
    PRIMARY_KEY  = "PRIMARY_KEY"

@dataclass
class ColumnProfile:
    column_name:       str
    data_type:         str
    cardinality_class: str
    total_rows:        int
    approx_distinct:   int
    null_count:        int
    valid_count:       int
    null_pct:          float
    min_val:           Any
    max_val:           Any
    mean_val:          Optional[float]
    run_pass2:         bool = False   # sample distributional stats
    run_pass3:         bool = False   # categorical: top-N + patterns
    run_pass4_sw:      bool = False   # Shapiro-Wilk
    run_pass4_psi:     bool = False   # PSI drift
    pass2_skip_reason: Optional[str] = None
    pass3_skip_reason: Optional[str] = None
    pass4_psi_skip_reason: Optional[str] = None

class ColumnClassifier:
    def __init__(self, pg_creds: dict, baseline_columns: Optional[Set[str]] = None):
        self.baseline_columns = baseline_columns or set()
        cfg = self._load_thresholds(pg_creds)
        self.CATEGORICAL_THRESHOLD  = int(cfg.get("categorical_threshold",  1000))
        self.HIGH_CARDINALITY_RATIO = float(cfg.get("high_cardinality_ratio", 0.10))
        self.PRIMARY_KEY_RATIO      = float(cfg.get("primary_key_ratio",      0.95))
        self.SAMPLING_THRESHOLD     = int(cfg.get("target_sample_rows",   1000000))

    def _load_thresholds(self, pg_creds):
        conn = psycopg2.connect(**pg_creds)
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT config_key, config_value FROM stat_cost_config")
                return {k: v for k,v in cur.fetchall()}
        finally:
            conn.close()

    def classify_all(self, config_columns: List[Dict], pass1: Dict[str,Any], total_rows: int) -> Dict[str, ColumnProfile]:
        profiles = {}
        for col in config_columns:
            if not col.get("is_active", True): continue
            p = self._classify_one(col, pass1, total_rows)
            profiles[p.column_name] = p
        from collections import Counter
        cc = Counter(p.cardinality_class for p in profiles.values())
        log.info("Classification: total_rows=%d | %s | pass2=%d | pass3=%d | psi=%d",
                 total_rows, dict(cc),
                 sum(1 for p in profiles.values() if p.run_pass2),
                 sum(1 for p in profiles.values() if p.run_pass3),
                 sum(1 for p in profiles.values() if p.run_pass4_psi))
        return profiles

    def _classify_one(self, col, pass1, total_rows):
        c_name = col["column_name"]
        c_type = col["data_type"]
        null_count      = int(pass1.get(f"{c_name}__empty_count") or 0)
        approx_distinct = int(pass1.get(f"{c_name}__distinct_count") or 0)
        mean_val        = pass1.get(f"{c_name}__mean_val")
        min_val         = pass1.get(f"{c_name}__min_val")
        max_val         = pass1.get(f"{c_name}__max_val")
        valid_count     = max(total_rows - null_count, 0)
        null_pct        = null_count / total_rows if total_rows > 0 else 1.0
        cls             = self._classify_cardinality(null_count, valid_count, approx_distinct, total_rows)

        p = ColumnProfile(c_name, c_type, cls, total_rows, approx_distinct,
                          null_count, valid_count, null_pct, min_val, max_val,
                          float(mean_val) if mean_val is not None else None)

        # Pass 2 gate: numeric, not degenerate, table large enough OR always run if small
        if is_boolean(c_type):
            p.pass2_skip_reason = "BOOLEAN_TYPE"
        elif not is_numeric(c_type):
            p.pass2_skip_reason = "STRING_TYPE"
        elif cls == C.ALL_NULL:
            p.pass2_skip_reason = "ALL_NULL"
        elif cls in (C.CONSTANT,):
            p.pass2_skip_reason = "CONSTANT"
        elif min_val is not None and max_val is not None and str(min_val) == str(max_val):
            p.pass2_skip_reason = "CONSTANT_VALUE"
        else:
            p.run_pass2 = True

        # Pass 3 gate: string, categorical cardinality only
        if not is_string(c_type):
            p.pass3_skip_reason = "NUMERIC_TYPE"
        elif cls == C.ALL_NULL:
            p.pass3_skip_reason = "ALL_NULL"
        elif cls in (C.HIGH, C.PRIMARY_KEY):
            p.pass3_skip_reason = "HIGH_CARDINALITY"
        else:
            p.run_pass3 = True

        # Pass 4 SW gate
        if is_numeric(c_type) and cls not in (C.ALL_NULL, C.CONSTANT) and valid_count >= 8:
            p.run_pass4_sw = True

        # Pass 4 PSI gate
        if c_name in self.baseline_columns:
            p.run_pass4_psi = True
        else:
            p.pass4_psi_skip_reason = "NO_BASELINE" if not self.baseline_columns else "NOT_IN_BASELINE"

        return p

    def _classify_cardinality(self, null_count, valid_count, approx_distinct, total_rows):
        if valid_count == 0: return C.ALL_NULL
        ratio = approx_distinct / total_rows if total_rows > 0 else 0
        if approx_distinct <= 1:   return C.CONSTANT
        if approx_distinct <= 2:   return C.BINARY
        if approx_distinct < 50:   return C.LOW
        if approx_distinct < self.CATEGORICAL_THRESHOLD: return C.CATEGORICAL
        if ratio >= self.PRIMARY_KEY_RATIO:  return C.PRIMARY_KEY
        if ratio >= self.HIGH_CARDINALITY_RATIO: return C.HIGH
        return C.MEDIUM
