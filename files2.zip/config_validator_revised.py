"""
config_validator_revised.py
----------------------------
Replaces the _check_limits() method in config_validator.py.

Key change: STANDARD column count check is removed entirely.
With 50-column batching, the per-run STANDARD column count is not a DB
expression limit concern. The batch size is the alias guard, not the total.

What is still checked
---------------------
1. ADVANCED column count vs max_advanced_columns_per_run
   Reason: each ADVANCED column adds one full-table GROUP BY scan (histogram),
   independent of batching. 50 ADVANCED columns = 50 full-table scans.
   This is a DB load concern, not an alias count concern.

2. Per-column deselection validity (unchanged)
3. Cardinality-based stat restrictions (unchanged)

What is no longer checked
--------------------------
- STANDARD column count: not a real constraint with batching in place.
  A 2000-column STANDARD profile is legitimate and will run in ~40 batches.
"""

from typing import Dict, List, Tuple


def _check_limits(self, counts: Dict[str, int]) -> Tuple[List[str], List[str]]:
    """
    Revised limit checker. Only enforces ADVANCED column count.
    STANDARD column count check removed — batching makes it irrelevant.
    """
    errors = []; warnings = []

    adv      = counts.get("ADVANCED", 0)
    max_adv  = self._limits.get("max_advanced_columns_per_run", 25)
    warn_adv = self._limits.get("warn_advanced_columns", 10)

    if adv > max_adv:
        errors.append(
            f"{adv} columns are set to ADVANCED pack, exceeding the limit of {max_adv}. "
            f"Each ADVANCED column fires a dedicated full-table histogram GROUP BY scan "
            f"against the source DB — independent of the batch size. "
            f"Downgrade {adv - max_adv} column(s) to STANDARD or BASIC."
        )
    elif adv > warn_adv:
        warnings.append(
            f"{adv} ADVANCED columns selected "
            f"(warning threshold: {warn_adv}, hard limit: {max_adv}). "
            f"Run time will be longer due to per-column histogram scans."
        )

    # STANDARD column count: no limit enforced.
    # With batch_size=50, each SELECT has at most 50×~8=400 aliases — well
    # below Oracle's ~1000 expression limit. A 2000-column STANDARD profile
    # is valid and runs in 40 sequential batches.
    # The batch size itself (batch_size_pass1 in stat_cost_config) is the
    # actual alias guard, and the CostGovernor auto-reduces it per-batch
    # if a column's stat alias count approaches oracle_max_aliases_per_select.

    return errors, warnings


# ==============================================================================
# Updated alias-safety check — now per-batch, not per-run
# ==============================================================================

def compute_safe_batch_size(
    batch_cols:           List[Dict],
    platform:             str,
    oracle_alias_limit:   int = 900,
    nominal_batch_size:   int = 50,
) -> int:
    """
    Computes the safe batch size for a specific batch of columns on Oracle.
    Called per-batch by the orchestrator, not per-run by the validator.

    For non-Oracle platforms: returns nominal_batch_size unchanged.
    For Oracle: reduces batch size if the worst-case column would push the
                SELECT alias count above oracle_alias_limit.

    The worst-case column is the one with the most stat aliases —
    typically an ADVANCED column with all stats enabled.

    Example:
      A batch contains one ADVANCED column with 15 stat aliases.
      oracle_alias_limit = 900
      safe_batch_size = FLOOR(900 / 15) = 60   → no reduction needed
      nominal_batch_size = 50                   → 50 used (min of 50 and 60)

      If the ADVANCED column had 25 stat aliases:
      safe_batch_size = FLOOR(900 / 25) = 36   → batch reduced to 36
    """
    if platform != "oracle":
        return nominal_batch_size

    # Count the maximum aliases any single column would generate
    max_aliases = max(
        len(col.get("_effective_stat_keys") or []) + 1  # +1 for total_table_rows
        for col in batch_cols
    ) if batch_cols else 1

    safe = max(1, oracle_alias_limit // max_aliases)
    return min(safe, nominal_batch_size)
