ALTER TABLE profiler_runs 
  ADD COLUMN department_id VARCHAR(50) REFERENCES department_budgets(department_id),
  ADD COLUMN execution_tier VARCHAR(50),
  ADD COLUMN billed_credits INT;