CREATE TABLE department_budgets (
    department_id VARCHAR(50) PRIMARY KEY, -- e.g., 'marketing_analytics', 'fraud_ds'
    department_name VARCHAR(100),
    monthly_credit_limit INT DEFAULT 1000,
    credits_used_this_month INT DEFAULT 0,
    alert_threshold_percent INT DEFAULT 80 -- Trigger email when 80% used
);