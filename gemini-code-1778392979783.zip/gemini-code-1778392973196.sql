ALTER TABLE profiler_run_metrics 
  ADD COLUMN skipped_operations JSONB DEFAULT '{}'::jsonb;

-- Example of what will be stored:
-- {"Skewness": "High Cardinality (98% unique)", "Top-K": "Cardinality > 1000 threshold"}