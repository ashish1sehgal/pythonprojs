import json
import math
import re
import numpy as np
import pandas as pd
import psycopg2
from pyspark.sql import SparkSession
import pyspark.sql.functions as F
from scipy import stats as scipy_stats
from google.cloud import storage

# --- ARCHITECTURAL CONSTANTS ---
PASS_1_STATS = {'Empty Count', 'Min', 'Max', 'Mean', 'Distinct Count'} 
PASS_2_STATS = {'Skewness', 'Kurtosis', 'Box Plot'}
MAX_SAMPLE_ROWS = 1000000 
MICRO_SAMPLE_ROWS = 2000

class EnterpriseProfilerEngine:
    def __init__(self, spark, pg_creds, source_platform, execution_tier):
        self.spark = spark
        self.pg_conn = psycopg2.connect(**pg_creds)
        self.source_platform = source_platform.upper()
        self.execution_tier = execution_tier.upper() # BASIC, ADVANCED, or COMPLIANCE
        self.dialect_cache = self._load_dialect_dictionary()

    def _load_dialect_dictionary(self):
        """Loads the stat2sql metadata mapping dynamically."""
        cache = {}
        cur = self.pg_conn.cursor()
        # Fallback to spark dialect if native pushdown dialect is missing
        cur.execute(f"SELECT stat, COALESCE({self.source_platform.lower()}, spark) FROM stat2sql")
        for stat, template in cur.fetchall():
            if template: cache[stat.strip()] = template.strip()
        cur.close()
        return cache

    def _is_id_column(self, column_name):
        """Heuristic Lockout: Identifies PK/FKs to bypass heavy distributional math."""
        name_lower = column_name.lower()
        return name_lower.endswith(('_id', '_sk', '_key', 'uuid')) or name_lower in ['id', 'pk']

    def _evaluate_normality(self, data_series, test_name='Shapiro-Wilk', alpha=0.05):
        """Pass 4: SciPy Math on the Driver Node."""
        clean_data = data_series.dropna().astype(float)
        if len(clean_data) < 4 or clean_data.nunique() <= 1:
            return (test_name, None, None, None)
        try:
            if test_name == 'Shapiro-Wilk':
                stat, p_value = scipy_stats.shapiro(clean_data)
                return (test_name, float(stat), float(p_value), bool(p_value > alpha))
        except Exception:
            return (test_name, None, None, None)

    # ==========================================
    # CORE EXECUTION ENGINE
    # ==========================================
    def execute_job(self, run_id, target_table, config_columns):
        # 1. Load Data (Native Pushdown happens under the hood via Spark Connector)
        df = self.spark.read.format("bigquery").load(target_table)
        df.createOrReplaceTempView("full_table")
        total_rows = df.count()
        
        # 2. Determine Sample Fraction for Advanced Stats
        sample_fraction = min(1.0, MAX_SAMPLE_ROWS / total_rows) if total_rows > 0 else 1.0
        
        # Chunk into 50-column batches to prevent query length limits
        batches = [config_columns[i:i + 50] for i in range(0, len(config_columns), 50)]
        
        for batch_num, batch_cols in enumerate(batches):
            metrics_payloads = []
            hist_payloads = []
            freq_payloads = []
            pattern_payloads = []
            
            pass_1_selects = ["COUNT(*) AS total_table_rows"]
            pass_2_selects = []

            # --- DYNAMIC SQL ROUTING VIA stat2sql ---
            for col in batch_cols:
                c = col['column_name']
                is_id = self._is_id_column(c)
                requested_stats = col.get('stats', [])
                
                for stat in requested_stats:
                    template = self.dialect_cache.get(stat)
                    if not template: continue
                    
                    sql_snippet = template.replace("<<col>>", f"`{c}`")
                    
                    # Exact Distinct Logic (Compliance Tier Override)
                    if stat == 'Distinct Count':
                        if self.execution_tier == 'COMPLIANCE' and col.get('force_exact_distinct'):
                            sql_snippet = f"COUNT(DISTINCT `{c}`)"
                        else:
                            # Default to HyperLogLog even if exact was requested outside compliance
                            sql_snippet = f"approx_count_distinct(`{c}`, 0.05)"
                            
                    # Route to Pass 1 (Full Table)
                    if stat in PASS_1_STATS:
                        pass_1_selects.append(f"{sql_snippet} AS `{c}__{stat}`")
                        
                    # Route to Pass 2 (Sampled Table) - Apply Heuristic Lockout!
                    elif stat in PASS_2_STATS and not is_id and col['data_type'] in ['INT', 'DECIMAL', 'FLOAT']:
                        pass_2_selects.append(f"{sql_snippet} AS `{c}__{stat}`")

            # ==========================================
            # PASS 1: FULL POPULATION BASE SCAN
            # ==========================================
            pass_1_sql = "SELECT \n  " + ",\n  ".join(pass_1_selects) + "\nFROM full_table"
            base_results = self.spark.sql(pass_1_sql).first().asDict()

            # ==========================================
            # PASS 2: SHAPE & DISTRIBUTION (SAMPLED)
            # ==========================================
            shape_results = {}
            # Cache the sample once in memory to speed up Passes 2, 3, and 4
            sample_df = df.sample(withReplacement=False, fraction=sample_fraction).cache()
            sample_df.createOrReplaceTempView("sample_table")

            if pass_2_selects:
                pass_2_sql = "SELECT \n  " + ",\n  ".join(pass_2_selects) + "\nFROM sample_table"
                shape_results = self.spark.sql(pass_2_sql).first().asDict()

            # ==========================================
            # PASS 3 & 4: SEMANTICS, PATTERNS & ML TESTS
            # ==========================================
            for col in batch_cols:
                c_name = col['column_name']
                is_id = self._is_id_column(c_name)
                column_warnings = {}
                
                empty_ct = base_results.get(f"{c_name}__Empty Count")
                mean_val = base_results.get(f"{c_name}__Mean")
                distinct_ct = base_results.get(f"{c_name}__Distinct Count", 0)
                
                # --- Pass 3: Categorical Top-K & Pattern Regex ---
                if col['data_type'] in ['STRING', 'VARCHAR'] and not is_id:
                    # Fencing: Only run Top-K if cardinality is reasonably low
                    if distinct_ct < 1000:
                        try:
                            # Categorical Top 10 Frequencies
                            freq_df = sample_df.groupBy(c_name).count().orderBy(F.desc("count")).limit(10).collect()
                            for row in freq_df:
                                if row[c_name] is not None:
                                    freq_payloads.append({"column_name": c_name, "value": str(row[c_name]), "count": row["count"]})
                        except Exception as e:
                            column_warnings["frequencies"] = "Failed to compute Top K."

                    # Patterns: Run regardless of cardinality, as long as it's not an ID column
                    try:
                        # Replace letters with A, numbers with N natively in Spark
                        pattern_df = sample_df.withColumn(
                            "mask", 
                            F.regexp_replace(F.regexp_replace(F.col(c_name), "[a-zA-Z]", "A"), "[0-9]", "N")
                        ).groupBy("mask").count().orderBy(F.desc("count")).limit(10).collect()
                        
                        for row in pattern_df:
                            if row["mask"] is not None:
                                pattern_payloads.append({"column_name": c_name, "pattern": row["mask"], "count": row["count"]})
                    except Exception as e:
                        column_warnings["patterns"] = "Failed to compute patterns."

                # --- Pass 4: SciPy Normality (Micro-Sample) ---
                t_name, t_stat, p_val, is_norm = None, None, None, None
                if col.get('normality_test') and not is_id and col['data_type'] in ['INT', 'DECIMAL']:
                    try:
                        micro_sample = sample_df.select(c_name).limit(MICRO_SAMPLE_ROWS).toPandas()
                        t_name, t_stat, p_val, is_norm = self._evaluate_normality(micro_sample[c_name], col['normality_test'])
                    except Exception as e:
                        column_warnings["normality"] = "SciPy Math Error."

                # --- Map Pass 2 Shape Results ---
                skew_val = shape_results.get(f"{c_name}__Skewness")
                kurt_val = shape_results.get(f"{c_name}__Kurtosis")
                quartiles = shape_results.get(f"{c_name}__Box Plot")

                # Package the Row
                metrics_payloads.append({
                    "run_id": run_id,
                    "column_name": c_name,
                    "empty_count": empty_ct,
                    "mean_val": mean_val,
                    "distinct_count": distinct_ct,
                    "percentile_25": quartiles[0] if quartiles else None,
                    "median_val": quartiles[1] if quartiles else None,
                    "percentile_75": quartiles[2] if quartiles else None,
                    "skewness_val": skew_val if not (skew_val and math.isnan(skew_val)) else None,
                    "kurtosis_val": kurt_val if not (kurt_val and math.isnan(kurt_val)) else None,
                    "normality_test_name": t_name,
                    "is_normal": is_norm,
                    "execution_warnings": json.dumps(column_warnings)
                })

            sample_df.unpersist() # Clear memory for the next 50-column batch
            
            # Drop everything into the GCS "Inbox" for SpringBoot to securely digest
            self._drop_to_data_inbox(run_id, batch_num, metrics_payloads, hist_payloads, freq_payloads, pattern_payloads)

    def _drop_to_data_inbox(self, run_id, batch_num, metrics, hists, freqs, patterns):
        master_payload = {
            "run_id": run_id,
            "metrics": metrics,
            "histograms": hists,
            "frequencies": freqs,
            "patterns": patterns
        }
        local_path = f"/tmp/{run_id}_b{batch_num}.json"
        with open(local_path, 'w') as f:
            json.dump(master_payload, f)
            
        client = storage.Client()
        bucket = client.bucket("hub-profiler-inbox")
        blob = bucket.blob(f"incoming/run_id={run_id}/batch_{batch_num}.json")
        blob.upload_from_filename(local_path)