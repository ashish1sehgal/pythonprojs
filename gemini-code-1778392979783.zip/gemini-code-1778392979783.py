# Inside the batch execution loop...

metrics_payloads = []
pass_1_selects = ["COUNT(*) AS total_table_rows"]

# ==========================================
# 1. BUILD & EXECUTE PASS 1
# ==========================================
for col in batch_cols:
    c = col['column_name']
    for stat in col.get('stats', []):
        template = self.dialect_cache.get(stat)
        if stat in PASS_1_STATS and template:
            # e.g., approx_count_distinct(`client_id`, 0.05)
            sql_snippet = template.replace("<<col>>", f"`{c}`")
            pass_1_selects.append(f"{sql_snippet} AS `{c}__{stat}`")

pass_1_sql = "SELECT \n  " + ",\n  ".join(pass_1_selects) + "\nFROM full_table"
base_results = self.spark.sql(pass_1_sql).first().asDict()
total_rows = base_results.get("total_table_rows", 0)

# ==========================================
# 2. RUNTIME DECISION ENGINE (CIRCUIT BREAKER)
# ==========================================
pass_2_selects = []
skipped_ops_master = {} # Dictionary to hold {column_name: {stat: reason}}

for col in batch_cols:
    c_name = col['column_name']
    skipped_ops_master[c_name] = {}
    
    # Fetch Pass 1 results for this specific column
    approx_distinct = base_results.get(f"{c_name}__Distinct Count", 0)
    
    # Calculate Uniqueness Percentage
    uniqueness_ratio = (approx_distinct / total_rows) if total_rows > 0 else 0
    is_high_cardinality = uniqueness_ratio > 0.90 # 90% unique threshold
    
    for stat in col.get('stats', []):
        if stat in PASS_2_STATS:
            # THE RUNTIME LOCKOUT
            if is_high_cardinality:
                skipped_ops_master[c_name][stat] = f"Skipped: High Cardinality ({uniqueness_ratio:.1%} unique)"
            else:
                # If safe, add it to Pass 2 SQL
                template = self.dialect_cache.get(stat)
                if template:
                    sql_snippet = template.replace("<<col>>", f"`{c_name}`")
                    pass_2_selects.append(f"{sql_snippet} AS `{c_name}__{stat}`")

# ==========================================
# 3. EXECUTE PASS 2 (Only on approved columns)
# ==========================================
shape_results = {}
if pass_2_selects:
    sample_df = df.sample(withReplacement=False, fraction=sample_fraction).cache()
    sample_df.createOrReplaceTempView("sample_table")
    pass_2_sql = "SELECT \n  " + ",\n  ".join(pass_2_selects) + "\nFROM sample_table"
    shape_results = self.spark.sql(pass_2_sql).first().asDict()

# ==========================================
# 4. UNPIVOT & PACKAGE
# ==========================================
for col in batch_cols:
    c_name = col['column_name']
    
    # Pass 3 Semantic Lockout (Top K & Patterns)
    distinct_ct = base_results.get(f"{c_name}__Distinct Count", 0)
    if distinct_ct > 1000:
        skipped_ops_master[c_name]["Top-K Frequencies"] = f"Skipped: Distinct count ({distinct_ct}) exceeds 1000 limit."
        skipped_ops_master[c_name]["Pattern Inference"] = f"Skipped: Distinct count ({distinct_ct}) exceeds 1000 limit."
    else:
        # ... Execute Pass 3 Top K math here ...
        pass

    # Package for GCS Inbox
    metrics_payloads.append({
        "run_id": run_id,
        "column_name": c_name,
        "mean_val": base_results.get(f"{c_name}__Mean"),
        "skewness_val": shape_results.get(f"{c_name}__Skewness"), # Will safely be None if skipped
        "skipped_operations": json.dumps(skipped_ops_master[c_name]) # <-- Audit Log Included!
    })