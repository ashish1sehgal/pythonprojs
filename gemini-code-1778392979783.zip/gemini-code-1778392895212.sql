-- 1. Track the FinOps / Execution Tier in the Run History
ALTER TABLE profiler_runs 
  ADD COLUMN execution_tier VARCHAR(50) DEFAULT 'BASIC'; -- 'BASIC', 'ADVANCED', 'COMPLIANCE'

-- 2. New Table: To store the Top 10 Regex Patterns per string column
CREATE TABLE profiler_run_patterns (
    pattern_id SERIAL PRIMARY KEY,
    run_id UUID NOT NULL,
    column_name VARCHAR(255) NOT NULL,
    pattern_string VARCHAR(255),  -- e.g., 'AAAA_NNN'
    frequency_count BIGINT,       -- How many times it appeared in the sample
    UNIQUE(run_id, column_name, pattern_string)
);

-- 3. New Table: To store Top K Values (Categorical Frequencies)
CREATE TABLE profiler_run_frequencies (
    frequency_id SERIAL PRIMARY KEY,
    run_id UUID NOT NULL,
    column_name VARCHAR(255) NOT NULL,
    actual_value TEXT,            -- e.g., 'PENDING', 'SHIPPED'
    frequency_count BIGINT,
    UNIQUE(run_id, column_name, actual_value)
);