CREATE TABLE tier_pricing_rules (
    tier_name VARCHAR(50) PRIMARY KEY, -- 'BASIC', 'ADVANCED', 'COMPLIANCE'
    base_cost_credits INT NOT NULL,
    per_column_penalty INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE
);

-- Insert our agreed-upon model
INSERT INTO tier_pricing_rules (tier_name, base_cost_credits, per_column_penalty) VALUES 
('BASIC', 10, 0),
('ADVANCED', 20, 0),
('COMPLIANCE', 10, 5); -- Base 10 + 5 per Exact Distinct column